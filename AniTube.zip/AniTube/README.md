# AniTube
1. Android Studio -> File > Open -> AniTube folder (Gradle sync hone do)
2. Phone connect karo -> Run
3. Release APK: Build > Generate Signed Bundle / APK
