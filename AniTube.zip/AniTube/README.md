# AniTube
1. Android Studio -> File > Open -> AniTube folder (Gradle sync hone do)
2. Phone connect karo -> Run
3. Release APK: Build > Generate Signed Bundle / APK

## Naye features
- Subtitle delay / Audio delay: Settings (tune icon) -> Subtitles / Audio -> -1s, -0.1, +0.1, +1s, Reset (MX Player jaisa, har video ka alag, sirf current session me).
  - Audio delay sirf decoded (PCM) audio par chalta hai, passthrough par nahi.
  - External subtitle file: + aur - dono delay. Embedded subtitle (mkv ke andar): sirf + (late) delay.
- Subtitle ON/OFF: right rail ka CC button ya Settings -> Subtitles -> ON/OFF.
- Collapsible: Settings ke sab sections (tap karke khulo/band, yaad rehta hai), player ka right rail (chevron), home par "Continue Watching".
