package com.anitube.player

import android.content.Context

class Entry(val uri: String, val pos: Long, val dur: Long, val time: Long, val folder: String, val name: String)

/** Dekhe hue videos ki history (position, duration, folder). SharedPreferences mein, extra library nahi. */
object History {
    private fun sp(c: Context) = c.getSharedPreferences("hist", Context.MODE_PRIVATE)

    private fun parse(k: String, v: String): Entry? {
        val p = v.split("|", limit = 5)
        if (p.size < 5) return null
        return Entry(k, p[0].toLongOrNull() ?: 0L, p[1].toLongOrNull() ?: 0L, p[2].toLongOrNull() ?: 0L, p[3], p[4])
    }

    fun get(c: Context, uri: String): Entry? = sp(c).getString(uri, null)?.let { parse(uri, it) }

    fun save(c: Context, uri: String, pos: Long, dur: Long, folder: String, name: String) {
        sp(c).edit()
            .putString(uri, "$pos|$dur|${System.currentTimeMillis()}|${folder.replace('|', ' ')}|$name")
            .apply()
    }

    fun recent(c: Context, n: Int): List<Entry> =
        sp(c).all.mapNotNull { (k, v) -> (v as? String)?.let { parse(k, it) } }
            .sortedByDescending { it.time }.take(n)

    fun finished(e: Entry) = e.dur > 0 && e.pos >= e.dur - 5000
}
