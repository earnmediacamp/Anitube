package com.anitube.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.ui.AspectRatioFrameLayout as AR
import androidx.media3.ui.PlayerView
import kotlin.math.abs

@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private lateinit var player: ExoPlayer
    private lateinit var uris: Array<String>
    private lateinit var pv: PlayerView
    private lateinit var info: TextView
    private lateinit var bar: View
    private lateinit var lockBtn: TextView
    private lateinit var decBtn: TextView
    private lateinit var am: AudioManager
    private val prefs by lazy { getSharedPreferences("pos", MODE_PRIVATE) }
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val modes = intArrayOf(AR.RESIZE_MODE_FIT, AR.RESIZE_MODE_FILL, AR.RESIZE_MODE_ZOOM)
    private val names = arrayOf("Fit", "Stretch", "Crop")
    private var mode = 0
    private var locked = false
    private var g = 0          // gesture: 1=seek 2=brightness 3=volume
    private var seekBy = 0L
    private var bright = 0.5f
    private var vol = 0f

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).run {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        pv = findViewById(R.id.pv)
        info = findViewById(R.id.info)
        bar = findViewById(R.id.bar)
        lockBtn = findViewById(R.id.lockBtn)
        decBtn = findViewById(R.id.decBtn)
        val aspectBtn = findViewById<TextView>(R.id.aspectBtn)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()

        uris = intent.getStringArrayExtra("uris") ?: arrayOf(intent.dataString ?: return finish())
        start(0, prefs.getLong(uris[0], 0L))

        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            if (!locked) bar.visibility = v
        })

        decBtn.setOnClickListener {
            prefs.edit().putBoolean("sw", !prefs.getBoolean("sw", false)).apply()
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            player.release()
            start(i, p)
            show(decBtn.text.toString() + " decoder")
        }
        lockBtn.setOnClickListener {
            locked = !locked
            lockBtn.text = if (locked) "🔓" else "🔒"
            val v = if (locked) View.GONE else View.VISIBLE
            aspectBtn.visibility = v
            decBtn.visibility = v
            pv.useController = !locked
            if (locked) { pv.hideController(); bar.visibility = View.VISIBLE }
        }
        aspectBtn.setOnClickListener {
            mode = (mode + 1) % 3
            pv.resizeMode = modes[mode]
            show(names[mode])
        }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                else if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val d = if (e.x < pv.width / 2) -10_000L else 10_000L
                player.seekTo((player.currentPosition + d).coerceAtLeast(0))
                show(if (d < 0) "⏪ 10s" else "10s ⏩")
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null) return false
                if (g == 0) g = if (abs(dx) > abs(dy)) 1 else if (e1.x < pv.width / 2) 2 else 3
                when (g) {
                    1 -> {
                        seekBy -= (dx * 80).toLong()
                        show((if (seekBy >= 0) "+" else "") + seekBy / 1000 + "s")
                    }
                    2 -> {
                        bright = (bright + dy / pv.height).coerceIn(0.01f, 1f)
                        window.attributes = window.attributes.also { it.screenBrightness = bright }
                        show("☀ " + (bright * 100).toInt() + "%")
                    }
                    else -> {
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        vol = (vol + dy / pv.height * max).coerceIn(0f, max.toFloat())
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                        show("🔊 " + vol.toInt() + "/" + max)
                    }
                }
                return true
            }
        })

        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (!locked) {
                    if (d.scaleFactor > 1.02f) pv.resizeMode = AR.RESIZE_MODE_ZOOM
                    else if (d.scaleFactor < 0.98f) pv.resizeMode = AR.RESIZE_MODE_FIT
                }
                return true
            }
        })

        pv.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (!sd.isInProgress) gd.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (g == 1 && seekBy != 0L) player.seekTo((player.currentPosition + seekBy).coerceAtLeast(0))
                g = 0; seekBy = 0
            }
            true
        }
    }

    /** Player banata hai. HW mode = default decoders, SW mode = sirf software decoders (fallback: default). */
    private fun start(index: Int, pos: Long) {
        val sw = prefs.getBoolean("sw", false)
        val selector = MediaCodecSelector { mime, secure, tunnel ->
            val l = MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel)
            if (sw) l.filter { it.softwareOnly }.ifEmpty { l } else l
        }
        player = ExoPlayer.Builder(
            this,
            DefaultRenderersFactory(this).setMediaCodecSelector(selector).setEnableDecoderFallback(true)
        ).build()
        pv.player = player
        player.setMediaItems(uris.map { MediaItem.fromUri(it) }, index, pos)
        player.prepare()
        player.play()
        decBtn.text = if (sw) "SW" else "HW"
    }

    private fun show(t: String) {
        info.removeCallbacks(hideInfo)
        info.text = t
        info.visibility = View.VISIBLE
        info.postDelayed(hideInfo, 800)
    }

    private fun save() {
        val u = player.currentMediaItem?.localConfiguration?.uri?.toString() ?: return
        val d = player.duration
        prefs.edit().putLong(u, if (d > 0 && player.currentPosition > d - 5000) 0 else player.currentPosition).apply()
    }

    override fun onUserLeaveHint() {
        if (!locked && player.isPlaying) enterPictureInPictureMode(PictureInPictureParams.Builder().build())
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        pv.useController = !inPip && !locked
        if (inPip) bar.visibility = View.GONE
    }

    override fun onStop() { super.onStop(); save(); player.pause() }
    override fun onDestroy() { super.onDestroy(); player.release() }
}
