package com.anitube.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.provider.OpenableColumns
import android.util.TypedValue
import java.io.File
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.ui.AspectRatioFrameLayout as AR
import androidx.media3.ui.PlayerView
import kotlin.math.abs

@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private lateinit var player: ExoPlayer
    private lateinit var uris: Array<String>
    private lateinit var pv: PlayerView
    private lateinit var info: TextView
    private lateinit var ttl: TextView
    private lateinit var decBtn: TextView
    private lateinit var playBtn: ImageView
    private lateinit var unlockBtn: ImageView
    private lateinit var am: AudioManager
    private val prefs by lazy { getSharedPreferences("set", MODE_PRIVATE) }
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }
    private val modes = intArrayOf(AR.RESIZE_MODE_FIT, AR.RESIZE_MODE_FILL, AR.RESIZE_MODE_ZOOM)
    private val aspectNames = arrayOf("Fit", "Stretch", "Crop")
    private var mode = 0
    private var folder = ""
    private var names: Array<String>? = null
    private var locked = false
    private var g = 0          // gesture: 1=seek 2=brightness 3=volume
    private var seekBy = 0L
    private var bright = 0.5f
    private var vol = 0f
    private val subs = HashMap<Int, MediaItem.SubtitleConfiguration>()
    private var dlg: AlertDialog? = null
    private var tf: Typeface? = null
    private val DLG = android.R.style.Theme_DeviceDefault_Dialog_Alert

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        pv = findViewById(R.id.pv)
        info = findViewById(R.id.info)
        ttl = findViewById(R.id.title)
        decBtn = findViewById(R.id.decBtn)
        playBtn = findViewById(R.id.playBtn)
        unlockBtn = findViewById(R.id.unlockBtn)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()

        uris = intent.getStringArrayExtra("uris") ?: arrayOf(intent.dataString ?: return finish())
        names = intent.getStringArrayExtra("names")
        folder = intent.getStringExtra("folder") ?: ""
        val h = History.get(this, uris[0])
        start(0, if (h != null && !History.finished(h)) h.pos else 0L)
        loadFont(); applySub(); applyEnh()
        pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.setOnClickListener { menu() }

        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        findViewById<View>(R.id.prevBtn).setOnClickListener { player.seekToPreviousMediaItem() }
        findViewById<View>(R.id.nextBtn).setOnClickListener { player.seekToNextMediaItem() }
        findViewById<View>(R.id.pipBtn).setOnClickListener { pip() }
        findViewById<View>(R.id.rotateBtn).setOnClickListener {
            requestedOrientation =
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        findViewById<View>(R.id.aspectBtn).setOnClickListener {
            mode = (mode + 1) % 3
            pv.resizeMode = modes[mode]
            show(aspectNames[mode])
        }
        playBtn.setOnClickListener {
            if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) player.play() else player.pause()
        }
        decBtn.setOnClickListener {
            prefs.edit().putBoolean("sw", !prefs.getBoolean("sw", false)).apply()
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            player.release()
            start(i, p)
            show(decBtn.text.toString() + " decoder")
        }
        findViewById<View>(R.id.lockBtn).setOnClickListener { setLock(true) }
        unlockBtn.setOnClickListener { setLock(false) }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) flashUnlock()
                else if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val d = if (e.x < pv.width / 2) -10_000L else 10_000L
                player.seekTo((player.currentPosition + d).coerceAtLeast(0))
                show(if (d < 0) "-10s" else "+10s")
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null) return false
                if (g == 0) g = if (abs(dx) > abs(dy)) 1 else if (e1.x < pv.width / 2) 2 else 3
                when (g) {
                    1 -> {
                        seekBy -= (dx * 80).toLong()
                        show((if (seekBy >= 0) "+" else "") + seekBy / 1000 + "s")
                    }
                    2 -> {
                        bright = (bright + dy / pv.height).coerceIn(0.01f, 1f)
                        window.attributes = window.attributes.also { it.screenBrightness = bright }
                        show("Brightness " + (bright * 100).toInt() + "%")
                    }
                    else -> {
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        vol = (vol + dy / pv.height * max).coerceIn(0f, max.toFloat())
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                        show("Volume " + vol.toInt() + "/" + max)
                    }
                }
                return true
            }
        })

        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (!locked) {
                    if (d.scaleFactor > 1.02f) pv.resizeMode = AR.RESIZE_MODE_ZOOM
                    else if (d.scaleFactor < 0.98f) pv.resizeMode = AR.RESIZE_MODE_FIT
                }
                return true
            }
        })

        pv.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (!sd.isInProgress) gd.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (g == 1 && seekBy != 0L) player.seekTo((player.currentPosition + seekBy).coerceAtLeast(0))
                g = 0; seekBy = 0
            }
            true
        }
    }

    /** Player banata hai. HW = default decoders, SW = sirf software decoders (na mile to default). */
    private fun start(index: Int, pos: Long) {
        val sw = prefs.getBoolean("sw", false)
        val selector = MediaCodecSelector { mime, secure, tunnel ->
            val l = MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel)
            if (sw) l.filter { it.softwareOnly }.ifEmpty { l } else l
        }
        player = ExoPlayer.Builder(
            this,
            DefaultRenderersFactory(this).setMediaCodecSelector(selector).setEnableDecoderFallback(true)
        ).build()
        pv.player = player
        player.addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(o: Player.PositionInfo, n: Player.PositionInfo, reason: Int) {
                // video poora khatam hoke next par gaya -> "Watched" mark
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) o.mediaItem?.let { mark(it, o.positionMs, o.positionMs) }
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                playBtn.setImageResource(if (playWhenReady) R.drawable.ic_pause else R.drawable.ic_play)
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                ttl.text = item?.mediaMetadata?.title
            }
        })
        player.setMediaItems(uris.indices.map { item(it) }, index, pos)
        player.prepare()
        player.play()
        ttl.text = player.currentMediaItem?.mediaMetadata?.title
        playBtn.setImageResource(R.drawable.ic_pause)
        decBtn.text = if (sw) "SW" else "HW"
    }

    private fun item(k: Int) = MediaItem.Builder().setUri(uris[k]).setMediaMetadata(
        MediaMetadata.Builder().setTitle(names?.getOrNull(k) ?: Uri.parse(uris[k]).lastPathSegment ?: "Video").build()
    ).apply { subs[k]?.let { setSubtitleConfigurations(listOf(it)) } }.build()

    // ---------- settings menu ----------
    private fun menu() {
        AlertDialog.Builder(this, DLG).setItems(arrayOf("Subtitles", "Video enhance", "Audio track", "Speed")) { _, i ->
            when (i) { 0 -> subPanel(); 1 -> enhPanel(); 2 -> pick(C.TRACK_TYPE_AUDIO); else -> speed() }
        }.show()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f
        setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { f() }
    }

    private fun toggle(t: String, k: String, on: () -> Unit) = btn("") {}.also { v ->
        val upd = { v.text = t + ": " + if (prefs.getBoolean(k, false)) "ON" else "OFF" }
        upd()
        v.setOnClickListener { prefs.edit().putBoolean(k, !prefs.getBoolean(k, false)).apply(); upd(); on() }
    }

    private fun bar(t: String, lo: Int, hi: Int, k: String, d: Int, on: () -> Unit): View {
        val cur = prefs.getInt(k, d)
        val tv = TextView(this).apply { setTextColor(Color.WHITE); text = "$t: $cur" }
        val seek = SeekBar(this).apply {
            max = hi - lo; progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    if (!u) return
                    prefs.edit().putInt(k, p + lo).apply(); tv.text = "$t: ${p + lo}"; on()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)); addView(tv); addView(seek)
        }
    }

    private fun panel(t: String, vararg v: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)); v.forEach { addView(it) }
        }
        dlg = AlertDialog.Builder(this, DLG).setTitle(t).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK", null).show()
        dlg?.window?.setDimAmount(0.15f)
    }

    // ---------- subtitles ----------
    private fun subPanel() = panel("Subtitles",
        btn("+  Load subtitle file (srt / ass / vtt)") { pickFile(1) },
        btn("Subtitle track") { dlg?.dismiss(); pick(C.TRACK_TYPE_TEXT) },
        bar("Size (sp)", 10, 48, "ss", 20) { applySub() },
        LinearLayout(this).apply {
            intArrayOf(Color.WHITE, 0xFFFFEB3B.toInt(), 0xFF4FC3F7.toInt(), 0xFF69F0AE.toInt(), 0xFFFF80AB.toInt(), 0xFFFFAB40.toInt()).forEach { c ->
                addView(View(context).apply {
                    setBackgroundColor(c)
                    layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(4), dp(8), dp(4), dp(8)) }
                    setOnClickListener { prefs.edit().putInt("sc", c).apply(); applySub() }
                })
            }
        },
        toggle("Background box", "sb") { applySub() },
        btn("Font from file (ttf / otf)") { pickFile(2) },
        btn("Default font") { prefs.edit().remove("sf").apply(); tf = null; applySub() })

    private fun applySub() {
        val sv = pv.subtitleView ?: return
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.getInt("ss", 20).toFloat())
        val bg = if (prefs.getBoolean("sb", false)) 0xAA000000.toInt() else Color.TRANSPARENT
        sv.setStyle(CaptionStyleCompat(prefs.getInt("sc", Color.WHITE), bg, Color.TRANSPARENT,
            CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, tf))
    }

    private fun loadFont() {
        tf = prefs.getString("sf", null)?.let { try { Typeface.createFromFile(it) } catch (e: Exception) { null } }
    }

    private fun pickFile(r: Int) {
        dlg?.dismiss()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), r)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data ?: return
        if (res != RESULT_OK) return
        if (r == 1) {
            val n = (contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: u.lastPathSegment ?: "").lowercase()
            val mt = when {
                n.endsWith(".vtt") -> MimeTypes.TEXT_VTT
                n.endsWith(".ass") || n.endsWith(".ssa") -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            subs[i] = MediaItem.SubtitleConfiguration.Builder(u).setMimeType(mt)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
            player.replaceMediaItem(i, item(i))
            player.seekTo(i, p)
            show("Subtitle added")
        } else {
            try {
                val f = File(filesDir, "font")
                contentResolver.openInputStream(u)?.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                prefs.edit().putString("sf", f.path).apply()
                loadFont(); applySub()
                show("Font set")
            } catch (e: Exception) { show("Font error") }
        }
        player.play()
    }

    private fun pick(type: Int) {
        val gs = player.currentTracks.groups.filter { it.type == type && it.isSupported }
        if (gs.isEmpty()) { show("No tracks"); return }
        val off = type == C.TRACK_TYPE_TEXT
        val names = (if (off) listOf("Off") else listOf<String>()) +
            gs.mapIndexed { n, g -> g.getTrackFormat(0).let { it.label ?: it.language ?: "Track ${n + 1}" } }
        AlertDialog.Builder(this, DLG).setItems(names.toTypedArray()) { _, i ->
            val k = if (off) i - 1 else i
            val tp = player.trackSelectionParameters.buildUpon().clearOverridesOfType(type).setTrackTypeDisabled(type, k < 0)
            if (k >= 0) tp.addOverride(TrackSelectionOverride(gs[k].mediaTrackGroup, 0))
            player.trackSelectionParameters = tp.build()
        }.show()
    }

    private fun speed() {
        val s = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        AlertDialog.Builder(this, DLG).setItems(s.map { "${it}x" }.toTypedArray()) { _, i ->
            player.setPlaybackSpeed(s[i]); show("${s[i]}x")
        }.show()
    }

    // ---------- video enhance (GPU colour matrix, no extra library) ----------
    private fun enhPanel() = panel("Video enhance",
        LinearLayout(this).apply {
            listOf("Normal" to intArrayOf(0, 100, 100), "Vivid" to intArrayOf(0, 110, 130),
                "Anime" to intArrayOf(4, 115, 145), "Cinema" to intArrayOf(-6, 112, 88)).forEach { (n, v) ->
                addView(btn(n) { setEnh(v[0], v[1], v[2]) }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f); gravity = Gravity.CENTER; textSize = 13f
                })
            }
        },
        bar("Brightness", -50, 50, "eb", 0) { applyEnh() },
        bar("Contrast %", 50, 150, "ec", 100) { applyEnh() },
        bar("Saturation %", 0, 200, "es", 100) { applyEnh() })

    private fun setEnh(b: Int, c: Int, s: Int) {
        prefs.edit().putInt("eb", b).putInt("ec", c).putInt("es", s).apply()
        applyEnh(); dlg?.dismiss(); enhPanel()
    }

    private fun applyEnh() {
        val b = prefs.getInt("eb", 0)
        val c = prefs.getInt("ec", 100) / 100f
        val m = ColorMatrix().apply { setSaturation(prefs.getInt("es", 100) / 100f) }
        val o = 128 * (1 - c) + b * 1.2f
        m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, o, 0f, c, 0f, 0f, o, 0f, 0f, c, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        pv.videoSurfaceView?.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
    }

    private fun setLock(on: Boolean) {
        locked = on
        pv.useController = !on
        unlockBtn.removeCallbacks(hideUnlock)
        if (on) flashUnlock() else unlockBtn.visibility = View.GONE
    }

    private fun flashUnlock() {
        unlockBtn.visibility = View.VISIBLE
        unlockBtn.removeCallbacks(hideUnlock)
        unlockBtn.postDelayed(hideUnlock, 2500)
    }

    private fun show(t: String) {
        info.removeCallbacks(hideInfo)
        info.text = t
        info.visibility = View.VISIBLE
        info.postDelayed(hideInfo, 800)
    }

    private fun mark(item: MediaItem, pos: Long, dur: Long) {
        val u = item.localConfiguration?.uri?.toString() ?: return
        History.save(this, u, pos, dur, folder, item.mediaMetadata.title?.toString() ?: "Video")
    }

    private fun save() {
        val item = player.currentMediaItem ?: return
        val d = player.duration
        if (d > 0) mark(item, player.currentPosition, d)
    }

    private fun pip() {
        enterPictureInPictureMode(PictureInPictureParams.Builder().build())
    }

    override fun onUserLeaveHint() {
        if (!locked && player.isPlaying) pip()
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        pv.useController = !inPip && !locked
    }

    override fun onStop() { super.onStop(); save(); player.pause() }
    override fun onDestroy() { super.onDestroy(); player.release() }
}
