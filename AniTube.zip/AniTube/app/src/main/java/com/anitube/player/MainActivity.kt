package com.anitube.player

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore.Video.Media
import android.provider.MediaStore.Video.Thumbnails
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class Video(val id: Long, val uri: String, val name: String, val dur: Long)

class MainActivity : Activity() {

    private val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    private val cache = LruCache<String, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(perm), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) load()
        else Toast.makeText(this, "Videos dikhane ke liye permission chahiye", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() { super.onDestroy(); pool.shutdownNow() }

    private fun load() {
        val videos = ArrayList<Video>()
        contentResolver.query(
            Media.EXTERNAL_CONTENT_URI,
            arrayOf(Media._ID, Media.DISPLAY_NAME, Media.DURATION),
            null, null, Media.DATE_ADDED + " DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                videos += Video(id, ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id).toString(),
                    c.getString(1) ?: "Video", c.getLong(2))
            }
        }

        val list = findViewById<ListView>(R.id.list)
        list.adapter = object : ArrayAdapter<Video>(this, R.layout.item_video, R.id.t1, videos) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val view = super.getView(i, v, p)
                val x = getItem(i)!!
                view.findViewById<TextView>(R.id.t1).text = x.name
                view.findViewById<TextView>(R.id.t2).text = "%d:%02d".format(x.dur / 60000, x.dur / 1000 % 60)
                thumb(x, view.findViewById(R.id.img))
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ ->
            val queue = videos.drop(i).take(100).map { it.uri }.toTypedArray()
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("uris", queue))
        }
    }

    @Suppress("DEPRECATION")
    private fun thumb(v: Video, iv: ImageView) {
        iv.tag = v.uri
        val hit = cache.get(v.uri)
        iv.setImageBitmap(hit)
        if (hit != null) return
        pool.execute {
            val bm = try {
                if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(Uri.parse(v.uri), Size(192, 120), null)
                else Thumbnails.getThumbnail(contentResolver, v.id, Thumbnails.MINI_KIND, null)
            } catch (e: Exception) { null }
            if (bm != null) {
                cache.put(v.uri, bm)
                runOnUiThread { if (iv.tag == v.uri) iv.setImageBitmap(bm) }
            }
        }
    }
}
