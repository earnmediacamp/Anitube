package com.anitube.player

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore.Video.Media
import android.provider.MediaStore.Video.Thumbnails
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class Video(val id: Long, val uri: String, val name: String, val dur: Long, val folder: String)
class Folder(val name: String, val videos: List<Video>)

class MainActivity : Activity() {

    private val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    private val cache = LruCache<String, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)
    private var folders = listOf<Folder>()
    private var openName: String? = null
    private val blue = 0xFF4FC3F7.toInt()
    private val grey = 0xFF777777.toInt()

    private lateinit var list: ListView
    private lateinit var title: TextView
    private lateinit var recent: android.widget.LinearLayout
    private lateinit var recentBox: View

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.list)
        title = findViewById(R.id.title)
        recent = findViewById(R.id.recent)
        recentBox = findViewById(R.id.recentBox)
        title.setOnClickListener { onBackPressed() }
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(perm), 1)
    }

    override fun onResume() {
        super.onResume()
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isEmpty() || r[0] != PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Videos dikhane ke liye permission chahiye", Toast.LENGTH_LONG).show()
    }

    override fun onBackPressed() {
        if (openName != null) { openName = null; render() } else super.onBackPressed()
    }

    override fun onDestroy() { super.onDestroy(); pool.shutdownNow() }

    // ---------- data ----------
    private fun load() {
        val all = ArrayList<Video>()
        contentResolver.query(
            Media.EXTERNAL_CONTENT_URI,
            arrayOf(Media._ID, Media.DISPLAY_NAME, Media.DURATION, Media.BUCKET_DISPLAY_NAME),
            null, null, Media.DATE_ADDED + " DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                all += Video(
                    id, ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id).toString(),
                    c.getString(1) ?: "Video", c.getLong(2), c.getString(3) ?: "Other"
                )
            }
        }
        folders = all.groupBy { it.folder }.map { Folder(it.key, it.value) }.sortedBy { it.name.lowercase() }
        render()
    }

    private fun render() {
        val f = folders.find { it.name == openName }
        if (f == null) { openName = null; showFolders() } else showVideos(f)
    }

    // ---------- folders screen ----------
    private fun showFolders() {
        title.text = "AniTube"
        val last = History.recent(this, 1).firstOrNull()?.folder
        list.adapter = object : ArrayAdapter<Folder>(this, R.layout.item_folder, R.id.t1, folders) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val view = super.getView(i, v, p)
                val f = getItem(i)!!
                val isLast = f.name == last
                view.findViewById<TextView>(R.id.t1).apply {
                    text = f.name
                    setTextColor(if (isLast) blue else 0xFFFFFFFF.toInt())
                }
                view.findViewById<TextView>(R.id.t2).text =
                    f.videos.size.toString() + if (f.videos.size == 1) " video" else " videos"
                view.findViewById<View>(R.id.last).visibility = if (isLast) View.VISIBLE else View.GONE
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ -> openName = folders[i].name; render() }
        showRecent()
    }

    private fun showRecent() {
        val byUri = HashMap<String, Video>()
        folders.forEach { f -> f.videos.forEach { byUri[it.uri] = it } }
        val items = History.recent(this, 20)
            .filter { it.dur > 0 && !History.finished(it) }
            .mapNotNull { e -> byUri[e.uri]?.let { e to it } }
            .take(8)

        recent.removeAllViews()
        for ((e, v) in items) {
            val card = layoutInflater.inflate(R.layout.item_recent, recent, false)
            card.findViewById<TextView>(R.id.t1).text = v.name
            card.findViewById<TextView>(R.id.t2).text = fmt(e.dur - e.pos) + " left"
            card.findViewById<ProgressBar>(R.id.bar).progress = (e.pos * 1000 / e.dur).toInt()
            thumb(v, card.findViewById(R.id.img))
            card.setOnClickListener {
                val f = folders.first { it.name == v.folder }
                play(f.videos, f.videos.indexOf(v))
            }
            recent.addView(card)
        }
        recentBox.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------- videos inside a folder ----------
    private fun showVideos(f: Folder) {
        title.text = "\u2039  " + f.name
        recentBox.visibility = View.GONE
        val lastUri = History.recent(this, 1).firstOrNull()?.uri
        list.adapter = object : ArrayAdapter<Video>(this, R.layout.item_video, R.id.t1, f.videos) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val view = super.getView(i, v, p)
                val x = getItem(i)!!
                val e = History.get(this@MainActivity, x.uri)
                val done = e != null && History.finished(e)
                val t3 = view.findViewById<TextView>(R.id.t3)
                val bar = view.findViewById<ProgressBar>(R.id.bar)

                view.findViewById<TextView>(R.id.t1).apply {
                    text = x.name
                    setTextColor(if (x.uri == lastUri) blue else if (done) grey else 0xFFFFFFFF.toInt())
                }
                view.findViewById<TextView>(R.id.t2).text = fmt(x.dur)
                if (e != null && e.dur > 0) {
                    bar.visibility = View.VISIBLE
                    bar.progress = if (done) 1000 else (e.pos * 1000 / e.dur).toInt()
                    t3.visibility = View.VISIBLE
                    t3.text = if (done) "Watched" else "Resume " + fmt(e.pos)
                    t3.setTextColor(if (done) grey else blue)
                } else {
                    bar.visibility = View.GONE
                    t3.visibility = View.GONE
                }
                thumb(x, view.findViewById(R.id.img))
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ -> play(f.videos, i) }
    }

    private fun play(videos: List<Video>, i: Int) {
        val q = videos.drop(i).take(100)
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra("uris", q.map { it.uri }.toTypedArray())
                .putExtra("names", q.map { it.name }.toTypedArray())
                .putExtra("folder", q[0].folder)
        )
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }

    // ---------- thumbnails ----------
    @Suppress("DEPRECATION")
    private fun thumb(v: Video, iv: ImageView) {
        iv.tag = v.uri
        val hit = cache.get(v.uri)
        iv.setImageBitmap(hit)
        if (hit != null) return
        pool.execute {
            val bm = try {
                if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(Uri.parse(v.uri), Size(192, 120), null)
                else Thumbnails.getThumbnail(contentResolver, v.id, Thumbnails.MINI_KIND, null)
            } catch (e: Exception) { null }
            if (bm != null) {
                cache.put(v.uri, bm)
                runOnUiThread { if (iv.tag == v.uri) iv.setImageBitmap(bm) }
            }
        }
    }
}
