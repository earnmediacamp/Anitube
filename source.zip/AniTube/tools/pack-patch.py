#!/usr/bin/env python3
"""bsdiff (BSDIFF40, bzip2) patch ko AniTube ke "APKPATCH" format me badalta hai.
Android me bzip2 nahi hota, isliye teeno blocks ko zlib (Deflate) me repack karte hain.
Use: pack-patch.py <raw.bsdiff> <out.patch>
Format: "APKPATCH"(8) | newSize(8) | ctrlLen(8) | diffLen(8) | extraLen(8)  (sab little-endian, len = compressed)
        | ctrl(zlib) | diff(zlib) | extra(zlib)
"""
import bz2, struct, sys, zlib

def offtin(b):
    y = int.from_bytes(b[:7] + bytes([b[7] & 0x7F]), "little")
    return -y if b[7] & 0x80 else y

def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    d = open(sys.argv[1], "rb").read()
    if d[:8] != b"BSDIFF40":
        sys.exit("BSDIFF40 patch nahi hai")
    cl, dl, new = offtin(d[8:16]), offtin(d[16:24]), offtin(d[24:32])
    ctrl = bz2.decompress(d[32:32 + cl])
    diff = bz2.decompress(d[32 + cl:32 + cl + dl])
    extra = bz2.decompress(d[32 + cl + dl:]) if len(d) > 32 + cl + dl else b""
    c, df, e = (zlib.compress(x, 9) for x in (ctrl, diff, extra))
    out = b"APKPATCH" + struct.pack("<QQQQ", new, len(c), len(df), len(e)) + c + df + e
    open(sys.argv[2], "wb").write(out)
    print("patch: %d bytes (new apk %d bytes)" % (len(out), new))

main()
