#!/bin/sh
# Ek baar chalao: apni release key banata hai (anitube-release.jks). Is file + password ka BACKUP zaroor rakho.
keytool -genkeypair -v -keystore anitube-release.jks -alias anitube -keyalg RSA -keysize 2048 -validity 10000
echo "Ab keystore.properties.example ko keystore.properties naam se copy karke password bharo."
