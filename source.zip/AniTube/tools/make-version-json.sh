#!/bin/sh
# Use: tools/make-version-json.sh <versionCode> <versionName> <apkFile> "<changelog>"
# version.json banata hai (APK ka SHA-256 ke saath). Isko GitHub Release me APK ke saath upload karo.
[ $# -lt 3 ] && { echo "Use: $0 <versionCode> <versionName> <apkFile> changelog"; exit 1; }
REPO=$(grep -o 'REPO = "[^"]*"' app/src/main/java/com/anitube/player/Updater.kt | cut -d'"' -f2)
if command -v sha256sum >/dev/null 2>&1; then SHA=$(sha256sum "$3" | cut -d' ' -f1); else SHA=$(shasum -a 256 "$3" | cut -d' ' -f1); fi
cat > version.json <<EOF
{
  "versionCode": $1,
  "versionName": "$2",
  "apkUrl": "https://github.com/$REPO/releases/download/v$2/$(basename "$3")",
  "sha256": "$SHA",
  "changelog": "$4"
}
EOF
cat version.json
