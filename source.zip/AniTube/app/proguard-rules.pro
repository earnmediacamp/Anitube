# libass (ass-media / ass-kt): native (JNI) + reflection ke liye
-keep class io.github.peerless2012.ass.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn io.github.peerless2012.**

# NextLib (ffmpeg decoders): JNI inhe naam se dhoondta hai
-keep class io.github.anilbeesetti.nextlib.** { *; }
-dontwarn io.github.anilbeesetti.**
# media3 decoder buffers: native code in fields ko naam se access karta hai
-keep class androidx.media3.decoder.** { *; }
# HLS: DefaultMediaSourceFactory reflection se load karta hai
-keep class androidx.media3.exoplayer.hls.** { *; }
