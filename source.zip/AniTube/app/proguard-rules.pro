# libass (ass-media / ass-kt): native (JNI) + reflection ke liye
-keep class io.github.peerless2012.ass.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn io.github.peerless2012.**
