Yahan koi bhi .ttf / .otf font file daalo (jaise Montserrat-Regular.ttf, OpenSans-Regular.ttf, Lato-Regular.ttf).
Player ke Fonts popup me wo apne aap list me aa jayegi (file ke naam se). Code badalne ki zaroorat nahi.
Poppins: SIL Open Font License.
