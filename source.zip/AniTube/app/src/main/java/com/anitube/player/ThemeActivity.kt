package com.anitube.player

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** App Theme screen: Adaptive / Light / Dark cards + Classic accent colours (light ya dark ke saath). */
class ThemeActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("set", MODE_PRIVATE) }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun attr(a: Int): Int { val tv = TypedValue(); theme.resolveAttribute(a, tv, true); return tv.data }

    override fun onCreate(b: Bundle?) {
        setTheme(if (Themes.light(this)) R.style.Theme_AniTube_Light else R.style.Theme_AniTube)
        Themes.applyAccent(this)
        super.onCreate(b)
        val txt = attr(R.attr.appText); val txt2 = attr(R.attr.appText2); val acc = attr(R.attr.appAccent)
        val mode = prefs.getInt("theme", 0)
        val accIdx = prefs.getInt("acc", -1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(28)) }

        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_back); setColorFilter(txt); setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)); setOnClickListener { finish() }
            })
            addView(TextView(context).apply {
                text = "App Theme"; setTextColor(txt); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, 0, 0)
            })
        })

        fun modeCard(label: String, m: Int, c1: Int, c2: Int, tc: Int, resetAccent: Boolean, first: Boolean): View = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(104), 1f).apply { if (!first) marginStart = dp(10) }
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
                cornerRadius = dp(18).toFloat(); if (mode == m) setStroke(dp(2), acc)
            }
            addView(TextView(context).apply {
                text = label; setTextColor(tc); textSize = 17f; setPadding(dp(14), dp(14), dp(10), dp(14)); gravity = Gravity.CENTER_VERTICAL
                layoutParams = FrameLayout.LayoutParams(-1, -1)
            })
            if (mode == m) addView(TextView(context).apply {
                text = "Using"; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(10), dp(3), dp(10), dp(3))
                background = GradientDrawable().apply { setColor(0xFF2ECC71.toInt()); cornerRadius = dp(10).toFloat() }
                layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(6), dp(8), 0) }
            })
            setOnClickListener {
                prefs.edit().putInt("theme", m).apply { if (resetAccent) putInt("acc", -1) }.apply()
                recreate()
            }
        }
        root.addView(LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
            addView(modeCard("Adaptive", 2, 0xFFB9D8FF.toInt(), 0xFFDCEBFF.toInt(), 0xFF22304A.toInt(), false, true))
            addView(modeCard("Light Theme", 1, 0xFFF4F8FF.toInt(), 0xFFDDEBFA.toInt(), 0xFF22304A.toInt(), true, false))
            addView(modeCard("Dark Theme", 0, 0xFF2B2F36.toInt(), 0xFF07090D.toInt(), Color.WHITE, true, false))
        })

        root.addView(TextView(this).apply {
            text = "Classic Themes"; setTextColor(txt); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(2), dp(26), 0, dp(12))
        })
        root.addView(TextView(this).apply {
            text = "Full colour = Light theme  \u00B7  half dark = Dark theme"; setTextColor(txt2); textSize = 12f
            setPadding(dp(2), 0, 0, dp(12))
        })

        val gap = dp(10)
        val tile = ((resources.displayMetrics.widthPixels - dp(32) - gap * 5) / 6).coerceAtLeast(dp(40))
        val r = dp(14).toFloat()
        fun tileView(i: Int, dark: Boolean): View {
            val c = Themes.ACCENTS[i]
            val on = accIdx == i && ((mode == 1 && !dark) || (mode == 0 && dark))
            val v = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(tile, tile).apply { marginEnd = gap; bottomMargin = gap }
                if (!dark) background = GradientDrawable().apply { setColor(c); cornerRadius = r }
                else {
                    addView(View(context).apply {
                        background = GradientDrawable().apply { setColor(0xFF1C2A3C.toInt()); cornerRadius = r }
                    }, FrameLayout.LayoutParams(-1, -1))
                    addView(View(context).apply {
                        background = GradientDrawable().apply { setColor(c); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
                    }, FrameLayout.LayoutParams(-1, tile / 2))
                }
                if (on) {
                    foreground = GradientDrawable().apply { setColor(Color.TRANSPARENT); cornerRadius = r; setStroke(dp(3), txt) }
                    addView(TextView(context).apply {
                        text = "\u2713"; setTextColor(if (dark) Color.WHITE else 0xFF111111.toInt()); textSize = 20f; gravity = Gravity.CENTER
                        typeface = Typeface.DEFAULT_BOLD
                    }, FrameLayout.LayoutParams(-1, -1))
                }
                setOnClickListener { prefs.edit().putInt("theme", if (dark) 0 else 1).putInt("acc", i).apply(); recreate() }
            }
            return v
        }
        for (group in 0..1) {
            for (rowStart in 0 until Themes.ACCENTS.size step 6) {
                root.addView(LinearLayout(this).apply {
                    for (i in rowStart until minOf(rowStart + 6, Themes.ACCENTS.size)) addView(tileView(i, group == 1))
                })
            }
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }
}
