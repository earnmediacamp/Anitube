package com.anitube.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/**
 * In-app updater (GitHub Releases).
 * Har release me 2 files upload hoti hain: AniTube APK + version.json (tools/make-version-json.sh banata hai).
 */
object Updater {
    /** <-- APNA GitHub "username/repo" yahan likho */
    const val REPO = "earnmediacamp/Anitube"

    private const val JSON_URL = "https://github.com/$REPO/releases/latest/download/version.json"

    class Info(val code: Long, val name: String, val url: String, val sha: String, val log: String)

    private var pending: Info? = null
    @Volatile private var busy = false

    @Suppress("DEPRECATION")
    fun curCode(c: Context): Long {
        val p = c.packageManager.getPackageInfo(c.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()
    }

    fun curName(c: Context): String = c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""

    private fun toast(a: Activity, t: String) = Toast.makeText(a, t, Toast.LENGTH_LONG).show()

    /** manual = true: button se (throttle / skip ignore). false: app khulte hi, din me ek baar. */
    fun check(a: Activity, manual: Boolean) {
        if (REPO.startsWith("YOUR_")) {
            if (manual) toast(a, "Updater.kt me REPO set karo (username/repo)")
            return
        }
        val sp = a.getSharedPreferences("set", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!manual && now - sp.getLong("updchk", 0L) < 24L * 3600 * 1000) return
        if (busy) return
        busy = true
        Thread {
            var err = false
            var found: Info? = null
            try { found = fetch() } catch (e: Exception) { err = true }
            val info = found
            val failed = err
            busy = false
            a.runOnUiThread {
                if (a.isFinishing || a.isDestroyed) return@runOnUiThread
                if (!failed) sp.edit().putLong("updchk", now).apply()
                when {
                    failed -> if (manual) toast(a, "Update check nahi ho paya (internet?)")
                    info == null || info.code <= curCode(a) ->
                        if (manual) toast(a, "Latest version hai (v" + curName(a) + ")")
                    !manual && sp.getLong("skipv", 0L) == info.code -> {}
                    else -> offer(a, info)
                }
                Unit
            }
        }.start()
    }

    private fun fetch(): Info? {
        val con = URL(JSON_URL).openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 8000
        try {
            if (con.responseCode != 200) return null      // abhi koi release nahi
            val j = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
            return Info(
                j.getLong("versionCode"), j.optString("versionName"), j.getString("apkUrl"),
                j.optString("sha256"), j.optString("changelog")
            )
        } finally { con.disconnect() }
    }

    private fun offer(a: Activity, i: Info) {
        AlertDialog.Builder(a, Themes.dialog(a))
            .setTitle("Update available: v" + i.name)
            .setMessage(if (i.log.isBlank()) "Naya version aaya hai." else i.log.replace("\\n", "\n"))
            .setPositiveButton("Update") { _, _ -> start(a, i) }
            .setNegativeButton("Later", null)
            .setNeutralButton("Skip") { _, _ ->
                a.getSharedPreferences("set", Context.MODE_PRIVATE).edit().putLong("skipv", i.code).apply()
            }.show()
    }

    private fun start(a: Activity, i: Info) {
        if (Build.VERSION.SDK_INT >= 26 && !a.packageManager.canRequestPackageInstalls()) {
            pending = i
            AlertDialog.Builder(a, Themes.dialog(a)).setTitle("Permission chahiye")
                .setMessage("Update install karne ke liye AniTube ko \"Allow from this source\" ON karo, phir wapas aao. Download apne aap shuru ho jayega.")
                .setPositiveButton("Open settings") { _, _ ->
                    a.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.packageName)))
                }
                .setNegativeButton("Cancel") { _, _ -> pending = null }.show()
            return
        }
        pending = null
        download(a, i)
    }

    /** MainActivity.onResume se: settings me permission dekar wapas aane par download shuru. */
    fun resume(a: Activity) {
        val p = pending ?: return
        if (Build.VERSION.SDK_INT < 26 || a.packageManager.canRequestPackageInstalls()) {
            pending = null
            download(a, p)
        }
    }

    private fun download(a: Activity, i: Info) {
        val dir = File(a.cacheDir, "update").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "AniTube-" + i.name + ".apk")
        val d = a.resources.displayMetrics.density
        val tv = TextView(a).apply { setTextColor(if (Themes.light(a)) 0xFF15151C.toInt() else 0xFFFFFFFF.toInt()); text = "0%" }
        val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (12 * d).toInt(), (20 * d).toInt(), (12 * d).toInt())
            addView(tv); addView(bar)
        }
        val cancel = AtomicBoolean(false)
        val dlg = AlertDialog.Builder(a, Themes.dialog(a)).setTitle("Downloading update").setView(box)
            .setCancelable(false).setNegativeButton("Cancel") { _, _ -> cancel.set(true) }.show()

        Thread {
            var ok = false
            var msg = "Download nahi hua"
            try {
                val con = URL(i.url).openConnection() as HttpURLConnection
                con.connectTimeout = 15000
                con.readTimeout = 15000
                val total = con.contentLengthLong
                val md = MessageDigest.getInstance("SHA-256")
                con.inputStream.use { ins ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var last = -1
                        while (true) {
                            if (cancel.get()) throw InterruptedException()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            md.update(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) { last = p; a.runOnUiThread { bar.progress = p; tv.text = "$p%" } }
                            }
                        }
                    }
                }
                val hex = md.digest().joinToString("") { "%02x".format(it) }
                if (i.sha.isNotBlank() && !hex.equals(i.sha.trim(), true)) {
                    msg = "File kharab hai (SHA mismatch), dobara try karo"
                    f.delete()
                } else ok = true
            } catch (e: InterruptedException) {
                msg = "Cancelled"; f.delete()
            } catch (e: Exception) {
                f.delete()
            }
            val good = ok
            val m = msg
            a.runOnUiThread {
                if (a.isFinishing || a.isDestroyed) return@runOnUiThread
                dlg.dismiss()
                if (good) install(a, f) else toast(a, m)
            }
        }.start()
    }

    private fun install(a: Activity, f: File) {
        try {
            val u = FileProvider.getUriForFile(a, a.packageName + ".fileprovider", f)
            a.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) { toast(a, "Install screen nahi khuli") }
    }
}
