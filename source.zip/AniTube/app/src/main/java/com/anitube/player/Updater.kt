package com.anitube.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/**
 * In-app updater (GitHub Releases).
 * Har release me 2 files upload hoti hain: AniTube APK + version.json (tools/make-version-json.sh banata hai).
 */
object Updater {
    /** <-- APNA GitHub "username/repo" yahan likho */
    const val REPO = "earnmediacamp/Anitube"

    private const val JSON_URL = "https://github.com/$REPO/releases/latest/download/version.json"

    class Info(val code: Long, val name: String, val url: String, val sha: String, val log: String, val bytes: Long,
                val patchUrl: String = "", val patchFrom: Long = -1L, val patchBytes: Long = 0L, val patchSha: String = "")

    private var pending: Info? = null
    @Volatile private var busy = false

    @Suppress("DEPRECATION")
    fun curCode(c: Context): Long {
        val p = c.packageManager.getPackageInfo(c.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()
    }

    fun curName(c: Context): String = c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""

    private fun toast(a: Activity, t: String) = Toast.makeText(a, t, Toast.LENGTH_LONG).show()

    /** manual = true: button se (throttle / skip ignore). false: app khulte hi, din me ek baar. */
    fun check(a: Activity, manual: Boolean) {
        if (REPO.startsWith("YOUR_")) {
            if (manual) toast(a, "Updater.kt me REPO set karo (username/repo)")
            return
        }
        val sp = a.getSharedPreferences("set", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!manual && now - sp.getLong("updchk", 0L) < 24L * 3600 * 1000) return
        if (busy) return
        busy = true
        Thread {
            var err = false
            var found: Info? = null
            try { found = fetch() } catch (e: Exception) { err = true }
            val info = found
            val failed = err
            busy = false
            a.runOnUiThread {
                if (a.isFinishing || a.isDestroyed) return@runOnUiThread
                if (!failed) sp.edit().putLong("updchk", now).apply()
                when {
                    failed -> if (manual) toast(a, "Update check nahi ho paya (internet?)")
                    info == null || info.code <= curCode(a) ->
                        if (manual) toast(a, "Latest version hai (v" + curName(a) + ")")
                    !manual && sp.getLong("skipv", 0L) == info.code -> {}
                    else -> offer(a, info)
                }
                Unit
            }
        }.start()
    }

    private fun fetch(): Info? {
        val con = URL(JSON_URL).openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 8000
        try {
            if (con.responseCode != 200) return null      // abhi koi release nahi
            val j = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
            val url = j.getString("apkUrl")
            var bytes = j.optLong("sizeBytes", 0L)
            if (bytes <= 0L) bytes = remoteSize(url)      // purani version.json me size nahi hota: APK se pucho
            val pj = j.optJSONObject("patch")
            return Info(
                j.getLong("versionCode"), j.optString("versionName"), url,
                j.optString("sha256"), j.optString("changelog"), bytes,
                pj?.optString("url") ?: "", pj?.optLong("fromCode", -1L) ?: -1L,
                pj?.optLong("sizeBytes", 0L) ?: 0L, pj?.optString("sha256") ?: ""
            )
        } finally { con.disconnect() }
    }

    /** APK ka size (bytes) HEAD request se. Na mile to 0. */
    private fun remoteSize(url: String): Long {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = "HEAD"
                c.connectTimeout = 8000
                c.readTimeout = 8000
                if (c.responseCode == 200) c.contentLengthLong.coerceAtLeast(0L) else 0L
            } finally { c.disconnect() }
        } catch (e: Exception) { 0L }
    }

    private fun offer(a: Activity, i: Info) {
        val full = VideoInfo.size(i.bytes).ifEmpty { "unknown" }
        val sizeLine = if (canPatch(a, i))
            "Update download size: " + VideoInfo.size(i.patchBytes) + " (patch)\nFull APK size: " + full
        else "Update download size: " + full
        val head = "Current version: v" + curName(a) + "\nNew version: v" + i.name + "\n" + sizeLine
        val notes = if (i.log.isBlank()) "Naya version aaya hai." else i.log.replace("\\n", "\n")
        AlertDialog.Builder(a, Themes.dialog(a))
            .setTitle("Update available: v" + i.name)
            .setMessage(head + "\n\nWHAT'S NEW\n" + notes)
            .setPositiveButton("Update") { _, _ -> start(a, i) }
            .setNegativeButton("Later", null)
            .setNeutralButton("Skip") { _, _ ->
                a.getSharedPreferences("set", Context.MODE_PRIVATE).edit().putLong("skipv", i.code).apply()
            }.show()
    }

    private fun start(a: Activity, i: Info) {
        if (Build.VERSION.SDK_INT >= 26 && !a.packageManager.canRequestPackageInstalls()) {
            pending = i
            AlertDialog.Builder(a, Themes.dialog(a)).setTitle("Permission chahiye")
                .setMessage("Update install karne ke liye AniTube ko \"Allow from this source\" ON karo, phir wapas aao. Download apne aap shuru ho jayega.")
                .setPositiveButton("Open settings") { _, _ ->
                    a.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.packageName)))
                }
                .setNegativeButton("Cancel") { _, _ -> pending = null }.show()
            return
        }
        pending = null
        download(a, i)
    }

    /** MainActivity.onResume se: settings me permission dekar wapas aane par download shuru. */
    fun resume(a: Activity) {
        val p = pending ?: return
        if (Build.VERSION.SDK_INT < 26 || a.packageManager.canRequestPackageInstalls()) {
            pending = null
            download(a, p)
        }
    }

    /** Patch tabhi, jab ye phone isi version par hai jis se patch bana hai. */
    private fun canPatch(a: Activity, i: Info): Boolean =
        i.patchUrl.isNotBlank() && i.patchBytes > 0 && i.patchFrom == curCode(a)

    private fun hex(md: MessageDigest) = md.digest().joinToString("") { "%02x".format(it) }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = ins.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return hex(md)
    }

    /** url -> out file. SHA-256 (hex) return karta hai. prog(done, total) har percent badalne par. */
    private fun fetchTo(url: String, out: File, total0: Long, cancel: AtomicBoolean, prog: (Long, Long) -> Unit): String {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 15000
        con.readTimeout = 15000
        try {
            val total = con.contentLengthLong.let { if (it > 0) it else total0 }
            val md = MessageDigest.getInstance("SHA-256")
            con.inputStream.use { ins ->
                out.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    var got = 0L
                    var last = -1
                    while (true) {
                        if (cancel.get()) throw InterruptedException()
                        val n = ins.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        md.update(buf, 0, n)
                        got += n
                        if (total > 0) {
                            val p = (got * 100 / total).toInt()
                            if (p != last) { last = p; prog(got, total) }
                        }
                    }
                }
            }
            return hex(md)
        } finally { con.disconnect() }
    }

    private fun download(a: Activity, i: Info) {
        val dir = File(a.cacheDir, "update").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "AniTube-" + i.name + ".apk")
        val pf = File(dir, "update.patch")
        val d = a.resources.displayMetrics.density
        val tv = TextView(a).apply { setTextColor(if (Themes.light(a)) 0xFF15151C.toInt() else 0xFFFFFFFF.toInt()); text = "0%" }
        val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (12 * d).toInt(), (20 * d).toInt(), (12 * d).toInt())
            addView(tv); addView(bar)
        }
        val cancel = AtomicBoolean(false)
        val patchMode = canPatch(a, i)
        val dlg = AlertDialog.Builder(a, Themes.dialog(a)).setTitle(if (patchMode) "Downloading update patch" else "Downloading update").setView(box)
            .setCancelable(false).setNegativeButton("Cancel") { _, _ -> cancel.set(true) }.show()

        val prog = { got: Long, tot: Long ->
            val p = (got * 100 / tot).toInt()
            a.runOnUiThread { bar.progress = p; tv.text = "$p%  \u00B7  " + VideoInfo.size(got) + " / " + VideoInfo.size(tot) }
            Unit
        }

        Thread {
            var ok = false
            var msg = "Download nahi hua"
            try {
                var done = false
                if (patchMode) {
                    try {
                        val h = fetchTo(i.patchUrl, pf, i.patchBytes, cancel, prog)
                        if (i.patchSha.isNotBlank() && !h.equals(i.patchSha.trim(), true)) throw java.io.IOException("patch sha")
                        a.runOnUiThread { tv.text = "Patch laga raha hu..."; bar.isIndeterminate = true }
                        ApkPatch.apply(File(a.applicationInfo.sourceDir), pf, f)
                        if (i.sha.isNotBlank() && !sha256(f).equals(i.sha.trim(), true)) throw java.io.IOException("apk sha")
                        done = true
                    } catch (e: InterruptedException) {
                        throw e
                    } catch (e: Throwable) {
                        // patch fail: poora APK download karte hain
                        f.delete(); pf.delete()
                        a.runOnUiThread {
                            dlg.setTitle("Downloading update")
                            bar.isIndeterminate = false; bar.progress = 0; tv.text = "0%"
                        }
                    }
                }
                if (!done) {
                    val h = fetchTo(i.url, f, i.bytes, cancel, prog)
                    if (i.sha.isNotBlank() && !h.equals(i.sha.trim(), true)) {
                        msg = "File kharab hai (SHA mismatch), dobara try karo"
                        f.delete()
                    } else done = true
                }
                ok = done
            } catch (e: InterruptedException) {
                msg = "Cancelled"; f.delete()
            } catch (e: Exception) {
                f.delete()
            }
            pf.delete()
            val good = ok
            val m = msg
            a.runOnUiThread {
                if (a.isFinishing || a.isDestroyed) return@runOnUiThread
                dlg.dismiss()
                if (good) install(a, f) else toast(a, m)
            }
        }.start()
    }

    private fun install(a: Activity, f: File) {
        try {
            val u = FileProvider.getUriForFile(a, a.packageName + ".fileprovider", f)
            a.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) { toast(a, "Install screen nahi khuli") }
    }
}
