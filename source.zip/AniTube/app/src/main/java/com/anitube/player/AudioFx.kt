package com.anitube.player

import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer

/** Equalizer + volume boost (LoudnessEnhancer), player ke audio session par. Phone support na kare to chupchaap band. */
class AudioFx {
    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null

    fun attach(sessionId: Int) {
        release()
        if (sessionId == 0) return
        try { eq = Equalizer(0, sessionId) } catch (e: Exception) { eq = null }
        try { loud = LoudnessEnhancer(sessionId) } catch (e: Exception) { loud = null }
    }

    fun release() {
        try { eq?.release() } catch (e: Exception) { }
        try { loud?.release() } catch (e: Exception) { }
        eq = null; loud = null
    }

    fun bands(): Int = eq?.numberOfBands?.toInt() ?: 0

    /** Band level range in millibel. */
    fun rangeMb(): Pair<Int, Int> = try {
        eq?.bandLevelRange?.let { it[0].toInt() to it[1].toInt() } ?: (-1500 to 1500)
    } catch (e: Exception) { -1500 to 1500 }

    fun freqHz(b: Int): Int = try { (eq?.getCenterFreq(b.toShort()) ?: 0) / 1000 } catch (e: Exception) { 0 }

    /** eqDb: har band ka dB level, boostDb: 0..15 dB. */
    fun apply(eqOn: Boolean, eqDb: IntArray, boostDb: Int) {
        try {
            eq?.let { e ->
                val (lo, hi) = rangeMb()
                for (i in 0 until minOf(eqDb.size, e.numberOfBands.toInt())) {
                    e.setBandLevel(i.toShort(), (eqDb[i] * 100).coerceIn(lo, hi).toShort())
                }
                e.enabled = eqOn
            }
        } catch (e: Exception) { }
        try {
            loud?.let { l ->
                l.setTargetGain(boostDb * 100)
                l.enabled = boostDb > 0
            }
        } catch (e: Exception) { }
    }
}
