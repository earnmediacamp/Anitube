package com.anitube.player

import java.net.HttpURLConnection
import java.net.URL

/**
 * Network link ka type pehchanta hai (jab URL me .m3u8 / .mp4 jaisa extension na ho, jaise ".../ab-ODX3wbdQ").
 * Bina iske ExoPlayer har extension-less link ko plain file maan leta hai aur HLS/DASH par
 * ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED deta hai.
 */
object NetProbe {
    const val HTML = "text/html"
    private const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** Return: "application/x-mpegURL" (HLS), "application/dash+xml" (DASH), HTML (webpage, video nahi), ya null (normal file / pata nahi). */
    fun sniff(url: String): String? = try {
        var cur = url
        var result: String? = null
        for (hop in 0..5) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000; c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Range", "bytes=0-4095")
            val code = c.responseCode
            if (code in 300..399) {                       // http -> https redirects bhi follow (HttpURLConnection khud nahi karta)
                val loc = c.getHeaderField("Location"); c.disconnect()
                if (loc.isNullOrBlank()) break
                cur = URL(URL(cur), loc).toString(); continue
            }
            val ct = (c.contentType ?: "").lowercase()
            val head = try {
                (if (code >= 400) c.errorStream else c.inputStream)?.use { ins ->
                    val b = ByteArray(4096); val n = ins.read(b)
                    if (n > 0) String(b, 0, n, Charsets.ISO_8859_1) else ""
                } ?: ""
            } catch (e: Exception) { "" }
            c.disconnect()
            val t = head.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
            result = when {
                t.startsWith("#EXTM3U") || ct.contains("mpegurl") -> "application/x-mpegURL"
                ct.contains("dash+xml") || t.contains("<MPD", true) -> "application/dash+xml"
                code < 400 && (ct.startsWith("text/html") || t.startsWith("<!doctype html", true) || t.startsWith("<html", true)) -> HTML
                else -> null
            }
            break
        }
        result
    } catch (e: Exception) { null }
}
