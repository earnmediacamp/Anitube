package com.anitube.player

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.MediaStore.Video.Media
import android.provider.OpenableColumns
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** Properties / info + share, MainActivity aur PlayerActivity dono use karte hain. */
object VideoInfo {

    fun size(b: Long): String {
        if (b <= 0) return ""
        val u = arrayOf("B", "KB", "MB", "GB")
        var d = b.toDouble()
        var i = 0
        while (d >= 1024 && i < 3) { d /= 1024; i++ }
        return String.format(Locale.US, if (i == 0) "%.0f %s" else "%.2f %s", d, u[i])
    }

    fun dur(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
        else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    fun summary(vs: List<Video>): String =
        "Videos: ${vs.size}\nTotal size: ${size(vs.sumOf { it.size })}\nTotal duration: ${dur(vs.sumOf { it.dur })}"

    @Suppress("DEPRECATION")
    fun describe(c: Context, uri: Uri): String {
        val sb = StringBuilder()
        fun add(k: String, v: String?) { if (!v.isNullOrBlank()) sb.append(k).append(": ").append(v).append('\n') }

        var name: String? = null; var sz = 0L; var d = 0L; var w = 0; var h = 0
        var added = 0L; var path: String? = null; var mime: String? = null; var bucket: String? = null
        try {
            c.contentResolver.query(uri, arrayOf(Media.DISPLAY_NAME, Media.SIZE, Media.DURATION, Media.WIDTH,
                Media.HEIGHT, Media.DATE_ADDED, Media.DATA, Media.MIME_TYPE, Media.BUCKET_DISPLAY_NAME), null, null, null)
                ?.use {
                    if (it.moveToFirst()) {
                        name = it.getString(0); sz = it.getLong(1); d = it.getLong(2); w = it.getInt(3); h = it.getInt(4)
                        added = it.getLong(5); path = it.getString(6); mime = it.getString(7); bucket = it.getString(8)
                    }
                }
        } catch (e: Exception) {
            try {   // media store ke bahar ka content uri
                c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                    ?.use { if (it.moveToFirst()) { name = it.getString(0); sz = it.getLong(1) } }
            } catch (e2: Exception) { }
        }
        add("Name", name ?: uri.lastPathSegment)
        add("Folder", bucket)
        add("Path", path ?: uri.toString())
        add("Size", size(sz))
        if (d > 0) add("Duration", dur(d))
        if (w > 0 && h > 0) add("Resolution", "$w x $h")
        if (added > 0) add("Added", DateFormat.getDateTimeInstance().format(Date(added * 1000)))
        add("Type", mime)

        try {
            val ex = MediaExtractor()
            try {
                ex.setDataSource(c, uri, null)
                var audio = 0; var subs = 0
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                    when {
                        m.startsWith("video/") -> {
                            add("Video codec", m.removePrefix("video/"))
                            num(f, MediaFormat.KEY_FRAME_RATE)?.let { add("Frame rate", String.format(Locale.US, "%.2f fps", it)) }
                            num(f, MediaFormat.KEY_BIT_RATE)?.let { add("Video bitrate", String.format(Locale.US, "%.0f kbps", it / 1000)) }
                        }
                        m.startsWith("audio/") -> {
                            audio++
                            val lang = if (f.containsKey(MediaFormat.KEY_LANGUAGE)) f.getString(MediaFormat.KEY_LANGUAGE) else null
                            val ch = num(f, MediaFormat.KEY_CHANNEL_COUNT)?.toInt()
                            val sr = num(f, MediaFormat.KEY_SAMPLE_RATE)?.toInt()
                            add("Audio $audio", listOfNotNull(m.removePrefix("audio/"), lang, ch?.let { "$it ch" }, sr?.let { "$it Hz" })
                                .joinToString(", "))
                        }
                        else -> subs++
                    }
                }
                if (subs > 0) add("Other/subtitle tracks", subs.toString())
            } finally { ex.release() }
        } catch (e: Exception) { }
        return sb.toString().trim()
    }

    private fun num(f: MediaFormat, key: String): Double? {
        if (!f.containsKey(key)) return null
        return try { f.getInteger(key).toDouble() } catch (e: Exception) {
            try { f.getFloat(key).toDouble() } catch (e2: Exception) { null }
        }
    }

    fun share(c: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val web = uris[0].scheme == "http" || uris[0].scheme == "https"
        val i = when {
            web -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, uris[0].toString())
            uris.size == 1 -> Intent(Intent.ACTION_SEND).setType("video/*").putExtra(Intent.EXTRA_STREAM, uris[0])
            else -> Intent(Intent.ACTION_SEND_MULTIPLE).setType("video/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        if (!web) {
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val cd = ClipData.newRawUri("", uris[0])
            uris.drop(1).forEach { cd.addItem(ClipData.Item(it)) }
            i.clipData = cd
        }
        val chooser = Intent.createChooser(i, "Share")
        if (c !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(chooser)
    }
}
