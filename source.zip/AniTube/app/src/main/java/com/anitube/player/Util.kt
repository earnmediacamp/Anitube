package com.anitube.player

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.media.MediaExtractor
import android.media.MediaFormat
import android.graphics.Typeface
import android.net.Uri
import android.provider.MediaStore.Video.Media
import android.provider.OpenableColumns
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** Library theme: 0 = Dark, 1 = Light, 2 = Follow system. Player hamesha dark rehta hai. */
object Themes {
    fun light(c: Context): Boolean {
        val t = c.getSharedPreferences("set", Context.MODE_PRIVATE).getInt("theme", 0)
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        return t == 1 || (t == 2 && !night)
    }
    fun dialog(c: Context): Int = if (light(c)) R.style.Theme_AniTube_Dialog_Light else R.style.Theme_AniTube_Dialog

    /** Classic theme accent colours (index = prefs "acc", -1 = default blue). */
    val ACCENTS: IntArray = longArrayOf(0xFFFA6150, 0xFFFF9B57, 0xFFFFC73A, 0xFFA06850, 0xFFCFD718, 0xFFA2DB54, 0xFF52CE62, 0xFF1BC592,
        0xFF4EB5E8, 0xFF5088E0, 0xFF5367E8, 0xFF9966EE, 0xFFD95BE8, 0xFFFF4F8D, 0xFFE84793, 0xFFDDE1E4).map { it.toInt() }.toIntArray()
    private val ACC_STYLES = intArrayOf(R.style.Accent0, R.style.Accent1, R.style.Accent2, R.style.Accent3, R.style.Accent4, R.style.Accent5,
        R.style.Accent6, R.style.Accent7, R.style.Accent8, R.style.Accent9, R.style.Accent10, R.style.Accent11, R.style.Accent12,
        R.style.Accent13, R.style.Accent14, R.style.Accent15)

    /** Chuna hua accent colour activity ke theme par lagao (setTheme ke baad, setContentView se pehle). */
    fun applyAccent(a: android.app.Activity) {
        val i = a.getSharedPreferences("set", Context.MODE_PRIVATE).getInt("acc", -1)
        if (i in ACC_STYLES.indices) a.theme.applyStyle(ACC_STYLES[i], true)
    }

    fun sig(c: Context): String = c.getSharedPreferences("set", Context.MODE_PRIVATE).let { "${it.getInt("theme", 0)}_${it.getInt("acc", -1)}" }
}

/** Properties / info + share, MainActivity aur PlayerActivity dono use karte hain. */
object VideoInfo {

    fun size(b: Long): String {
        if (b <= 0) return ""
        val u = arrayOf("B", "KB", "MB", "GB")
        var d = b.toDouble()
        var i = 0
        while (d >= 1024 && i < 3) { d /= 1024; i++ }
        return String.format(Locale.US, if (i == 0) "%.0f %s" else "%.2f %s", d, u[i])
    }

    fun dur(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
        else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    /** Properties dialog ka text: section heading (bold) + "Label: value" rows. Khali section dikhta hi nahi. */
    private class Doc {
        val sb = SpannableStringBuilder()
        private var pending: String? = null
        fun section(t: String) { pending = t }
        fun row(k: String, v: String?) {
            if (v.isNullOrBlank()) return
            pending?.let { t ->
                if (sb.isNotEmpty()) sb.append('\n')
                val st = sb.length
                sb.append(t.uppercase(Locale.US))
                sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(RelativeSizeSpan(0.85f), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.append('\n')
                pending = null
            }
            sb.append(k).append(": ").append(v).append('\n')
        }
        fun finish(): CharSequence {
            while (sb.isNotEmpty() && sb[sb.length - 1] == '\n') sb.delete(sb.length - 1, sb.length)
            return sb
        }
    }

    fun summary(vs: List<Video>): CharSequence {
        val d = Doc()
        d.section("Selection summary")
        d.row("Videos selected", vs.size.toString())
        d.row("Total file size", size(vs.sumOf { it.size }))
        d.row("Total duration", dur(vs.sumOf { it.dur }))
        return d.finish()
    }

    @Suppress("DEPRECATION")
    fun describe(c: Context, uri: Uri): CharSequence {
        val doc = Doc()

        var name: String? = null; var sz = 0L; var d = 0L; var w = 0; var h = 0
        var added = 0L; var path: String? = null; var mime: String? = null; var bucket: String? = null
        try {
            c.contentResolver.query(uri, arrayOf(Media.DISPLAY_NAME, Media.SIZE, Media.DURATION, Media.WIDTH,
                Media.HEIGHT, Media.DATE_ADDED, Media.DATA, Media.MIME_TYPE, Media.BUCKET_DISPLAY_NAME), null, null, null)
                ?.use {
                    if (it.moveToFirst()) {
                        name = it.getString(0); sz = it.getLong(1); d = it.getLong(2); w = it.getInt(3); h = it.getInt(4)
                        added = it.getLong(5); path = it.getString(6); mime = it.getString(7); bucket = it.getString(8)
                    }
                }
        } catch (e: Exception) {
            try {   // media store ke bahar ka content uri
                c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                    ?.use { if (it.moveToFirst()) { name = it.getString(0); sz = it.getLong(1) } }
            } catch (e2: Exception) { }
        }

        doc.section("File details")
        doc.row("File name", name ?: uri.lastPathSegment)
        doc.row("Folder name", bucket)
        doc.row("Full path", path ?: uri.toString())
        doc.row("File size", size(sz))
        doc.row("File format (MIME type)", mime)
        if (added > 0) doc.row("Date added", DateFormat.getDateTimeInstance().format(Date(added * 1000)))

        doc.section("Video details")
        if (d > 0) doc.row("Duration", dur(d))
        if (w > 0 && h > 0) doc.row("Resolution (width x height)", "$w x $h")

        try {
            val ex = MediaExtractor()
            try {
                ex.setDataSource(c, uri, null)
                var audio = 0; var subs = 0
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                    when {
                        m.startsWith("video/") -> {
                            doc.row("Video codec", m.removePrefix("video/"))
                            num(f, MediaFormat.KEY_FRAME_RATE)?.let { doc.row("Frame rate", String.format(Locale.US, "%.2f fps", it)) }
                            num(f, MediaFormat.KEY_BIT_RATE)?.let { doc.row("Video bitrate", String.format(Locale.US, "%.0f kbps", it / 1000)) }
                        }
                        m.startsWith("audio/") -> {
                            audio++
                            val lang = if (f.containsKey(MediaFormat.KEY_LANGUAGE)) f.getString(MediaFormat.KEY_LANGUAGE) else null
                            val ch = num(f, MediaFormat.KEY_CHANNEL_COUNT)?.toInt()
                            val sr = num(f, MediaFormat.KEY_SAMPLE_RATE)?.toInt()
                            doc.section("Audio tracks")
                            doc.row("Audio track $audio", listOfNotNull(m.removePrefix("audio/"), lang?.let { "Language: $it" },
                                ch?.let { "$it channels" }, sr?.let { "$it Hz" }).joinToString("  |  "))
                        }
                        else -> subs++
                    }
                }
                if (subs > 0) {
                    doc.section("Subtitle / other tracks")
                    doc.row("Embedded subtitle / other tracks", subs.toString())
                }
            } finally { ex.release() }
        } catch (e: Exception) { }
        return doc.finish()
    }

    private fun num(f: MediaFormat, key: String): Double? {
        if (!f.containsKey(key)) return null
        return try { f.getInteger(key).toDouble() } catch (e: Exception) {
            try { f.getFloat(key).toDouble() } catch (e2: Exception) { null }
        }
    }

    fun share(c: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val web = uris[0].scheme == "http" || uris[0].scheme == "https"
        val i = when {
            web -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, uris[0].toString())
            uris.size == 1 -> Intent(Intent.ACTION_SEND).setType("video/*").putExtra(Intent.EXTRA_STREAM, uris[0])
            else -> Intent(Intent.ACTION_SEND_MULTIPLE).setType("video/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        if (!web) {
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val cd = ClipData.newRawUri("", uris[0])
            uris.drop(1).forEach { cd.addItem(ClipData.Item(it)) }
            i.clipData = cd
        }
        val chooser = Intent.createChooser(i, "Share")
        if (c !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(chooser)
    }
}
