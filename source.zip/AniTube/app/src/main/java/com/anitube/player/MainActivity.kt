package com.anitube.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.MediaStore.Video.Media
import android.provider.MediaStore.Video.Thumbnails
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

class Video(
    val id: Long, val uri: String, val name: String, val dur: Long, val folder: String,
    val size: Long = 0L, val path: String = ""
)
class Folder(val name: String, val videos: List<Video>)

class MainActivity : Activity() {

    private val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    private val cache = LruCache<String, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)
    private var all = listOf<Video>()
    private var folders = listOf<Folder>()
    private var openName: String? = null
    private val prefs by lazy { getSharedPreferences("set", MODE_PRIVATE) }
    private val sortNames = arrayOf("Name 1,2,3", "Newest", "Oldest")
    private val blue = 0xFF4FC3F7.toInt()
    private val grey = 0xFF777777.toInt()
    private val FAV = "\u2605 Favourites"
    private val DLG = android.R.style.Theme_DeviceDefault_Dialog_Alert

    // multiselect / search / pending system-dialog actions
    private val sel = LinkedHashSet<String>()
    private var selecting = false
    private var curVids = listOf<Video>()
    private var query = ""
    private var pendingDel: List<String> = emptyList()
    private var pendingRename: Pair<Video, String>? = null
    private var afterPerm: (() -> Unit)? = null
    private val REQ_DEL = 10
    private val REQ_DEL29 = 11
    private val REQ_REN = 12
    private val REQ_REN29 = 13

    private lateinit var list: ListView
    private lateinit var titleTv: TextView
    private lateinit var sortBtn: TextView
    private lateinit var searchBtn: TextView
    private lateinit var searchBox: EditText
    private lateinit var header: View
    private lateinit var selBar: View
    private lateinit var selCount: TextView
    private lateinit var recent: android.widget.LinearLayout
    private lateinit var recentBox: View

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.list)
        titleTv = findViewById(R.id.title)
        sortBtn = findViewById(R.id.sortBtn)
        searchBtn = findViewById(R.id.searchBtn)
        searchBox = findViewById(R.id.searchBox)
        header = findViewById(R.id.header)
        selBar = findViewById(R.id.selBar)
        selCount = findViewById(R.id.selCount)
        recent = findViewById(R.id.recent)
        recentBox = findViewById(R.id.recentBox)
        titleTv.setOnClickListener { onBackPressed() }
        val recentHdr = findViewById<TextView>(R.id.recentHdr)
        val recentScroll = findViewById<View>(R.id.recentScroll)
        val updRecent = {
            val open = prefs.getBoolean("c_recent", true)
            recentScroll.visibility = if (open) View.VISIBLE else View.GONE
            recentHdr.text = (if (open) "\u25BE  " else "\u25B8  ") + "Continue Watching"
        }
        updRecent()
        recentHdr.setOnClickListener { prefs.edit().putBoolean("c_recent", !prefs.getBoolean("c_recent", true)).apply(); updRecent() }
        sortBtn.setOnClickListener {
            prefs.edit().putInt("sort", (prefs.getInt("sort", 0) + 1) % 3).apply()
            render()
        }

        // search
        searchBtn.setOnClickListener {
            if (searchBox.visibility == View.VISIBLE) closeSearch()
            else {
                searchBox.visibility = View.VISIBLE
                searchBox.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox, 0)
            }
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s.toString().trim(); clearSel(); render() }
        })

        // multiselect bar
        findViewById<View>(R.id.selClose).setOnClickListener { clearSel() }
        findViewById<View>(R.id.selAll).setOnClickListener {
            curVids.forEach { sel.add(it.uri) }; selecting = sel.isNotEmpty(); refreshSel()
        }
        findViewById<View>(R.id.selShare).setOnClickListener { VideoInfo.share(this, selVideos().map { Uri.parse(it.uri) }) }
        findViewById<View>(R.id.selDel).setOnClickListener { deleteSelected() }
        findViewById<View>(R.id.selMore).setOnClickListener { moreMenu() }

        findViewById<TextView>(R.id.verBtn).apply {
            text = "v" + Updater.curName(this@MainActivity)
            setOnClickListener { Updater.check(this@MainActivity, true) }
        }
        Updater.check(this, false)

        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(perm), 1)
    }

    override fun onResume() {
        super.onResume()
        Updater.resume(this)
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 2) {
            val next = afterPerm; afterPerm = null
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) next?.invoke()
            else Toast.makeText(this, "Permission chahiye", Toast.LENGTH_LONG).show()
            return
        }
        if (r.isEmpty() || r[0] != PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Videos dikhane ke liye permission chahiye", Toast.LENGTH_LONG).show()
    }

    override fun onBackPressed() {
        when {
            selecting -> clearSel()
            searchBox.visibility == View.VISIBLE -> closeSearch()
            openName != null -> { openName = null; render() }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { super.onDestroy(); pool.shutdownNow() }

    private fun closeSearch() {
        query = ""
        searchBox.setText("")
        searchBox.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchBox.windowToken, 0)
        render()
    }

    // ---------- data ----------
    @Suppress("DEPRECATION")
    private fun load() {
        val v = ArrayList<Video>()
        contentResolver.query(
            Media.EXTERNAL_CONTENT_URI,
            arrayOf(Media._ID, Media.DISPLAY_NAME, Media.DURATION, Media.BUCKET_DISPLAY_NAME, Media.SIZE, Media.DATA),
            null, null, Media.DATE_ADDED + " DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                v += Video(
                    id, ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id).toString(),
                    c.getString(1) ?: "Video", c.getLong(2), c.getString(3) ?: "Other",
                    c.getLong(4), c.getString(5) ?: ""
                )
            }
        }
        all = v
        folders = v.groupBy { it.folder }.map { Folder(it.key, it.value) }.sortedWith(Comparator { a, b -> natCmp(a.name, b.name) })
        sel.retainAll(v.map { it.uri }.toSet())
        if (sel.isEmpty()) selecting = false
        render()
    }

    // favourites = pin: har folder me upar, aur home par "Favourites" folder
    private fun favs(): Set<String> = prefs.getStringSet("fav", emptySet()) ?: emptySet()
    private fun setFavs(s: Set<String>) = prefs.edit().putStringSet("fav", HashSet(s)).apply()

    private fun shownFolders(): List<Folder> {
        val f = favs()
        val fv = all.filter { it.uri in f }
        return (if (fv.isEmpty()) emptyList() else listOf(Folder(FAV, fv))) + folders
    }

    private fun render() {
        updateBars()
        if (query.isNotEmpty()) {
            showVideos(Folder("Search", all.filter { it.name.contains(query, true) }), true)
            return
        }
        val f = shownFolders().find { it.name == openName }
        if (f == null) { openName = null; showFolders() } else showVideos(f, false)
    }

    // ---------- folders screen ----------
    private fun showFolders() {
        titleTv.text = "AniTube"
        sortBtn.visibility = View.GONE
        curVids = emptyList()
        val last = History.recent(this, 1).firstOrNull()?.folder
        val fl = shownFolders()
        list.adapter = object : ArrayAdapter<Folder>(this, R.layout.item_folder, R.id.t1, fl) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val view = super.getView(i, v, p)
                val f = getItem(i)!!
                val isLast = f.name == last
                view.findViewById<TextView>(R.id.t1).apply {
                    text = f.name
                    setTextColor(if (isLast) blue else 0xFFFFFFFF.toInt())
                }
                view.findViewById<TextView>(R.id.t2).text =
                    f.videos.size.toString() + if (f.videos.size == 1) " video" else " videos"
                view.findViewById<View>(R.id.last).visibility = if (isLast) View.VISIBLE else View.GONE
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ -> openName = fl[i].name; render() }
        list.onItemLongClickListener = null
        showRecent()
    }

    private fun showRecent() {
        val byUri = HashMap<String, Video>()
        all.forEach { byUri[it.uri] = it }
        val items = History.recent(this, 20)
            .filter { it.dur > 0 && !History.finished(it) }
            .mapNotNull { e -> byUri[e.uri]?.let { e to it } }
            .take(8)

        recent.removeAllViews()
        for ((e, v) in items) {
            val card = layoutInflater.inflate(R.layout.item_recent, recent, false)
            card.findViewById<TextView>(R.id.t1).text = v.name
            card.findViewById<TextView>(R.id.t2).text = fmt(e.dur - e.pos) + " left"
            card.findViewById<ProgressBar>(R.id.bar).progress = (e.pos * 1000 / e.dur).toInt()
            thumb(v, card.findViewById(R.id.img))
            card.setOnClickListener {
                val f = folders.firstOrNull { it.name == v.folder }
                val l = if (f != null) ordered(f) else listOf(v)
                play(l, l.indexOf(v).coerceAtLeast(0))
            }
            recent.addView(card)
        }
        recentBox.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------- videos inside a folder (select mode yahin) ----------
    private fun showVideos(f: Folder, search: Boolean) {
        titleTv.text = if (search) "\u2039  Search (" + f.videos.size + ")" else "\u2039  " + f.name
        recentBox.visibility = View.GONE
        val vids = ordered(f)
        curVids = vids
        sortBtn.text = sortNames[prefs.getInt("sort", 0)]
        sortBtn.visibility = View.VISIBLE
        val lastUri = History.recent(this, 1).firstOrNull()?.uri
        val fv = favs()
        list.adapter = object : ArrayAdapter<Video>(this, R.layout.item_video, R.id.t1, vids) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val view = super.getView(i, v, p)
                val x = getItem(i)!!
                val e = History.get(this@MainActivity, x.uri)
                val done = e != null && History.finished(e)
                val t3 = view.findViewById<TextView>(R.id.t3)
                val bar = view.findViewById<ProgressBar>(R.id.bar)
                val picked = x.uri in sel

                view.setBackgroundColor(if (picked) 0x334FC3F7 else 0)
                view.findViewById<TextView>(R.id.t1).apply {
                    text = (if (picked) "\u2714  " else "") + (if (x.uri in fv) "\u2605 " else "") + x.name
                    setTextColor(if (x.uri == lastUri) blue else if (done) grey else 0xFFFFFFFF.toInt())
                }
                view.findViewById<TextView>(R.id.t2).text = fmt(x.dur)
                if (e != null && e.dur > 0) {
                    bar.visibility = View.VISIBLE
                    bar.progress = if (done) 1000 else (e.pos * 1000 / e.dur).toInt()
                    t3.visibility = View.VISIBLE
                    t3.text = if (done) "Watched" else "Resume " + fmt(e.pos)
                    t3.setTextColor(if (done) grey else blue)
                } else {
                    bar.visibility = View.GONE
                    t3.visibility = View.GONE
                }
                thumb(x, view.findViewById(R.id.img))
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ -> if (selecting) toggleSel(vids[i]) else play(vids, i) }
        list.setOnItemLongClickListener { _, _, i, _ -> selecting = true; toggleSel(vids[i]); true }
    }

    private fun ordered(f: Folder): List<Video> {
        val base = when (prefs.getInt("sort", 0)) {
            0 -> f.videos.sortedWith(Comparator { a, b -> natCmp(a.name, b.name) })
            1 -> f.videos
            else -> f.videos.reversed()
        }
        val fv = favs()
        return base.filter { it.uri in fv } + base.filter { it.uri !in fv }
    }

    private fun play(videos: List<Video>, i: Int) {
        val q = videos.drop(i).take(100)
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra("uris", q.map { it.uri }.toTypedArray())
                .putExtra("names", q.map { it.name }.toTypedArray())
                .putExtra("folder", q[0].folder)
        )
    }

    private fun fmt(ms: Long) = VideoInfo.dur(ms)

    // ---------- multiselect ----------
    private fun selVideos(): List<Video> = all.filter { it.uri in sel }

    private fun toggleSel(v: Video) {
        if (!sel.add(v.uri)) sel.remove(v.uri)
        if (sel.isEmpty()) selecting = false
        refreshSel()
    }

    private fun clearSel() { sel.clear(); selecting = false; refreshSel() }

    private fun refreshSel() { updateBars(); (list.adapter as? BaseAdapter)?.notifyDataSetChanged() }

    private fun updateBars() {
        selBar.visibility = if (selecting) View.VISIBLE else View.GONE
        header.visibility = if (selecting) View.GONE else View.VISIBLE
        selCount.text = sel.size.toString() + " selected"
    }

    private fun moreMenu() {
        val vs = selVideos()
        if (vs.isEmpty()) return
        val fv = favs()
        val allFav = vs.all { it.uri in fv }
        val names = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(t: String, f: () -> Unit) { names += t; acts += f }
        add("Properties") { showInfo(vs) }
        if (vs.size == 1) add("Rename") { renameDialog(vs[0]) }
        add(if (allFav) "Remove from favourites" else "Add to favourites (pin)") {
            val ids = vs.map { it.uri }.toSet()
            setFavs(if (allFav) fv - ids else fv + ids); clearSel(); render()
        }
        add("Mark as watched") {
            vs.forEach { if (it.dur > 0) History.save(this, it.uri, it.dur, it.dur, it.folder, it.name) }
            clearSel(); render()
        }
        add("Reset progress") { vs.forEach { History.remove(this, it.uri) }; clearSel(); render() }
        AlertDialog.Builder(this, DLG).setItems(names.toTypedArray()) { _, i -> acts[i]() }.show()
    }

    private fun showInfo(vs: List<Video>) {
        pool.execute {
            val text = if (vs.size == 1) VideoInfo.describe(this, Uri.parse(vs[0].uri)) else VideoInfo.summary(vs)
            runOnUiThread {
                AlertDialog.Builder(this, DLG).setTitle("Properties").setMessage(text)
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    // ---------- permission helper (Android 9 aur neeche write permission) ----------
    private fun needsWritePerm() = Build.VERSION.SDK_INT <= 28 &&
        checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED

    private fun withWrite(next: () -> Unit) {
        if (needsWritePerm()) { afterPerm = next; requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2) }
        else next()
    }

    // ---------- delete (safe: Android 11+ par system confirm dialog) ----------
    private fun deleteSelected() {
        val vs = selVideos()
        if (vs.isEmpty()) return
        pendingDel = vs.map { it.uri }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(contentResolver, vs.map { Uri.parse(it.uri) })
                startIntentSenderForResult(pi.intentSender, REQ_DEL, null, 0, 0, 0)
            } catch (e: Exception) { Toast.makeText(this, "Delete nahi ho paya", Toast.LENGTH_SHORT).show() }
        } else {
            AlertDialog.Builder(this, DLG).setTitle("Delete")
                .setMessage("${vs.size} video(s) delete karne hain? Ye wapas nahi aayenge.")
                .setPositiveButton("Delete") { _, _ -> withWrite { deleteLegacy() } }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun onDeleted(uri: String) {
        History.remove(this, uri)
        setFavs(favs() - uri)
        cache.remove(uri)
    }

    private fun deleteLegacy() {
        val left = ArrayList(pendingDel)
        var n = 0
        while (left.isNotEmpty()) {
            val u = left.first()
            try {
                contentResolver.delete(Uri.parse(u), null, null)
                onDeleted(u); left.removeAt(0); n++
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    pendingDel = ArrayList(left)
                    try {
                        startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ_DEL29, null, 0, 0, 0)
                    } catch (e2: Exception) { }
                    return
                }
                left.removeAt(0)
            }
        }
        finishDelete(n)
    }

    private fun finishDelete(n: Int) {
        Toast.makeText(this, "$n video(s) deleted", Toast.LENGTH_SHORT).show()
        clearSel(); load()
    }

    // ---------- rename ----------
    private fun renameDialog(v: Video) {
        val dot = v.name.lastIndexOf('.')
        val base = if (dot > 0) v.name.substring(0, dot) else v.name
        val extn = if (dot > 0) v.name.substring(dot) else ""
        val et = EditText(this).apply { setText(base); setTextColor(0xFFFFFFFF.toInt()); setSelection(text.length); setSingleLine() }
        AlertDialog.Builder(this, DLG).setTitle("Rename").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val n = et.text.toString().trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (n.isNotEmpty() && n != base) startRename(v, n + extn)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun startRename(v: Video, newName: String) {
        pendingRename = v to newName
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createWriteRequest(contentResolver, listOf(Uri.parse(v.uri)))
                startIntentSenderForResult(pi.intentSender, REQ_REN, null, 0, 0, 0)
            } catch (e: Exception) { Toast.makeText(this, "Rename nahi hua", Toast.LENGTH_SHORT).show() }
        } else withWrite { doRename() }
    }

    @Suppress("DEPRECATION")
    private fun doRename() {
        val (v, n) = pendingRename ?: return
        val uri = Uri.parse(v.uri)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                contentResolver.update(uri, ContentValues().apply { put(Media.DISPLAY_NAME, n) }, null, null)
            } else {
                val old = File(v.path)
                val nw = File(old.parentFile, n)
                if (!old.renameTo(nw)) throw IllegalStateException("rename failed")
                contentResolver.update(uri, ContentValues().apply {
                    put(Media.DISPLAY_NAME, n); put(Media.DATA, nw.absolutePath)
                }, null, null)
            }
            pendingRename = null
            Toast.makeText(this, "Renamed", Toast.LENGTH_SHORT).show()
            clearSel(); load()
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try { startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ_REN29, null, 0, 0, 0) } catch (e2: Exception) { }
            } else Toast.makeText(this, "Rename nahi hua (permission)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Rename nahi hua", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        when (r) {
            REQ_DEL -> if (res == RESULT_OK) { pendingDel.forEach { onDeleted(it) }; finishDelete(pendingDel.size) }
            REQ_DEL29 -> if (res == RESULT_OK) deleteLegacy()
            REQ_REN, REQ_REN29 -> if (res == RESULT_OK) doRename()
        }
    }

    // ---------- thumbnails ----------
    @Suppress("DEPRECATION")
    private fun thumb(v: Video, iv: ImageView) {
        iv.tag = v.uri
        val hit = cache.get(v.uri)
        iv.setImageBitmap(hit)
        if (hit != null) return
        pool.execute {
            val bm = try {
                if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(Uri.parse(v.uri), Size(192, 120), null)
                else Thumbnails.getThumbnail(contentResolver, v.id, Thumbnails.MINI_KIND, null)
            } catch (e: Exception) { null }
            if (bm != null) {
                cache.put(v.uri, bm)
                runOnUiThread { if (iv.tag == v.uri) iv.setImageBitmap(bm) }
            }
        }
    }
}

/** Natural sort: "Ep 2" < "Ep 10" (1,2,3,...,10), na ki 1,10,2. */
fun natCmp(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        if (a[i].isDigit() && b[j].isDigit()) {
            val si = i
            val sj = j
            while (i < a.length && a[i].isDigit()) i++
            while (j < b.length && b[j].isDigit()) j++
            val x = a.substring(si, i).trimStart('0')
            val y = b.substring(sj, j).trimStart('0')
            if (x.length != y.length) return x.length - y.length
            val c = x.compareTo(y)
            if (c != 0) return c
        } else {
            val c = a[i].lowercaseChar().compareTo(b[j].lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}
