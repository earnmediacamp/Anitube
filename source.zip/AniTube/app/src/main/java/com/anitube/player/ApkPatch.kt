package com.anitube.player

import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.InflaterInputStream

/**
 * Patch update: purani (installed) APK + chhota patch = nayi APK.
 * Patch tools/pack-patch.py se banta hai (bsdiff ka output, zlib me repack).
 */
object ApkPatch {
    private const val MAGIC = "APKPATCH"
    private const val HEAD = 40

    private fun le(b: ByteArray, o: Int): Long {
        var v = 0L
        for (k in 7 downTo 0) v = (v shl 8) or (b[o + k].toLong() and 0xFF)
        return v
    }

    /** bsdiff ka sign-magnitude 8 byte number. */
    private fun offtin(b: ByteArray): Long {
        var y = (b[7].toLong() and 0x7F)
        for (k in 6 downTo 0) y = (y shl 8) or (b[k].toLong() and 0xFF)
        return if ((b[7].toInt() and 0x80) != 0) -y else y
    }

    private fun readFully(s: InputStream, b: ByteArray, n: Int) {
        var r = 0
        while (r < n) {
            val k = s.read(b, r, n - r)
            if (k < 0) throw EOFException("patch adhura hai")
            r += k
        }
    }

    @Throws(IOException::class)
    fun apply(oldFile: File, patchFile: File, outFile: File) {
        val p = patchFile.readBytes()
        if (p.size < HEAD || String(p, 0, 8, Charsets.US_ASCII) != MAGIC) throw IOException("patch format galat")
        val newSize = le(p, 8)
        val cl = le(p, 16).toInt()
        val dl = le(p, 24).toInt()
        val el = le(p, 32).toInt()
        if (cl < 0 || dl < 0 || el < 0 || HEAD.toLong() + cl + dl + el != p.size.toLong()) throw IOException("patch size galat")

        val ctrl = BufferedInputStream(InflaterInputStream(ByteArrayInputStream(p, HEAD, cl)))
        val diff = BufferedInputStream(InflaterInputStream(ByteArrayInputStream(p, HEAD + cl, dl)))
        val extra = BufferedInputStream(InflaterInputStream(ByteArrayInputStream(p, HEAD + cl + dl, el)))
        val old = oldFile.readBytes()
        val oldSize = old.size.toLong()

        outFile.outputStream().buffered().use { out ->
            val cb = ByteArray(8)
            val buf = ByteArray(64 * 1024)
            val x = LongArray(3)
            var oldPos = 0L
            var newPos = 0L
            while (newPos < newSize) {
                for (k in 0..2) { readFully(ctrl, cb, 8); x[k] = offtin(cb) }
                if (x[0] < 0 || x[1] < 0 || newPos + x[0] + x[1] > newSize) throw IOException("patch kharab hai")

                var left = x[0]
                while (left > 0) {
                    val n = minOf(left, buf.size.toLong()).toInt()
                    readFully(diff, buf, n)
                    for (k in 0 until n) {
                        val op = oldPos + k
                        if (op >= 0 && op < oldSize) buf[k] = (buf[k] + old[op.toInt()]).toByte()
                    }
                    out.write(buf, 0, n)
                    oldPos += n; newPos += n; left -= n
                }
                left = x[1]
                while (left > 0) {
                    val n = minOf(left, buf.size.toLong()).toInt()
                    readFully(extra, buf, n)
                    out.write(buf, 0, n)
                    newPos += n; left -= n
                }
                oldPos += x[2]
            }
        }
        if (outFile.length() != newSize) throw IOException("naya APK size match nahi hua")
    }
}
