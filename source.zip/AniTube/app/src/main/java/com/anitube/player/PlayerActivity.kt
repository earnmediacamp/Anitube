package com.anitube.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Environment
import android.provider.MediaStore
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.provider.OpenableColumns
import android.util.TypedValue
import java.io.File
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.SubtitleView
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Locale
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.ui.AspectRatioFrameLayout as AR
import androidx.media3.ui.PlayerView
import kotlin.math.abs

private class ExtSub(val text: String, val kind: String, val mime: String) { var cur: File? = null }

@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private lateinit var player: ExoPlayer
    private lateinit var uris: Array<String>
    private lateinit var pv: PlayerView
    private lateinit var info: TextView
    private lateinit var ttl: TextView
    private lateinit var decBtn: TextView
    private lateinit var playBtn: ImageView
    private lateinit var unlockBtn: ImageView
    private lateinit var am: AudioManager
    private val prefs by lazy { getSharedPreferences("set", MODE_PRIVATE) }
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }
    private val modes = intArrayOf(AR.RESIZE_MODE_FIT, AR.RESIZE_MODE_FILL, AR.RESIZE_MODE_ZOOM)
    private val aspectNames = arrayOf("Fit", "Stretch", "Crop")
    private var mode = 0
    private var folder = ""
    private var names: Array<String>? = null
    private var locked = false
    private var g = 0          // gesture: 1=seek 2=brightness 3=volume
    private var seekBy = 0L
    private var bright = 0.5f
    private var vol = 0f
    private val subs = HashMap<Int, MediaItem.SubtitleConfiguration>()

    // ---- sub / audio delay (per video, sirf is session ke liye) ----
    private lateinit var subView: SubtitleView
    private lateinit var ccBtn: ImageView
    private val audioDelay = AudioDelayProcessor()
    private var audioDelayOn = false      // true hone par hi audio chain me delay processor lagta hai
    private var fallbacks = 0
    private val subDelay = HashMap<Int, Long>()
    private val audDelay = HashMap<Int, Long>()
    private val ext = HashMap<Int, ExtSub>()           // external subtitle file (re-time karne ke liye text yaad rakhte hain)
    private val cueEvents = ArrayList<Pair<Long, List<Cue>>>()   // embedded subtitle ke live delay ke liye
    private var lastCues: List<Cue> = emptyList()
    private var shown: List<Cue> = emptyList()
    private var reloadIdx = -1
    private var sleepAt = 0L
    private val sleepRun = Runnable { sleepAt = 0L; player.pause(); show("Sleep timer: paused") }
    private val reloadSub = Runnable { reloadItem(reloadIdx) }
    private val flushAudio = Runnable { player.seekTo(player.currentPosition) }
    private val tick = object : Runnable {
        override fun run() { updateCues(); subView.postDelayed(this, 80) }
    }
    private var dlg: AlertDialog? = null
    private var tf: Typeface? = null
    private val DLG = android.R.style.Theme_DeviceDefault_Dialog_Alert

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        pv = findViewById(R.id.pv)
        info = findViewById(R.id.info)
        ttl = findViewById(R.id.title)
        decBtn = findViewById(R.id.decBtn)
        playBtn = findViewById(R.id.playBtn)
        unlockBtn = findViewById(R.id.unlockBtn)
        subView = findViewById(R.id.subView)
        ccBtn = findViewById(R.id.ccBtn)
        pv.subtitleView?.visibility = View.GONE      // apna SubtitleView use karte hain (delay ke liye)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()

        uris = intent.getStringArrayExtra("uris") ?: arrayOf(intent.dataString ?: return finish())
        names = intent.getStringArrayExtra("names")
        folder = intent.getStringExtra("folder") ?: ""
        val h = History.get(this, uris[0])
        start(0, if (h != null && !History.finished(h)) h.pos else 0L)
        loadFont(); applySub(); applyEnh()
        pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.setOnClickListener { menu() }

        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }

        // right rail collapsible
        val railItems = findViewById<View>(R.id.railItems)
        val railToggle = findViewById<ImageView>(R.id.railToggle)
        val rail = {
            val open = prefs.getBoolean("rail", true)
            railItems.visibility = if (open) View.VISIBLE else View.GONE
            railToggle.rotation = if (open) 0f else 180f
        }
        rail()
        railToggle.setOnClickListener { prefs.edit().putBoolean("rail", !prefs.getBoolean("rail", true)).apply(); rail() }

        findViewById<View>(R.id.shotBtn).setOnClickListener { screenshot() }

        // quick subtitle ON/OFF
        ccBtn.setOnClickListener {
            prefs.edit().putBoolean("son", !subOn()).apply()
            applySubOnOff()
            show(if (subOn()) "Subtitles ON" else "Subtitles OFF")
        }
        findViewById<View>(R.id.prevBtn).setOnClickListener { player.seekToPreviousMediaItem() }
        findViewById<View>(R.id.nextBtn).setOnClickListener { player.seekToNextMediaItem() }
        findViewById<View>(R.id.pipBtn).setOnClickListener { pip() }
        findViewById<View>(R.id.rotateBtn).setOnClickListener {
            requestedOrientation =
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        findViewById<View>(R.id.aspectBtn).setOnClickListener {
            mode = (mode + 1) % 3
            pv.resizeMode = modes[mode]
            show(aspectNames[mode])
        }
        playBtn.setOnClickListener {
            if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) player.play() else player.pause()
        }
        decBtn.setOnClickListener {
            prefs.edit().putBoolean("sw", !prefs.getBoolean("sw", false)).apply()
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            player.release()
            start(i, p)
            show(decBtn.text.toString() + " decoder")
        }
        findViewById<View>(R.id.lockBtn).setOnClickListener { setLock(true) }
        unlockBtn.setOnClickListener { setLock(false) }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) flashUnlock()
                else if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val x = e.x / pv.width
                if (x in 0.35f..0.65f) {          // beech me double-tap = play / pause
                    if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) { player.play(); show("Play") }
                    else { player.pause(); show("Pause") }
                    return true
                }
                val d = if (x < 0.35f) -10_000L else 10_000L
                player.seekTo((player.currentPosition + d).coerceAtLeast(0))
                show(if (d < 0) "-10s" else "+10s")
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null) return false
                if (g == 0) g = if (abs(dx) > abs(dy)) 1 else if (e1.x < pv.width / 2) 2 else 3
                when (g) {
                    1 -> {
                        seekBy -= (dx * 80).toLong()
                        show((if (seekBy >= 0) "+" else "") + seekBy / 1000 + "s")
                    }
                    2 -> {
                        bright = (bright + dy / pv.height).coerceIn(0.01f, 1f)
                        window.attributes = window.attributes.also { it.screenBrightness = bright }
                        show("Brightness " + (bright * 100).toInt() + "%")
                    }
                    else -> {
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        vol = (vol + dy / pv.height * max).coerceIn(0f, max.toFloat())
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                        show("Volume " + vol.toInt() + "/" + max)
                    }
                }
                return true
            }
        })

        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (!locked) {
                    if (d.scaleFactor > 1.02f) pv.resizeMode = AR.RESIZE_MODE_ZOOM
                    else if (d.scaleFactor < 0.98f) pv.resizeMode = AR.RESIZE_MODE_FIT
                }
                return true
            }
        })

        pv.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (!sd.isInProgress) gd.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (g == 1 && seekBy != 0L) player.seekTo((player.currentPosition + seekBy).coerceAtLeast(0))
                g = 0; seekBy = 0
            }
            true
        }
        subView.postDelayed(tick, 80)
    }

    /** Player banata hai. HW = default decoders, SW = sirf software decoders (na mile to default). */
    private fun start(index: Int, pos: Long) {
        val sw = prefs.getBoolean("sw", false)
        cueEvents.clear(); shown = emptyList(); lastCues = emptyList()
        audioDelay.delayMs = audDelay[index] ?: 0L
        val selector = MediaCodecSelector { mime, secure, tunnel ->
            val l = MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel)
            if (sw) l.filter { it.softwareOnly }.ifEmpty { l } else l
        }
        player = ExoPlayer.Builder(
            this,
            DelayRenderersFactory(this, if (audioDelayOn) audioDelay else null).setMediaCodecSelector(selector).setEnableDecoderFallback(true)
        ).build()
        pv.player = player
        player.addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(o: Player.PositionInfo, n: Player.PositionInfo, reason: Int) {
                // video poora khatam hoke next par gaya -> "Watched" mark
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) o.mediaItem?.let { mark(it, o.positionMs, o.positionMs) }
                if (reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    cueEvents.clear(); shown = emptyList(); subView.setCues(emptyList())
                }
            }
            override fun onCues(cueGroup: CueGroup) {
                lastCues = cueGroup.cues
                if (liveDelay() <= 0) { cueEvents.clear(); shown = lastCues; subView.setCues(lastCues) }
                else { cueEvents.add(player.currentPosition to lastCues); updateCues() }
            }
            override fun onTracksChanged(tracks: Tracks) { refreshCues() }
            override fun onPlayerError(error: PlaybackException) { handleError(error) }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                playBtn.setImageResource(if (playWhenReady) R.drawable.ic_pause else R.drawable.ic_play)
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                ttl.text = item?.mediaMetadata?.title
                audioDelay.delayMs = audDelay[player.currentMediaItemIndex] ?: 0L
            }
        })
        player.setMediaItems(uris.indices.map { item(it) }, index, pos)
        player.pauseAtEndOfMediaItems = !prefs.getBoolean("auto", true)
        player.prepare()
        player.play()
        ttl.text = player.currentMediaItem?.mediaMetadata?.title
        playBtn.setImageResource(R.drawable.ic_pause)
        decBtn.text = if (sw) "SW" else "HW"
        applySubOnOff()
    }

    // ---------- error handling + auto fallback ----------
    private fun restartSoon() {
        pv.post {
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            player.release()
            start(i, p)
        }
    }

    private fun handleError(e: PlaybackException) {
        val c = e.errorCode
        val audioErr = c == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
            c == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
        val decErr = c == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
            c == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            c == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
            c == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
        if (fallbacks < 2) {
            if (audioErr && audioDelayOn) {
                fallbacks++; audioDelayOn = false; audioDelay.delayMs = 0; audDelay.clear()
                show("Audio delay band (error)"); restartSoon(); return
            }
            if (decErr && !prefs.getBoolean("sw", false)) {
                fallbacks++; prefs.edit().putBoolean("sw", true).apply()
                show("SW decoder par switch"); restartSoon(); return
            }
        }
        if (isFinishing) return
        AlertDialog.Builder(this, DLG).setTitle("Playback error")
            .setMessage(e.errorCodeName + "\n" + (e.message ?: ""))
            .setPositiveButton("Retry") { _, _ -> restartSoon() }
            .setNegativeButton("Close", null).show()
    }

    private fun item(k: Int) = MediaItem.Builder().setUri(uris[k]).setMediaMetadata(
        MediaMetadata.Builder().setTitle(names?.getOrNull(k) ?: Uri.parse(uris[k]).lastPathSegment ?: "Video").build()
    ).apply { subs[k]?.let { setSubtitleConfigurations(listOf(it)) } }.build()

    // ---------- settings menu (sab kuch collapsible sections me) ----------
    private fun menu() = panel("Settings",
        section("Subtitles", "sub", true,
            subSwitch(),
            btn("+  Load subtitle file (srt / ass / vtt)") { pickFile(1) },
            btn("Subtitle track") { dlg?.dismiss(); pick(C.TRACK_TYPE_TEXT) },
            delayRow("Subtitle delay", { subDelay[player.currentMediaItemIndex] ?: 0L }) { setSubDelay(it) },
            section("Style", "substyle", false,
                bar("Size (sp)", 10, 48, "ss", 20) { applySub() },
                LinearLayout(this).apply {
                    intArrayOf(Color.WHITE, 0xFFFFEB3B.toInt(), 0xFF4FC3F7.toInt(), 0xFF69F0AE.toInt(), 0xFFFF80AB.toInt(), 0xFFFFAB40.toInt()).forEach { c ->
                        addView(View(context).apply {
                            setBackgroundColor(c)
                            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(4), dp(8), dp(4), dp(8)) }
                            setOnClickListener { prefs.edit().putInt("sc", c).apply(); applySub() }
                        })
                    }
                },
                toggle("Background box", "sb") { applySub() }),
            section("Font", "subfont", false,
                btn("Font from file (ttf / otf)") { pickFile(2) },
                btn("Default font") { prefs.edit().remove("sf").apply(); tf = null; applySub() })),
        section("Audio", "aud", false,
            btn("Audio track") { dlg?.dismiss(); pick(C.TRACK_TYPE_AUDIO) },
            delayRow("Audio delay", { audDelay[player.currentMediaItemIndex] ?: 0L }) { setAudDelay(it) }),
        section("Video enhance", "enh", false,
            LinearLayout(this).apply {
                listOf("Normal" to intArrayOf(0, 100, 100), "Vivid" to intArrayOf(0, 110, 130),
                    "Anime" to intArrayOf(4, 115, 145), "Cinema" to intArrayOf(-6, 112, 88)).forEach { (n, v) ->
                    addView(btn(n) { setEnh(v[0], v[1], v[2]) }.apply {
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f); gravity = Gravity.CENTER; textSize = 13f
                    })
                }
            },
            bar("Brightness", -50, 50, "eb", 0) { applyEnh() },
            bar("Contrast %", 50, 150, "ec", 100) { applyEnh() },
            bar("Saturation %", 0, 200, "es", 100) { applyEnh() }),
        section("Speed", "spd", false,
            LinearLayout(this).apply {
                floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { sp ->
                    addView(btn("${sp}x") { player.setPlaybackSpeed(sp); show("${sp}x") }.apply {
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f); gravity = Gravity.CENTER; textSize = 12f
                        setPadding(dp(2), dp(12), dp(2), dp(12))
                    })
                }
            }),
        section("Playback", "play", false, autoSwitch(), sleepRow()),
        section("Video", "vid", false,
            btn("Screenshot") { dlg?.dismiss(); screenshot() },
            btn("Share video") { dlg?.dismiss(); curUri()?.let { VideoInfo.share(this, listOf(it)) } },
            btn("Properties") { showProps() }))

    private fun curUri(): Uri? = player.currentMediaItem?.localConfiguration?.uri

    private fun showProps() {
        val u = curUri() ?: return
        Thread {
            val t = VideoInfo.describe(this, u)
            runOnUiThread { AlertDialog.Builder(this, DLG).setTitle("Properties").setMessage(t).setPositiveButton("OK", null).show() }
        }.start()
    }

    private fun autoSwitch(): View = btn("") {}.also { v ->
        val upd = { v.text = "Auto-play next episode: " + if (prefs.getBoolean("auto", true)) "ON" else "OFF" }
        upd()
        v.setOnClickListener {
            prefs.edit().putBoolean("auto", !prefs.getBoolean("auto", true)).apply()
            player.pauseAtEndOfMediaItems = !prefs.getBoolean("auto", true)
            upd()
        }
    }

    private fun setSleep(min: Int) {
        subView.removeCallbacks(sleepRun)
        if (min == 0) { sleepAt = 0L; show("Sleep timer off"); return }
        sleepAt = System.currentTimeMillis() + min * 60_000L
        subView.postDelayed(sleepRun, min * 60_000L)
        show("Sleep timer $min min")
    }

    private fun sleepRow(): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = {
            tv.text = "Sleep timer: " + if (sleepAt == 0L) "Off" else "${(sleepAt - System.currentTimeMillis()) / 60_000 + 1} min left"
        }
        upd()
        val row = LinearLayout(this)
        listOf("Off" to 0, "15m" to 15, "30m" to 30, "45m" to 45, "60m" to 60, "90m" to 90).forEach { (l, m) ->
            row.addView(btn(l) { setSleep(m); upd() }.apply {
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
                gravity = Gravity.CENTER; textSize = 12f; setPadding(dp(2), dp(10), dp(2), dp(10))
                setBackgroundResource(R.drawable.chip_bg)
            })
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row) }
    }

    // ---------- screenshot (video frame, Pictures/AniTube me) ----------
    private fun screenshot() {
        val tv = pv.videoSurfaceView as? TextureView
        val bm: Bitmap? = try { tv?.bitmap } catch (e: Exception) { null }
        if (bm == null) { show("Screenshot nahi hua"); return }
        Thread {
            val ok = try { saveShot(bm) } catch (e: Exception) { false }
            runOnUiThread { show(if (ok) "Screenshot saved" else "Screenshot error") }
        }.start()
    }

    private fun saveShot(bm: Bitmap): Boolean {
        val name = "AniTube_" + System.currentTimeMillis() + ".jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AniTube")
            }
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
            contentResolver.openOutputStream(u)?.use { bm.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            return true
        }
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return false
        File(dir, name).outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        return true
    }

    /** Collapsible section: header par tap = khulo/band. Haalat prefs me yaad rehti hai. */
    private fun section(title: String, key: String, openDefault: Boolean, vararg v: View): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0); v.forEach { addView(it) }
        }
        val hdr = TextView(this).apply {
            setTextColor(0xFF4FC3F7.toInt()); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(12))
        }
        val upd = {
            val open = prefs.getBoolean("sec_$key", openDefault)
            body.visibility = if (open) View.VISIBLE else View.GONE
            hdr.text = (if (open) "\u25BE  " else "\u25B8  ") + title
        }
        upd()
        hdr.setOnClickListener {
            prefs.edit().putBoolean("sec_$key", !prefs.getBoolean("sec_$key", openDefault)).apply(); upd()
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(hdr); addView(body) }
    }

    private fun fmtDelay(ms: Long) = (if (ms > 0) "+" else "") + String.format(Locale.US, "%.1f s", ms / 1000.0)

    /** MX Player jaisa delay control: -1s  -0.1s  +0.1s  +1s  Reset */
    private fun delayRow(t: String, cur: () -> Long, set: (Long) -> Unit): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = { tv.text = "$t: " + fmtDelay(cur()) }
        upd()
        fun chip(label: String, d: Long?) = btn(label) { set(if (d == null) 0L else cur() + d); upd() }.apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
            setBackgroundResource(R.drawable.chip_bg)
        }
        val row = LinearLayout(this).apply {
            addView(chip("-1s", -1000)); addView(chip("-0.1", -100)); addView(chip("+0.1", 100))
            addView(chip("+1s", 1000)); addView(chip("Reset", null))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row)
        }
    }

    private fun subSwitch(): View = btn("") {}.also { v ->
        val upd = { v.text = "Subtitles: " + if (subOn()) "ON" else "OFF" }
        upd()
        v.setOnClickListener { prefs.edit().putBoolean("son", !subOn()).apply(); applySubOnOff(); upd() }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f
        setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { f() }
    }

    private fun toggle(t: String, k: String, on: () -> Unit) = btn("") {}.also { v ->
        val upd = { v.text = t + ": " + if (prefs.getBoolean(k, false)) "ON" else "OFF" }
        upd()
        v.setOnClickListener { prefs.edit().putBoolean(k, !prefs.getBoolean(k, false)).apply(); upd(); on() }
    }

    private fun bar(t: String, lo: Int, hi: Int, k: String, d: Int, on: () -> Unit): View {
        val cur = prefs.getInt(k, d)
        val tv = TextView(this).apply { setTextColor(Color.WHITE); text = "$t: $cur" }
        val seek = SeekBar(this).apply {
            max = hi - lo; progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    if (!u) return
                    prefs.edit().putInt(k, p + lo).apply(); tv.text = "$t: ${p + lo}"; on()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)); addView(tv); addView(seek)
        }
    }

    private fun panel(t: String, vararg v: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)); v.forEach { addView(it) }
        }
        dlg = AlertDialog.Builder(this, DLG).setTitle(t).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK", null).show()
        dlg?.window?.setDimAmount(0.15f)
    }

    // ---------- subtitles ----------
    private fun subOn() = prefs.getBoolean("son", true)

    /** Subtitle ON/OFF: text track disable + view hide. */
    private fun applySubOnOff() {
        val on = subOn()
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !on).build()
        syncSubUi()
    }

    private fun syncSubUi() {
        val on = subOn()
        subView.visibility = if (on) View.VISIBLE else View.GONE
        ccBtn.alpha = if (on) 1f else 0.4f
    }

    // ---- subtitle delay ----
    private fun extSelected() = player.currentTracks.groups.any {
        it.type == C.TRACK_TYPE_TEXT && it.isSelected && it.getTrackFormat(0).id == "ext"
    }

    /** Live delay sirf embedded subtitle par (external file ka time file me hi badal dete hain). */
    private fun liveDelay(): Long = if (extSelected()) 0L else (subDelay[player.currentMediaItemIndex] ?: 0L)

    private fun updateCues() {
        val d = liveDelay()
        if (d <= 0 || cueEvents.isEmpty()) return
        val p = player.currentPosition - d
        var best: List<Cue> = emptyList()
        var n = 0
        for ((i, e) in cueEvents.withIndex()) { if (e.first <= p) { best = e.second; n = i } else break }
        repeat(n) { cueEvents.removeAt(0) }
        if (best !== shown) { shown = best; subView.setCues(best) }
    }

    private fun refreshCues() {
        if (liveDelay() <= 0) { cueEvents.clear(); shown = lastCues; subView.setCues(lastCues) }
        else { if (cueEvents.isEmpty()) cueEvents.add(player.currentPosition to lastCues); updateCues() }
    }

    private fun setSubDelay(v: Long) {
        val k = player.currentMediaItemIndex
        val d = v.coerceIn(-60_000L, 60_000L)
        subDelay[k] = d
        if (ext[k] != null) {                       // external file: re-time karke reload (debounced)
            reloadIdx = k
            subView.removeCallbacks(reloadSub)
            subView.postDelayed(reloadSub, 600)
        } else if (d < 0) {
            show("Embedded sub: sirf + delay")
            return
        }
        refreshCues()
        show("Sub delay " + fmtDelay(d))
    }

    private fun setAudDelay(v: Long) {
        val k = player.currentMediaItemIndex
        val d = v.coerceIn(-10_000L, 10_000L)
        audDelay[k] = d
        audioDelay.delayMs = d
        if (d != 0L && !audioDelayOn) {            // pehli baar: player naye audio chain ke saath dobara banta hai
            audioDelayOn = true
            restartSoon()
            show("Audio delay " + fmtDelay(d))
            return
        }
        info.removeCallbacks(flushAudio)
        info.postDelayed(flushAudio, 500)          // thoda ruk ke seek: purana buffered audio flush hoke naya delay lagta hai
        show("Audio delay " + fmtDelay(d))
    }

    private fun reloadItem(k: Int) {
        if (k < 0 || k >= player.mediaItemCount) return
        buildExt(k)
        val p = player.currentPosition
        val playing = player.playWhenReady
        player.replaceMediaItem(k, item(k))
        player.seekTo(k, p)
        player.playWhenReady = playing
    }

    private val tsRe = Regex("""((?:\d+:)?\d+:\d{2}[,.]\d{1,3})(\s*-->\s*)((?:\d+:)?\d+:\d{2}[,.]\d{1,3})""")
    private val tsPart = Regex("""(?:(\d+):)?(\d+):(\d{2})[,.](\d{1,3})""")
    private val assRe = Regex("""^(\s*Dialogue:[^,]*,)(\d+:\d{2}:\d{2}[.:]\d{1,2}),(\d+:\d{2}:\d{2}[.:]\d{1,2})(,.*)$""")
    private val assPart = Regex("""(\d+):(\d{2}):(\d{2})[.:](\d{1,2})""")

    private fun parseTs(s: String): Long {
        val m = tsPart.matchEntire(s.trim()) ?: return 0
        val h = m.groupValues[1].ifEmpty { "0" }.toLong()
        return ((h * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(3, '0').toLong()
    }

    private fun fmtTs(ms: Long, comma: Boolean): String {
        val t = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d:%02d%s%03d", t / 3600000, t / 60000 % 60, t / 1000 % 60,
            if (comma) "," else ".", t % 1000)
    }

    private fun parseAss(s: String): Long {
        val m = assPart.matchEntire(s.trim()) ?: return 0
        return ((m.groupValues[1].toLong() * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(2, '0').toLong() * 10
    }

    private fun fmtAss(ms: Long): String {
        val t = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%d:%02d:%02d.%02d", t / 3600000, t / 60000 % 60, t / 1000 % 60, t % 1000 / 10)
    }

    /** Subtitle text ke saare timestamps ms se shift karta hai (srt / vtt / ass). */
    private fun shiftSub(text: String, kind: String, ms: Long): String {
        if (ms == 0L) return text
        return if (kind == "ass") {
            text.lines().joinToString("\n") { line ->
                assRe.matchEntire(line)?.let { m ->
                    m.groupValues[1] + fmtAss(parseAss(m.groupValues[2]) + ms) + "," +
                        fmtAss(parseAss(m.groupValues[3]) + ms) + m.groupValues[4]
                } ?: line
            }
        } else {
            tsRe.replace(text) { m ->
                fmtTs(parseTs(m.groupValues[1]) + ms, kind == "srt") + m.groupValues[2] +
                    fmtTs(parseTs(m.groupValues[3]) + ms, kind == "srt")
            }
        }
    }

    private fun decodeText(b: ByteArray): String {
        if (b.size >= 2 && ((b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) || (b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())))
            return String(b, Charsets.UTF_16).removePrefix("\uFEFF")
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString().removePrefix("\uFEFF")
        } catch (e: Exception) {
            String(b, java.nio.charset.Charset.forName("windows-1252"))
        }
    }

    /** External subtitle ko current delay ke hisaab se re-time karke cache file + SubtitleConfiguration banata hai. */
    private fun buildExt(k: Int) {
        val e = ext[k] ?: return
        val out = shiftSub(e.text, e.kind, subDelay[k] ?: 0L)
        e.cur?.delete()
        val f = File(cacheDir, "sub_${k}_${System.nanoTime()}.${e.kind}")
        f.writeBytes(out.toByteArray(Charsets.UTF_8))
        e.cur = f
        subs[k] = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f)).setMimeType(e.mime)
            .setId("ext").setLabel("External").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
    }

    private fun applySub() {
        val sv = subView
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.getInt("ss", 20).toFloat())
        val bg = if (prefs.getBoolean("sb", false)) 0xAA000000.toInt() else Color.TRANSPARENT
        sv.setStyle(CaptionStyleCompat(prefs.getInt("sc", Color.WHITE), bg, Color.TRANSPARENT,
            CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, tf))
    }

    private fun loadFont() {
        tf = prefs.getString("sf", null)?.let { try { Typeface.createFromFile(it) } catch (e: Exception) { null } }
    }

    private fun pickFile(r: Int) {
        dlg?.dismiss()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), r)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data ?: return
        if (res != RESULT_OK) return
        if (r == 1) {
            val n = (contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: u.lastPathSegment ?: "").lowercase()
            val (kind, mt) = when {
                n.endsWith(".vtt") -> "vtt" to MimeTypes.TEXT_VTT
                n.endsWith(".ass") || n.endsWith(".ssa") -> "ass" to MimeTypes.TEXT_SSA
                else -> "srt" to MimeTypes.APPLICATION_SUBRIP
            }
            val bytes = try { contentResolver.openInputStream(u)?.use { it.readBytes() } } catch (e: Exception) { null }
            if (bytes == null) { show("Subtitle error"); return }
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            ext[i]?.cur?.delete()
            ext[i] = ExtSub(decodeText(bytes), kind, mt)
            buildExt(i)
            prefs.edit().putBoolean("son", true).apply()
            player.replaceMediaItem(i, item(i))
            player.seekTo(i, p)
            applySubOnOff()
            show("Subtitle added")
        } else {
            try {
                val f = File(filesDir, "font")
                contentResolver.openInputStream(u)?.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                prefs.edit().putString("sf", f.path).apply()
                loadFont(); applySub()
                show("Font set")
            } catch (e: Exception) { show("Font error") }
        }
        player.play()
    }

    private fun pick(type: Int) {
        val gs = player.currentTracks.groups.filter { it.type == type && it.isSupported }
        if (gs.isEmpty()) { show("No tracks"); return }
        val off = type == C.TRACK_TYPE_TEXT
        val names = (if (off) listOf("Off") else listOf<String>()) +
            gs.mapIndexed { n, g -> g.getTrackFormat(0).let { it.label ?: it.language ?: "Track ${n + 1}" } }
        AlertDialog.Builder(this, DLG).setItems(names.toTypedArray()) { _, i ->
            val k = if (off) i - 1 else i
            val tp = player.trackSelectionParameters.buildUpon().clearOverridesOfType(type).setTrackTypeDisabled(type, k < 0)
            if (k >= 0) tp.addOverride(TrackSelectionOverride(gs[k].mediaTrackGroup, 0))
            player.trackSelectionParameters = tp.build()
            if (type == C.TRACK_TYPE_TEXT) { prefs.edit().putBoolean("son", k >= 0).apply(); syncSubUi() }
        }.show()
    }

    // ---------- video enhance (GPU colour matrix, no extra library) ----------
    private fun setEnh(b: Int, c: Int, s: Int) {
        prefs.edit().putInt("eb", b).putInt("ec", c).putInt("es", s).apply()
        applyEnh(); dlg?.dismiss(); menu()
    }

    private fun applyEnh() {
        val b = prefs.getInt("eb", 0)
        val c = prefs.getInt("ec", 100) / 100f
        val m = ColorMatrix().apply { setSaturation(prefs.getInt("es", 100) / 100f) }
        val o = 128 * (1 - c) + b * 1.2f
        m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, o, 0f, c, 0f, 0f, o, 0f, 0f, c, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        pv.videoSurfaceView?.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
    }

    private fun setLock(on: Boolean) {
        locked = on
        pv.useController = !on
        unlockBtn.removeCallbacks(hideUnlock)
        if (on) flashUnlock() else unlockBtn.visibility = View.GONE
    }

    private fun flashUnlock() {
        unlockBtn.visibility = View.VISIBLE
        unlockBtn.removeCallbacks(hideUnlock)
        unlockBtn.postDelayed(hideUnlock, 2500)
    }

    private fun show(t: String) {
        info.removeCallbacks(hideInfo)
        info.text = t
        info.visibility = View.VISIBLE
        info.postDelayed(hideInfo, 800)
    }

    private fun mark(item: MediaItem, pos: Long, dur: Long) {
        val u = item.localConfiguration?.uri?.toString() ?: return
        History.save(this, u, pos, dur, folder, item.mediaMetadata.title?.toString() ?: "Video")
    }

    private fun save() {
        val item = player.currentMediaItem ?: return
        val d = player.duration
        if (d > 0) mark(item, player.currentPosition, d)
    }

    private fun pip() {
        enterPictureInPictureMode(PictureInPictureParams.Builder().build())
    }

    override fun onUserLeaveHint() {
        if (!locked && player.isPlaying) pip()
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        pv.useController = !inPip && !locked
    }

    override fun onStop() { super.onStop(); save(); player.pause() }
    override fun onDestroy() {
        super.onDestroy()
        subView.removeCallbacks(tick); subView.removeCallbacks(reloadSub); subView.removeCallbacks(sleepRun); info.removeCallbacks(flushAudio)
        ext.values.forEach { it.cur?.delete() }
        player.release()
    }
}
