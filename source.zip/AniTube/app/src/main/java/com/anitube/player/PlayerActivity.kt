package com.anitube.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Environment
import android.provider.MediaStore
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.provider.OpenableColumns
import android.util.TypedValue
import java.io.File
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.media.MediaMetadataRetriever
import android.os.SystemClock
import android.widget.ProgressBar
import android.widget.RadioButton
import android.graphics.drawable.GradientDrawable
import java.util.concurrent.Executors
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.ImageView
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.Switch
import android.content.res.ColorStateList
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.SubtitleView
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Locale
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.ui.AspectRatioFrameLayout as AR
import androidx.media3.ui.PlayerView
import io.github.peerless2012.ass.media.AssHandlerConfig
import io.github.peerless2012.ass.media.kt.buildWithAssSupport
import io.github.peerless2012.ass.media.type.AssRenderType
import androidx.media3.ui.TimeBar
import kotlin.math.abs

/** libass (ass-media) ko external ASS track ka id numeric aur >= 128 chahiye; baaki formats "ext" hi rehte hain. */
private const val ASS_EXT_ID = "129"

private class ExtSub(val text: String, val kind: String, val mime: String, val name: String) { var cur: File? = null }

private const val SHARP_AGSL = """
uniform shader inputShader;
uniform float amount;
half4 main(float2 c) {
    half4 s = inputShader.eval(c);
    half4 n = inputShader.eval(c + float2(0.0, -1.0));
    half4 d = inputShader.eval(c + float2(0.0, 1.0));
    half4 w = inputShader.eval(c + float2(-1.0, 0.0));
    half4 e = inputShader.eval(c + float2(1.0, 0.0));
    half3 o = s.rgb * (1.0 + 4.0 * amount) - (n.rgb + d.rgb + w.rgb + e.rgb) * amount;
    return half4(clamp(o, 0.0, 1.0), s.a);
}
"""

@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private lateinit var player: ExoPlayer
    private lateinit var uris: Array<String>
    private lateinit var pv: PlayerView
    private lateinit var info: TextView
    private lateinit var ttl: TextView
    private lateinit var decBtn: TextView
    private lateinit var playBtn: ImageView
    private lateinit var playFlash: ImageView
    private var manualOrient = false   // user ne rotate button dabaya -> auto orientation band (agle video tak)
    private lateinit var unlockBtn: ImageView
    private lateinit var am: AudioManager
    private val prefs by lazy { getSharedPreferences("set", MODE_PRIVATE) }
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val hideFlash = Runnable {
        playFlash.animate().alpha(0f).setDuration(220).withEndAction { playFlash.visibility = View.GONE }.start()
    }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }

    // ---- instant double-tap skip ----
    private lateinit var skipL: TextView
    private lateinit var skipR: TextView
    private var skipBase = 0L
    private var skipAcc = 0L
    private var skipDir = 0
    private var lastSkipAt = 0L
    private val hideSkip = Runnable { skipL.visibility = View.GONE; skipR.visibility = View.GONE }
    private val exactSeek = Runnable { player.setSeekParameters(SeekParameters.EXACT) }

    // ---- hold = 2x, level bar, A-B repeat, autosave, scrub preview ----
    private var boost = false
    private var preBoost = 1f
    private lateinit var levelBox: View
    private lateinit var levelTxt: TextView
    private lateinit var levelBar: ProgressBar
    private val hideLevel = Runnable { levelBox.visibility = View.GONE }
    private var abA = -1L
    private var abB = -1L
    private var lastSave = 0L
    private lateinit var scrubBox: View
    private lateinit var scrubImg: ImageView
    private lateinit var scrubTime: TextView
    private val scrubPool = Executors.newSingleThreadExecutor()
    private var mmr: MediaMetadataRetriever? = null
    private var mmrUri: String? = null
    private var scrubBusy = false
    private var scrubWant = -1L
    private val modes = intArrayOf(AR.RESIZE_MODE_FIT, AR.RESIZE_MODE_FILL, AR.RESIZE_MODE_ZOOM)
    private val aspectNames = arrayOf("Fit", "Stretch", "Crop")
    private var mode = 0
    private var folder = ""
    private var names: Array<String>? = null
    private var locked = false
    private var g = 0          // gesture: 1=seek 2=brightness 3=volume
    private var seekBy = 0L
    private var bright = 0.5f
    private var vol = 0f
    private val subs = HashMap<Int, MediaItem.SubtitleConfiguration>()

    // ---- sub / audio delay (per video, sirf is session ke liye) ----
    private lateinit var subView: SubtitleView
    private lateinit var ccBtn: ImageView
    private val audioDelay = AudioDelayProcessor()
    private var audioDelayOn = false      // true hone par hi audio chain me delay processor lagta hai
    private var fallbacks = 0
    private val subDelay = HashMap<Int, Long>()
    private val audDelay = HashMap<Int, Long>()
    private val ext = HashMap<Int, ExtSub>()           // external subtitle file (re-time karne ke liye text yaad rakhte hain)
    private val cueEvents = ArrayList<Pair<Long, List<Cue>>>()   // embedded subtitle ke live delay ke liye
    private var lastCues: List<Cue> = emptyList()
    private var shown: List<Cue> = emptyList()
    private var reloadIdx = -1
    private var badgeAfterSelect = false
    private var pendingExt = -1                       // is item par external subtitle track ko zabardasti select karna hai
    private var sleepAt = 0L
    private val sleepRun = Runnable { sleepAt = 0L; player.pause(); show("Sleep timer: paused") }
    private val reloadSub = Runnable { reloadItem(reloadIdx) }
    private val flushAudio = Runnable { player.seekTo(player.currentPosition) }
    private val tick = object : Runnable {
        override fun run() {
            updateCues()
            if (abA >= 0 && abB > abA && player.currentPosition >= abB) player.seekTo(abA)
            val now = SystemClock.uptimeMillis()
            if (now - lastSave > 10_000) { lastSave = now; if (player.isPlaying) save() }
            subView.postDelayed(this, 80)
        }
    }
    private var dlg: AlertDialog? = null

    // ---- right side panel (subtitle / more / audio / ...) + left rail ----
    private lateinit var sideWrap: View
    private lateinit var sidePanel: ScrollView
    private lateinit var sideBody: LinearLayout
    private lateinit var railWrap: View
    private lateinit var muteBtn: ImageView
    private var sideOpen = false
    private var sideRebuild: (() -> Unit)? = null
    private var muted = false
    private var tf: Typeface? = null
    private var assViews: List<View> = emptyList()      // libass overlay (animated mode) ke views, player dobara banne par hatane ke liye
    private val DLG = R.style.Theme_AniTube_Dialog

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // video ke hisab se orientation: vertical video -> portrait, horizontal -> landscape
        val firstUri = intent.getStringArrayExtra("uris")?.firstOrNull() ?: intent.dataString
        requestedOrientation = if (peekPortrait(firstUri) == true) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        pv = findViewById(R.id.pv)
        info = findViewById(R.id.info)
        ttl = findViewById(R.id.title)
        decBtn = findViewById(R.id.decBtn)
        playBtn = findViewById(R.id.playBtn)
        playFlash = findViewById(R.id.playFlash)
        skipL = findViewById(R.id.skipL)
        skipR = findViewById(R.id.skipR)
        levelBox = findViewById(R.id.levelBox)
        levelTxt = findViewById(R.id.levelTxt)
        levelBar = findViewById(R.id.levelBar)
        scrubBox = findViewById(R.id.scrubBox)
        scrubImg = findViewById(R.id.scrubImg)
        scrubTime = findViewById(R.id.scrubTime)
        unlockBtn = findViewById(R.id.unlockBtn)
        subView = findViewById(R.id.subView)
        ccBtn = findViewById(R.id.ccBtn)
        sideWrap = findViewById(R.id.sideWrap)
        sidePanel = findViewById(R.id.sidePanel)
        sideBody = findViewById(R.id.sideBody)
        railWrap = findViewById(R.id.railWrap)
        muteBtn = findViewById(R.id.muteBtn)
        findViewById<View>(R.id.sideScrim).setOnClickListener { closeSide() }
        pv.subtitleView?.visibility = View.GONE      // apna SubtitleView use karte hain (delay ke liye)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
        // brightness: pichli baar set ki hui (sab videos + app restart ke baad bhi) wapas lagao, warna system brightness se shuru
        bright = prefs.getFloat("bright", -1f).let { sv ->
            if (sv > 0f) { window.attributes = window.attributes.also { it.screenBrightness = sv }; sv }
            else try { (android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f).coerceIn(0.01f, 1f) } catch (e: Exception) { 0.5f }
        }

        uris = intent.getStringArrayExtra("uris") ?: arrayOf(intent.dataString ?: return finish())
        names = intent.getStringArrayExtra("names")
        folder = intent.getStringExtra("folder") ?: ""
        val h = History.get(this, uris[0])
        start(0, if (h != null && !History.finished(h)) h.pos else 0L)
        loadFont(); applySub(); applyEnh()
        pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.setOnClickListener { moreMenu() }

        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        findViewById<View>(R.id.rewBtn).setOnClickListener { player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L)) }
        findViewById<View>(R.id.ffBtn).setOnClickListener {
            val d = player.duration
            val t = player.currentPosition + 10_000L
            player.seekTo(if (d > 0) minOf(t, d) else t)
        }

        // left rail (vertical shortcuts) collapsible
        val railItems = findViewById<View>(R.id.railItems)
        val railToggle = findViewById<ImageView>(R.id.railToggle)
        val rail = {
            val open = prefs.getBoolean("rail2", false)
            railItems.visibility = if (open) View.VISIBLE else View.GONE
            railToggle.rotation = if (open) 180f else 0f
        }
        rail()
        applyRailVisible()
        railToggle.setOnClickListener { prefs.edit().putBoolean("rail2", !prefs.getBoolean("rail2", false)).apply(); rail() }

        // CC button -> subtitle side panel
        ccBtn.setOnClickListener { subtitlePage() }
        findViewById<View>(R.id.queueTopBtn).setOnClickListener { queue() }
        muteBtn.setOnClickListener {
            muted = !muted
            player.volume = if (muted) 0f else 1f
            muteBtn.setImageResource(if (muted) R.drawable.ic_mute else R.drawable.ic_volume)
            show(if (muted) "Muted" else "Sound ON")
        }
        findViewById<View>(R.id.sleepBtn).setOnClickListener { sleepPage() }
        findViewById<View>(R.id.audioBtn).setOnClickListener { audioPage() }
        findViewById<View>(R.id.prevBtn).setOnClickListener { player.seekToPreviousMediaItem() }
        findViewById<View>(R.id.nextBtn).setOnClickListener { player.seekToNextMediaItem() }
        findViewById<View>(R.id.pipBtn).setOnClickListener { pip() }
        findViewById<View>(R.id.skipBtn).setOnClickListener {
            val d = player.duration
            val t = player.currentPosition + prefs.getInt("skipS", 85) * 1000L
            player.seekTo(if (d > 0) minOf(t, d) else t)
            show("+" + prefs.getInt("skipS", 85) + "s")
        }
        updateSkipLabel()
        findViewById<View>(R.id.rotateBtn).setOnClickListener {
            manualOrient = true
            requestedOrientation =
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        playBtn.setOnClickListener {
            if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) player.play() else player.pause()
        }
        decBtn.setOnClickListener {
            prefs.edit().putBoolean("sw", !prefs.getBoolean("sw", false)).apply()
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            player.release()
            start(i, p)
            show(decBtn.text.toString() + " decoder")
        }
        findViewById<View>(R.id.lockBtn).setOnClickListener { setLock(true) }
        unlockBtn.setOnClickListener { setLock(false) }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                // skip chain: double-tap ke baad agle single taps bhi turant skip karte hain
                if (!locked && SystemClock.uptimeMillis() - lastSkipAt < 700) {
                    val x = e.x / pv.width
                    if (x < 0.35f) { skip(-1); return true }
                    if (x > 0.65f) { skip(1); return true }
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked || g != 0 || boost) return
                boost = true
                preBoost = player.playbackParameters.speed
                player.setPlaybackSpeed(2f)
                info.removeCallbacks(hideInfo)
                info.text = "\u25B6\u25B6  2x"
                info.visibility = View.VISIBLE
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (SystemClock.uptimeMillis() - lastSkipAt < 700) return true
                if (locked) flashUnlock()
                else if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val x = e.x / pv.width
                if (x in 0.35f..0.65f) {          // beech me double-tap = play / pause
                    if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) { player.play(); flashPlay(true) }
                    else { player.pause(); flashPlay(false) }
                    return true
                }
                skip(if (x < 0.35f) -1 else 1)
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || boost) return false
                if (g == 0) {
                    // screen ke kinare (status bar / notification pull, back & home gesture) se shuru hua swipe ignore
                    val d = resources.displayMetrics.density
                    val edge = e1.y < 56 * d || e1.y > pv.height - 40 * d || e1.x < 28 * d || e1.x > pv.width - 28 * d
                    g = if (edge) -1 else if (abs(dx) > abs(dy)) 1 else if (e1.x < pv.width / 2) 2 else 3
                }
                when (g) {
                    -1 -> return false
                    1 -> {
                        seekBy -= (dx * 80).toLong()
                        val tgt = (player.currentPosition + seekBy).coerceIn(0L, if (player.duration > 0) player.duration else Long.MAX_VALUE)
                        show(VideoInfo.dur(tgt) + "   (" + (if (seekBy >= 0) "+" else "") + seekBy / 1000 + "s)")
                    }
                    2 -> {
                        bright = (bright + dy / pv.height).coerceIn(0.01f, 1f)
                        window.attributes = window.attributes.also { it.screenBrightness = bright }
                        showLevel("Brightness  " + (bright * 100).toInt() + "%", (bright * 100).toInt())
                    }
                    else -> {
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        vol = (vol + dy / pv.height * max).coerceIn(0f, max.toFloat())
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                        showLevel("Volume  " + vol.toInt() + "/" + max, (vol / max * 100).toInt())
                    }
                }
                return true
            }
        })

        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (!locked) {
                    if (d.scaleFactor > 1.02f) pv.resizeMode = AR.RESIZE_MODE_ZOOM
                    else if (d.scaleFactor < 0.98f) pv.resizeMode = AR.RESIZE_MODE_FIT
                }
                return true
            }
        })

        pv.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (!sd.isInProgress) gd.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (g == 1 && seekBy != 0L) player.seekTo((player.currentPosition + seekBy).coerceAtLeast(0))
                if (g == 2) prefs.edit().putFloat("bright", bright).apply()
                g = 0; seekBy = 0
                if (boost) { boost = false; player.setPlaybackSpeed(preBoost); info.visibility = View.GONE }
            }
            true
        }
        (pv.findViewById<View>(androidx.media3.ui.R.id.exo_progress) as? TimeBar)?.addListener(object : TimeBar.OnScrubListener {
            override fun onScrubStart(timeBar: TimeBar, position: Long) { scrubBox.visibility = View.VISIBLE; scrubTo(position) }
            override fun onScrubMove(timeBar: TimeBar, position: Long) { scrubTo(position) }
            override fun onScrubStop(timeBar: TimeBar, position: Long, canceled: Boolean) { scrubBox.visibility = View.GONE }
        })
        subView.postDelayed(tick, 80)
    }

    /** Player banata hai. HW = default decoders, SW = sirf software decoders (na mile to default). */
    private fun start(index: Int, pos: Long) {
        val sw = prefs.getBoolean("sw", false)
        cueEvents.clear(); shown = emptyList(); lastCues = emptyList()
        audioDelay.delayMs = audDelay[index] ?: 0L
        val selector = MediaCodecSelector { mime, secure, tunnel ->
            val l = MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel)
            if (sw) l.filter { it.softwareOnly }.ifEmpty { l } else l
        }
        val rf = DelayRenderersFactory(this, if (audioDelayOn) audioDelay else null).setMediaCodecSelector(selector).setEnableDecoderFallback(true)
        // libass: ASS/SSA subtitles. Default CUES (purane subtitle pipeline ke saath poora compatible),
        // "Animated ASS" ON ho to overlay (animations / karaoke / moving text). Audio delay wala renderers factory wahi rehta hai.
        assViews.forEach { subView.removeView(it) }
        assViews = emptyList()
        val overlay = assOverlay()
        val childBefore = subView.childCount
        player = ExoPlayer.Builder(this).buildWithAssSupport(
            context = this,
            renderType = if (overlay) AssRenderType.OVERLAY_OPEN_GL else AssRenderType.CUES,
            config = AssHandlerConfig(maxRenderPixels = if (overlay) 2_073_600 else 0),
            subtitleView = if (overlay) subView else null,
            renderersFactory = rf
        )
        assViews = (childBefore until subView.childCount).map { subView.getChildAt(it) }
        if (overlay && subOn()) subView.visibility = View.VISIBLE
        pv.player = player
        // pichli baar chuni hui audio / subtitle language agle episodes par bhi apne aap
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().apply {
            prefs.getString("pal", null)?.let { setPreferredAudioLanguage(it) }
            prefs.getString("ptl", null)?.let { setPreferredTextLanguage(it) }
        }.build()
        player.volume = if (muted) 0f else 1f
        // Bluetooth / earphones: audio focus (call, doosre apps), disconnect par auto-pause, headset buttons
        player.setAudioAttributes(androidx.media3.common.AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        player.setHandleAudioBecomingNoisy(true)
        setupSession()
        player.repeatMode = prefs.getInt("rep", Player.REPEAT_MODE_OFF)
        player.shuffleModeEnabled = prefs.getBoolean("shuf", false)
        fx.attach(player.audioSessionId); applyFx()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { fx.attach(audioSessionId); applyFx() }
            override fun onIsPlayingChanged(isPlaying: Boolean) { syncSession() }
            override fun onPlaybackStateChanged(state: Int) { syncSession() }
            override fun onPositionDiscontinuity(o: Player.PositionInfo, n: Player.PositionInfo, reason: Int) {
                // video poora khatam hoke next par gaya -> "Watched" mark
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) o.mediaItem?.let { mark(it, o.positionMs, o.positionMs) }
                if (reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    cueEvents.clear(); shown = emptyList(); subView.setCues(emptyList())
                }
            }
            override fun onCues(cueGroup: CueGroup) {
                lastCues = cueGroup.cues
                // Keep the custom overlay visible whenever real cue data arrives.
                if (subOn()) subView.visibility = View.VISIBLE
                if (liveDelay() <= 0) { cueEvents.clear(); shown = lastCues; subView.setCues(lastCues) }
                else { cueEvents.add(player.currentPosition to lastCues); updateCues() }
            }
            override fun onTracksChanged(tracks: Tracks) {
                selectPendingExt(tracks)
                refreshCues()
            }
            override fun onVideoSizeChanged(vs: VideoSize) {
                if (manualOrient || isInPictureInPictureMode || vs.width <= 0 || vs.height <= 0) return
                val w = vs.width * (if (vs.pixelWidthHeightRatio > 0f) vs.pixelWidthHeightRatio else 1f)
                val h = vs.height.toFloat()
                if (w == h) return
                requestedOrientation = if (h > w) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
            override fun onPlayerError(error: PlaybackException) { handleError(error) }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                playBtn.setImageResource(if (playWhenReady) R.drawable.ic_pause else R.drawable.ic_play)
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                ttl.text = item?.mediaMetadata?.title
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) pendingExt = -1
                manualOrient = false
                abA = -1L; abB = -1L
                player.currentMediaItemIndex.let { ci -> if (ext[ci] != null) { pendingExt = ci; subView.postDelayed(extTrackRetry, 450) } }
                applySpeed()
                audioDelay.delayMs = audDelay[player.currentMediaItemIndex] ?: 0L
            }
        })
        uris.indices.forEach { loadExt(it) }          // pehle add kiye hue subtitles wapas
        if (ext[index] != null) pendingExt = index
        player.setMediaItems(uris.indices.map { item(it) }, index, pos)
        applySpeed()
        player.pauseAtEndOfMediaItems = !prefs.getBoolean("auto", true)
        player.prepare()
        player.play()
        ttl.text = player.currentMediaItem?.mediaMetadata?.title
        playBtn.setImageResource(R.drawable.ic_pause)
        decBtn.text = if (sw) "SW" else "HW"
        applySubOnOff()
    }

    // ---------- error handling + auto fallback ----------
    private fun restartSoon() {
        pv.post {
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            player.release()
            start(i, p)
        }
    }

    private fun handleError(e: PlaybackException) {
        val c = e.errorCode
        val audioErr = c == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
            c == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
        val decErr = c == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
            c == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            c == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
            c == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
        if (fallbacks < 2) {
            if (audioErr && audioDelayOn) {
                fallbacks++; audioDelayOn = false; audioDelay.delayMs = 0; audDelay.clear()
                show("Audio delay band (error)"); restartSoon(); return
            }
            if (decErr && !prefs.getBoolean("sw", false)) {
                fallbacks++; prefs.edit().putBoolean("sw", true).apply()
                show("SW decoder par switch"); restartSoon(); return
            }
        }
        if (isFinishing) return
        AlertDialog.Builder(this, DLG).setTitle("Playback error")
            .setMessage(friendly(e) + "\n\n(" + e.errorCodeName + ")")
            .setPositiveButton("Retry") { _, _ -> restartSoon() }
            .setNegativeButton("Close", null).show()
    }

    private fun item(k: Int) = MediaItem.Builder().setUri(uris[k]).setMediaMetadata(
        MediaMetadata.Builder().setTitle(names?.getOrNull(k) ?: Uri.parse(uris[k]).lastPathSegment ?: "Video").build()
    ).apply {
        subs[k]?.let {
            setSubtitleConfigurations(listOf(it))
            // IMPORTANT: Media3 1.4.1 me ProgressiveMediaSource.canUpdateMediaItem() sirf uri / customCacheKey
            // compare karta hai (subtitle config nahi). Isliye replaceMediaItem() same video par subtitle ko
            // chupchaap ignore kar deta tha -> track kabhi bana hi nahi. Har subtitle build par alag cache key
            // dene se source naya banta hai aur subtitle sach me load hota hai.
            setCustomCacheKey(uris[k] + "#sub-" + it.id + "-" + (ext[k]?.cur?.name ?: ""))
        }
    }.build()

    // ---------- right side panel: helpers ----------
    private fun fillSide(title: String?, v: List<View>) {
        sideBody.removeAllViews()
        if (title != null) sideBody.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(14))
            addView(TextView(context).apply {
                text = title; setTextColor(Color.WHITE); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_close); setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundResource(R.drawable.circle_btn); contentDescription = "Close"
                layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
                setOnClickListener { closeSide() }
            })
        })
        v.forEach { sideBody.addView(it) }
    }

    private fun openSide(title: String?, build: () -> List<View>) {
        sideRebuild = { fillSide(title, build()) }
        fillSide(title, build())
        sidePanel.scrollTo(0, 0)
        val w = minOf(dp(340), (resources.displayMetrics.widthPixels * 0.88f).toInt())
        sidePanel.layoutParams = sidePanel.layoutParams.apply { width = w }
        if (!sideOpen) {
            sideOpen = true
            pv.hideController()
            sideWrap.visibility = View.VISIBLE
            sidePanel.translationX = w.toFloat()
            sidePanel.animate().translationX(0f).setDuration(180).start()
        }
    }

    /** Panel ko wahin dobara banata hai (scroll yaad rakhta hai), jaise slider values refresh karne ke liye. */
    private fun reopenSide() {
        if (!sideOpen) return
        val y = sidePanel.scrollY
        sideRebuild?.invoke()
        sidePanel.post { sidePanel.scrollTo(0, y) }
    }

    private fun closeSide() {
        dlg?.dismiss()
        if (!sideOpen) return
        sideOpen = false
        sidePanel.animate().translationX(sidePanel.width.toFloat()).setDuration(160)
            .withEndAction { if (!sideOpen) sideWrap.visibility = View.GONE }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (sideOpen) closeSide() else super.onBackPressed() }

    private fun icon(res: Int) = ImageView(this).apply {
        setImageResource(res)
        layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(20) }
    }

    /** Icon + text wali row (tap = action). */
    private fun srow(ic: Int?, t: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
        setBackgroundResource(R.drawable.row_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        if (ic != null) addView(icon(ic))
        addView(TextView(context).apply { text = t; setTextColor(Color.WHITE); textSize = 18f })
        setOnClickListener { f() }
    }

    /** Collapsible row (header par tap = khulo/band, haalat prefs me yaad rehti hai). */
    private fun fold(t: String, key: String, openDef: Boolean, ic: Int?, vararg v: View): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, 0, dp(4)); v.forEach { addView(it) }
        }
        val caret = TextView(this).apply { setTextColor(0xFFBBBBCC.toInt()); textSize = 13f }
        val hdr = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(13), 0, dp(13))
            if (ic != null) addView(icon(ic))
            addView(TextView(context).apply {
                text = t; setTextColor(if (ic != null) Color.WHITE else 0xFFC4C4D2.toInt()); textSize = if (ic != null) 19f else 17f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(caret)
        }
        val upd = {
            val open = prefs.getBoolean("sf_$key", openDef)
            body.visibility = if (open) View.VISIBLE else View.GONE
            caret.text = if (open) "\u25B2" else "\u25BC"
        }
        upd()
        hdr.setOnClickListener { prefs.edit().putBoolean("sf_$key", !prefs.getBoolean("sf_$key", openDef)).apply(); upd() }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(hdr); addView(body) }
    }

    /** Checkbox row. */
    private fun crow(t: String, get: () -> Boolean, set: (Boolean) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6))
        val cb = CheckBox(context).apply {
            isChecked = get(); buttonTintList = ColorStateList.valueOf(Color.WHITE)
            setOnCheckedChangeListener { _, c -> set(c) }
        }
        addView(cb)
        addView(TextView(context).apply {
            text = t; setTextColor(Color.WHITE); textSize = 17f; setPadding(dp(6), dp(6), 0, dp(6))
            setOnClickListener { cb.toggle() }
        })
    }

    /** ON/OFF switch row. */
    private fun trow(t: String, get: () -> Boolean, set: (Boolean) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(6))
        addView(TextView(context).apply {
            text = t; setTextColor(Color.WHITE); textSize = 19f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val sw = Switch(context).apply { isChecked = get(); setOnCheckedChangeListener { _, c -> set(c) } }
        addView(sw)
        setOnClickListener { sw.toggle() }
    }

    /** 3-dot menu ka round icon + label. */
    private fun cell(ic: Int, label: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(8), 0, dp(8))
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        addView(ImageView(context).apply {
            setImageResource(ic); setPadding(dp(16), dp(16), dp(16), dp(16)); setBackgroundResource(R.drawable.tile_sq_bg)
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
        })
        addView(TextView(context).apply {
            text = label; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
            minLines = 2; maxLines = 2
        })
        setOnClickListener { f() }
    }

    /** Titled rounded card that groups related settings in a side panel. */
    private fun settingCard(title: String?, vararg v: View): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(10))
        setBackgroundResource(R.drawable.row_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        if (title != null) addView(TextView(context).apply {
            text = title; setTextColor(0xFF9A9AAC.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(4))
        })
        v.forEach { addView(it) }
    }

    private fun presetRow(items: List<Pair<String, () -> Unit>>, selected: Int = -1): View = LinearLayout(this).apply {
        items.forEachIndexed { i, (n, f) ->
            addView(btn(n) { f() }.apply {
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
                gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
                setBackgroundResource(if (i == selected) R.drawable.tab_sel_bg else R.drawable.chip_bg)
            })
        }
    }

    // ---------- 3-dot menu (icon grid + toggles) ----------
    private fun moreMenu() = openSide("Quick settings") {
        val cells = ArrayList<View>()
        fun add(ic: Int, label: String, f: () -> Unit) { cells += cell(ic, label, f) }
        add(R.drawable.ic_queue, "Playing\nQueue") { closeSide(); queue() }
        add(R.drawable.ic_aspect, "Aspect\nRatio") {
            mode = (mode + 1) % 3; pv.resizeMode = modes[mode]; closeSide(); show(aspectNames[mode])
        }
        add(R.drawable.ic_display, "Display\nSettings") { displayPage() }
        add(R.drawable.ic_cc, "Subtitle") { subtitlePage() }
        add(R.drawable.ic_audio, "Audio") { audioPage() }
        add(R.drawable.ic_speed, "Speed") { speedPage() }
        add(R.drawable.ic_tune, "Playback") { playbackPage() }
        add(R.drawable.ic_info, "Video properties") { closeSide(); showProps() }
        add(R.drawable.ic_share, "Share") { closeSide(); curUri()?.let { VideoInfo.share(this, listOf(it)) } }
        add(R.drawable.ic_camera, "Screenshot") { closeSide(); screenshot() }
        add(R.drawable.ic_pip, "Picture in\nPicture") { closeSide(); pip() }
        add(R.drawable.ic_power, "Quit") { finish() }
        val out = ArrayList<View>()
        cells.chunked(4).forEach { r ->
            out += LinearLayout(this).apply {
                r.forEach { addView(it) }
                repeat(4 - r.size) { addView(View(context).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }) }
            }
        }
        out += trow("Subtitles", { subOn() }) { on -> prefs.edit().putBoolean("son", on).apply(); applySubOnOff() }
        out += trow("Shortcuts", { prefs.getBoolean("rail_on", true) }) { on ->
            prefs.edit().putBoolean("rail_on", on).apply(); applyRailVisible()
        }
        out += trow("Auto-play next", { prefs.getBoolean("auto", true) }) { on ->
            prefs.edit().putBoolean("auto", on).apply(); player.pauseAtEndOfMediaItems = !on
        }
        out += trow("Animated ASS (libass)", { assOverlay() }) { on ->
            if (on != assOverlay()) {
                prefs.edit().putBoolean("ass_anim", on).apply()
                val i = player.currentMediaItemIndex
                val p = player.currentPosition
                player.release()
                start(i, p)
                closeSide()
                show(if (on) "Animated ASS ON" else "Animated ASS OFF")
            }
        }
        out
    }

    private fun applyRailVisible() { railWrap.visibility = if (prefs.getBoolean("rail_on", true)) View.VISIBLE else View.GONE }

    // ---------- subtitle panel ----------
    private var subTab = 0

    /** Tracks | Style | Sync segmented tabs for the subtitle sheet. */
    private fun subTabBar(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4))
        setBackgroundResource(R.drawable.tab_track_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        listOf("Tracks", "Style", "Sync").forEachIndexed { i, n ->
            addView(TextView(context).apply {
                text = n; gravity = Gravity.CENTER; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (i == subTab) Color.WHITE else 0xFF9A9AAC.toInt())
                setPadding(0, dp(10), 0, dp(10))
                if (i == subTab) setBackgroundResource(R.drawable.tab_sel_bg)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { subTab = i; reopenSide() }
            })
        }
    }

    private fun subtitlePage() {
        subTab = 0
        openSide("Subtitle") {
            val body: List<View> = when (subTab) {
                1 -> customization().toList()
                2 -> listOf(
                    TextView(this).apply {
                        text = "External subtitle files can be shifted earlier or later. Embedded tracks support a later (+) delay only."
                        setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(2), dp(4), dp(10))
                    },
                    delayRow("Subtitle delay", { subDelay[player.currentMediaItemIndex] ?: 0L }) { setSubDelay(it) },
                    crow("Show subtitles", { subOn() }) { on -> prefs.edit().putBoolean("son", on).apply(); applySubOnOff() }
                )
                else -> listOfNotNull(
                    selectedSubRow(),
                    srow(R.drawable.ic_folder, prefs.getString("sub_tree", null)?.let { "Subtitle files  \u00B7  " + folderLabel(it) } ?: "Select subtitle folder") { closeSide(); subFolderDialog() }
                ) + subTrackRows() + listOfNotNull(
                    if (ext[player.currentMediaItemIndex] != null)
                        srow(R.drawable.ic_close, "Remove added subtitle") { removeExt(player.currentMediaItemIndex); closeSide() }
                    else null
                )
            }
            listOf(subTabBar()) + body
        }
    }

    private fun customization(): Array<View> = arrayOf(
        subPreviewBox(),
        TextView(this).apply {
            text = "Note: ASS/SSA subtitles use their own style, font and position; these settings apply to SRT/VTT only."
            setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(6), dp(4), dp(10))
        },
        presetRow(listOf("Classic" to intArrayOf(Color.WHITE, 0, 20), "Yellow" to intArrayOf(0xFFFFEB3B.toInt(), 0, 22),
            "Box" to intArrayOf(Color.WHITE, 1, 20), "Big" to intArrayOf(0xFFFFEB3B.toInt(), 1, 30)).map { (n, v) ->
            n to {
                prefs.edit().putInt("sc", v[0]).putBoolean("sb", v[1] == 1).putInt("ss", v[2]).apply()
                applySub(); show("$n style"); reopenSide()
            }
        }),
        bar("Size (sp)", 10, 48, "ss", 20) { applySub() },
        bar("Position (bottom se %)", 0, 40, "spos", 8) { applySub() },
        bar("Opacity %", 20, 100, "sop", 100) { applySub() },
        LinearLayout(this).apply {
            intArrayOf(Color.WHITE, 0xFFFFEB3B.toInt(), 0xFF4FC3F7.toInt(), 0xFF69F0AE.toInt(), 0xFFFF80AB.toInt(), 0xFFFFAB40.toInt()).forEach { c ->
                addView(View(context).apply {
                    setBackgroundColor(c)
                    layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(8), dp(4), dp(8)) }
                    setOnClickListener { prefs.edit().putInt("sc", c).apply(); applySub() }
                })
            }
        },
        toggle("Background box", "sb") { applySub() },
        btn("Font: " + fontName() + "  \u203A") { fontDialog() }
    )

    // ---------- other panels ----------
    private fun audioPage() = openSide("Audio") {
        listOf(
            srow(R.drawable.ic_audio, "Audio track") { closeSide(); pick(C.TRACK_TYPE_AUDIO) },
            srow(R.drawable.ic_tune, "Equalizer") { closeSide(); eqPage() },
            settingCard("SYNC", delayRow("Audio delay", { audDelay[player.currentMediaItemIndex] ?: 0L }) { setAudDelay(it) }),
            settingCard("VOLUME BOOST",
                bar("Boost (dB)", 0, 15, "vb", 0) { applyFx() },
                TextView(this).apply {
                    text = "Zyada boost se awaaz phat sakti hai aur earphones / kaan ko nuksan ho sakta hai. Dheere badhao."
                    setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(2), dp(4), dp(6))
                })
        )
    }

    // ---------- equalizer + volume boost ----------
    private val fx = AudioFx()

    private fun applyFx() {
        val n = fx.bands()
        fx.apply(prefs.getBoolean("eqon", false), IntArray(n) { prefs.getInt("eqb$it", 0) }, prefs.getInt("vb", 0))
    }

    private fun hzLabel(hz: Int) = if (hz >= 1000) String.format(Locale.US, "%.1f kHz", hz / 1000f) else "$hz Hz"

    private fun setEqPreset(name: String, n: Int, minDb: Int, maxDb: Int) {
        val e = prefs.edit()
        for (i in 0 until n) {
            val f = if (n <= 1) 0f else i / (n - 1f)
            val w = when (name) {
                "Bass" -> maxOf(0f, 0.8f * (1f - 2f * f))
                "Treble" -> maxOf(0f, 0.8f * (2f * f - 1f))
                "Vocal" -> 0.6f * (1f - kotlin.math.abs(2f * f - 1f))
                else -> 0f
            }
            e.putInt("eqb$i", Math.round(w * maxDb).coerceIn(minDb, maxDb))
        }
        e.putBoolean("eqon", name != "Flat").apply()
        applyFx(); reopenSide()
    }

    private fun eqPage() = openSide("Equalizer") {
        val n = fx.bands()
        if (n == 0) listOf(TextView(this).apply {
            text = "Is phone par equalizer available nahi hai."
            setTextColor(0xFFBBBBCC.toInt()); textSize = 14f; setPadding(dp(8), dp(12), dp(8), dp(12))
        }) else {
            val (lo, hi) = fx.rangeMb()
            val minDb = maxOf(lo / 100, -15)
            val maxDb = minOf(hi / 100, 15)
            listOf(
                crow("Equalizer", { prefs.getBoolean("eqon", false) }) { on -> prefs.edit().putBoolean("eqon", on).apply(); applyFx() },
                settingCard("PRESETS", presetRow(listOf("Flat", "Bass", "Vocal", "Treble").map { nm -> nm to { setEqPreset(nm, n, minDb, maxDb) } }))
            ) + (0 until n).map { i -> bar(hzLabel(fx.freqHz(i)) + " (dB)", minDb, maxDb, "eqb$i", 0) { applyFx() } }
        }
    }

    private fun sleepPage() = openSide("Sleep timer") { listOf(sleepRow()) }

    private fun speedPage() = openSide("Speed") {
        val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val curSp = prefs.getFloat(spdKey(player.currentMediaItemIndex), 1f)
        listOf(presetRow(speeds.map { sp -> "${sp}x" to { setSpeed(sp); reopenSide() } }, speeds.indexOfFirst { it == curSp }))
    }

    private fun updateSkipLabel() { findViewById<TextView>(R.id.skipBtn).text = "+" + prefs.getInt("skipS", 85) + "s" }

    private fun playbackPage() = openSide("Playback") {
        listOf(
            settingCard("AUTO-PLAY", autoSwitch()),
            settingCard("REPEAT", repeatBtn(), toggle("Shuffle", "shuf") { player.shuffleModeEnabled = prefs.getBoolean("shuf", false) }),
            settingCard("SLEEP TIMER", sleepRow()),
            settingCard("A-B REPEAT", abRow()),
            settingCard("SKIP BUTTON", bar("Skip button (seconds)", 10, 180, "skipS", 85) { updateSkipLabel() }),
            srow(R.drawable.ic_queue, "Queue / Playlist") { closeSide(); queue() }
        )
    }

    private fun displayPage() = openSide("Display") {
        listOf(
            settingCard("PRESETS", presetRow(listOf("Normal" to intArrayOf(0, 100, 100, 0), "Vivid" to intArrayOf(0, 110, 130, 15),
                "Anime" to intArrayOf(4, 115, 145, 35), "Cinema" to intArrayOf(-6, 112, 88, 0)).map { (n, v) -> n to { setEnh(v[0], v[1], v[2], v[3]) } })),
            settingCard("ADJUST",
                bar("Brightness", -50, 50, "eb", 0) { applyEnh() },
                bar("Contrast %", 50, 150, "ec", 100) { applyEnh() },
                bar("Saturation %", 0, 300, "es", 100) { applyEnh() },
                if (Build.VERSION.SDK_INT >= 33) bar("Sharpness", 0, 100, "esh", 0) { applyEnh() }
                else TextView(this).apply {
                    text = "Sharpness: Android 13 ya usse upar chahiye"
                    setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(8), dp(4), dp(8))
                })
        )
    }

    private fun curUri(): Uri? = player.currentMediaItem?.localConfiguration?.uri

    private fun showProps() {
        val u = curUri() ?: return
        Thread {
            val t = VideoInfo.describe(this, u)
            runOnUiThread { AlertDialog.Builder(this, DLG).setTitle("Video properties").setMessage(t).setPositiveButton("OK", null).show() }
        }.start()
    }

    /** Repeat: Off -> This video -> All videos. */
    private fun repeatBtn(): View = btn("") {}.also { v ->
        val upd = {
            v.text = "Repeat: " + when (player.repeatMode) {
                Player.REPEAT_MODE_ONE -> "This video"
                Player.REPEAT_MODE_ALL -> "All videos"
                else -> "Off"
            }
        }
        upd()
        v.setOnClickListener {
            val next = when (player.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
                Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
                else -> Player.REPEAT_MODE_OFF
            }
            player.repeatMode = next
            prefs.edit().putInt("rep", next).apply()
            upd()
        }
    }

    private fun autoSwitch(): View = btn("") {}.also { v ->
        val upd = { v.text = "Auto-play next episode: " + if (prefs.getBoolean("auto", true)) "ON" else "OFF" }
        upd()
        v.setOnClickListener {
            prefs.edit().putBoolean("auto", !prefs.getBoolean("auto", true)).apply()
            player.pauseAtEndOfMediaItems = !prefs.getBoolean("auto", true)
            upd()
        }
    }

    private fun setSleep(min: Int) {
        subView.removeCallbacks(sleepRun)
        if (min == 0) { sleepAt = 0L; show("Sleep timer off"); return }
        sleepAt = System.currentTimeMillis() + min * 60_000L
        subView.postDelayed(sleepRun, min * 60_000L)
        show("Sleep timer $min min")
    }

    private fun sleepRow(): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = {
            tv.text = "Sleep timer: " + if (sleepAt == 0L) "Off" else "${(sleepAt - System.currentTimeMillis()) / 60_000 + 1} min left"
        }
        upd()
        val row = LinearLayout(this)
        listOf("Off" to 0, "15m" to 15, "30m" to 30, "45m" to 45, "60m" to 60, "90m" to 90).forEach { (l, m) ->
            row.addView(btn(l) { setSleep(m); upd() }.apply {
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
                gravity = Gravity.CENTER; textSize = 12f; setPadding(dp(2), dp(10), dp(2), dp(10))
                setBackgroundResource(R.drawable.chip_bg)
            })
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row) }
    }

    // ---------- screenshot (video frame, Pictures/AniTube me) ----------
    private fun screenshot() {
        val tv = pv.videoSurfaceView as? TextureView
        val bm: Bitmap? = try { tv?.bitmap } catch (e: Exception) { null }
        if (bm == null) { show("Screenshot nahi hua"); return }
        Thread {
            val ok = try { saveShot(bm) } catch (e: Exception) { false }
            runOnUiThread { show(if (ok) "Screenshot saved" else "Screenshot error") }
        }.start()
    }

    private fun saveShot(bm: Bitmap): Boolean {
        val name = "AniTube_" + System.currentTimeMillis() + ".jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AniTube")
            }
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
            contentResolver.openOutputStream(u)?.use { bm.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            return true
        }
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return false
        File(dir, name).outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        return true
    }

    /** Collapsible section: header par tap = khulo/band. Haalat prefs me yaad rehti hai. */
    private fun section(title: String, key: String, openDefault: Boolean, vararg v: View): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0); v.forEach { addView(it) }
        }
        val hdr = TextView(this).apply {
            setTextColor(0xFF8B7CFF.toInt()); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(12))
        }
        val upd = {
            val open = prefs.getBoolean("sec_$key", openDefault)
            body.visibility = if (open) View.VISIBLE else View.GONE
            hdr.text = (if (open) "\u25BE  " else "\u25B8  ") + title
        }
        upd()
        hdr.setOnClickListener {
            prefs.edit().putBoolean("sec_$key", !prefs.getBoolean("sec_$key", openDefault)).apply(); upd()
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(hdr); addView(body) }
    }

    private fun fmtDelay(ms: Long) = (if (ms > 0) "+" else "") + String.format(Locale.US, "%.1f s", ms / 1000.0)

    /** MX Player jaisa delay control: -1s  -0.1s  +0.1s  +1s  Reset */
    private fun delayRow(t: String, cur: () -> Long, set: (Long) -> Unit): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = { tv.text = "$t: " + fmtDelay(cur()) }
        upd()
        fun chip(label: String, d: Long?) = btn(label) { set(if (d == null) 0L else cur() + d); upd() }.apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
            setBackgroundResource(R.drawable.chip_bg)
        }
        val row = LinearLayout(this).apply {
            addView(chip("-1s", -1000)); addView(chip("-0.1", -100)); addView(chip("+0.1", 100))
            addView(chip("+1s", 1000)); addView(chip("Reset", null))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row)
        }
    }

    private fun subSwitch(): View = btn("") {}.also { v ->
        val upd = { v.text = "Subtitles: " + if (subOn()) "ON" else "OFF" }
        upd()
        v.setOnClickListener { prefs.edit().putBoolean("son", !subOn()).apply(); applySubOnOff(); upd() }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f
        setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { f() }
    }

    private fun toggle(t: String, k: String, on: () -> Unit) = btn("") {}.also { v ->
        val upd = { v.text = t + ": " + if (prefs.getBoolean(k, false)) "ON" else "OFF" }
        upd()
        v.setOnClickListener { prefs.edit().putBoolean(k, !prefs.getBoolean(k, false)).apply(); upd(); on() }
    }

    private fun bar(t: String, lo: Int, hi: Int, k: String, d: Int, on: () -> Unit): View {
        val cur = prefs.getInt(k, d)
        val tv = TextView(this).apply { setTextColor(Color.WHITE); text = "$t: $cur" }
        val seek = SeekBar(this).apply {
            max = hi - lo; progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    if (!u) return
                    prefs.edit().putInt(k, p + lo).apply(); tv.text = "$t: ${p + lo}"; on()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)); addView(tv); addView(seek)
        }
    }

    private fun panel(t: String, vararg v: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)); v.forEach { addView(it) }
        }
        dlg = AlertDialog.Builder(this, DLG).setTitle(t).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK", null).show()
        dlg?.window?.setDimAmount(0.15f)
    }

    // ---------- selected subtitle name + saved external subtitle (per video) ----------
    private fun currentSubName(): String {
        if (!subOn()) return "Off"
        val k = player.currentMediaItemIndex
        val g = player.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_TEXT && it.isSelected }
        if (g == null) return ext[k]?.let { it.name + " (loading\u2026)" } ?: "None"
        val f = g.getTrackFormat(0)
        if (isExtFormat(f)) return ext[k]?.name ?: (f.label ?: "External")
        return listOfNotNull(f.label, f.language).distinct().joinToString(" \u00B7 ").ifEmpty { "Embedded track" }
    }

    private fun selectedSubRow(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
        background = resources.getDrawable(R.drawable.info_bg, theme)
        addView(TextView(context).apply { text = "Selected subtitle"; setTextColor(0xFFBBBBCC.toInt()); textSize = 13f })
        addView(TextView(context).apply {
            text = currentSubName(); setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setSingleLine(false)       // poora naam, wrap hoke
        })
    }

    private fun subKey(k: Int): String =
        java.security.MessageDigest.getInstance("SHA-1").digest(uris[k].toByteArray()).joinToString("") { "%02x".format(it) }.take(24)

    private fun subFile(k: Int) = File(File(filesDir, "subs").apply { mkdirs() }, subKey(k) + ".sub")

    /** Added subtitle ko is video ke liye save karo, taaki player band hone ke baad dobara add na karna pade. */
    private fun saveExt(k: Int) {
        val e = ext[k] ?: return
        try {
            subFile(k).writeText(e.text, Charsets.UTF_8)
            prefs.edit().putString("xs_" + subKey(k), e.kind + "|" + e.mime + "|" + e.name).apply()
        } catch (_: Exception) {}
    }

    private fun loadExt(k: Int) {
        if (ext[k] != null) return
        val v = prefs.getString("xs_" + subKey(k), null) ?: return
        val f = subFile(k)
        if (!f.exists()) return
        try {
            val p = v.split("|", limit = 3)
            ext[k] = ExtSub(f.readText(Charsets.UTF_8), p[0], p[1], p.getOrElse(2) { "Subtitle" })
            buildExt(k)
        } catch (_: Exception) { ext.remove(k); subs.remove(k) }
    }

    private fun removeExt(k: Int) {
        ext.remove(k)?.cur?.delete()
        subs.remove(k); subDelay.remove(k); pendingExt = -1
        subFile(k).delete(); prefs.edit().remove("xs_" + subKey(k)).apply()
        val p = player.currentPosition; val pl = player.playWhenReady
        player.replaceMediaItem(k, item(k))
        player.seekTo(k, p); player.playWhenReady = pl
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).build()
        lastCues = emptyList(); shown = emptyList(); subView.setCues(emptyList())
        show("Subtitle removed")
    }

    // ---------- subtitles ----------
    private fun subOn() = prefs.getBoolean("son", true)

    /** Animated ASS (libass overlay) ON/OFF. OFF = CUES (static, purana pipeline). */
    private fun assOverlay() = prefs.getBoolean("ass_anim", false)

    /** Subtitle ON/OFF: text track disable + view hide. */
    private fun applySubOnOff() {
        val on = subOn()
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !on).build()
        syncSubUi()
    }

    private fun syncSubUi() {
        val on = subOn()
        subView.visibility = if (on) View.VISIBLE else View.GONE
        ccBtn.alpha = if (on) 1f else 0.4f
        if (!on) subView.setCues(emptyList())
    }

    // ---- subtitle delay ----
    private fun isExtFormat(f: androidx.media3.common.Format): Boolean =
        f.id == "ext" || f.id == ASS_EXT_ID || f.label == "External" || f.id?.startsWith("ext-") == true ||
            (f.label != null && f.label == ext[player.currentMediaItemIndex]?.name)

    private fun extSelected() = player.currentTracks.groups.any {
        it.type == C.TRACK_TYPE_TEXT && it.isSelected && isExtFormat(it.getTrackFormat(0))
    }

    /** Nayi external file ke baad uska track hi select karo (warna mkv ka embedded track / purana override jeet jata tha). */
    private fun selectPendingExt(tracks: Tracks) {
        if (pendingExt < 0 || pendingExt != player.currentMediaItemIndex) return
        // Do not accidentally select an embedded subtitle group reported from the previous
        // item. First wait for the replacement item's external track to appear.
        val textGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 && it.isSupported }
        val g = textGroups.firstOrNull { group ->
            (0 until group.length).any { isExtFormat(group.getTrackFormat(it)) }
        }
        if (g == null) {
            // Media3 may publish tracks before the replacement media item is prepared.
            subView.removeCallbacks(extTrackRetry)
            subView.postDelayed(extTrackRetry, 350)
            return
        }
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .addOverride(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
        pendingExt = -1
        prefs.edit().putBoolean("son", true).apply()
        subView.visibility = View.VISIBLE
        syncSubUi()
        if (badgeAfterSelect) { badgeAfterSelect = false; subView.postDelayed({ showBadge() }, 200) }
    }

    private val extTrackRetry = Runnable {
        if (pendingExt >= 0 && pendingExt == player.currentMediaItemIndex && ::player.isInitialized) {
            selectPendingExt(player.currentTracks)
        }
    }

    /** Live delay sirf embedded subtitle par (external file ka time file me hi badal dete hain). */
    private fun liveDelay(): Long = if (extSelected()) 0L else (subDelay[player.currentMediaItemIndex] ?: 0L)

    private fun updateCues() {
        val d = liveDelay()
        if (d <= 0 || cueEvents.isEmpty()) return
        val p = player.currentPosition - d
        var best: List<Cue> = emptyList()
        var n = 0
        for ((i, e) in cueEvents.withIndex()) { if (e.first <= p) { best = e.second; n = i } else break }
        repeat(n) { cueEvents.removeAt(0) }
        if (best !== shown) { shown = best; subView.setCues(best) }
    }

    private fun refreshCues() {
        if (liveDelay() <= 0) { cueEvents.clear(); shown = lastCues; subView.setCues(lastCues) }
        else { if (cueEvents.isEmpty()) cueEvents.add(player.currentPosition to lastCues); updateCues() }
    }

    private fun setSubDelay(v: Long) {
        val k = player.currentMediaItemIndex
        val d = v.coerceIn(-60_000L, 60_000L)
        subDelay[k] = d
        if (ext[k] != null) {                       // external file: re-time karke reload (debounced)
            reloadIdx = k
            subView.removeCallbacks(reloadSub)
            subView.postDelayed(reloadSub, 600)
        } else if (d < 0) {
            show("Embedded sub: sirf + delay")
            return
        }
        refreshCues()
        show("Sub delay " + fmtDelay(d) + if (ext[k] == null && assOverlay() && d != 0L) "  (animated ASS: embedded ASS par delay nahi chalta)" else "")
    }

    private fun setAudDelay(v: Long) {
        val k = player.currentMediaItemIndex
        val d = v.coerceIn(-10_000L, 10_000L)
        audDelay[k] = d
        audioDelay.delayMs = d
        if (d != 0L && !audioDelayOn) {            // pehli baar: player naye audio chain ke saath dobara banta hai
            audioDelayOn = true
            restartSoon()
            show("Audio delay " + fmtDelay(d))
            return
        }
        info.removeCallbacks(flushAudio)
        info.postDelayed(flushAudio, 500)          // thoda ruk ke seek: purana buffered audio flush hoke naya delay lagta hai
        show("Audio delay " + fmtDelay(d))
    }

    private fun reloadItem(k: Int) {
        if (k < 0 || k >= player.mediaItemCount) return
        if (k == player.currentMediaItemIndex && (extSelected() || pendingExt == k)) pendingExt = k
        buildExt(k)
        val p = player.currentPosition
        val playing = player.playWhenReady
        player.replaceMediaItem(k, item(k))
        player.seekTo(k, p)
        player.playWhenReady = playing
    }

    private val tsRe = Regex("""((?:\d+:)?\d+:\d{2}[,.]\d{1,3})(\s*-->\s*)((?:\d+:)?\d+:\d{2}[,.]\d{1,3})""")
    private val tsPart = Regex("""(?:(\d+):)?(\d+):(\d{2})[,.](\d{1,3})""")
    private val assRe = Regex("""^(\s*Dialogue:[^,]*,)(\d+:\d{2}:\d{2}[.:]\d{1,2}),(\d+:\d{2}:\d{2}[.:]\d{1,2})(,.*)$""")
    private val assPart = Regex("""(\d+):(\d{2}):(\d{2})[.:](\d{1,2})""")

    private fun parseTs(s: String): Long {
        val m = tsPart.matchEntire(s.trim()) ?: return 0
        val h = m.groupValues[1].ifEmpty { "0" }.toLong()
        return ((h * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(3, '0').toLong()
    }

    private fun fmtTs(ms: Long, comma: Boolean): String {
        val t = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d:%02d%s%03d", t / 3600000, t / 60000 % 60, t / 1000 % 60,
            if (comma) "," else ".", t % 1000)
    }

    private fun parseAss(s: String): Long {
        val m = assPart.matchEntire(s.trim()) ?: return 0
        return ((m.groupValues[1].toLong() * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(2, '0').toLong() * 10
    }

    private fun fmtAss(ms: Long): String {
        val t = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%d:%02d:%02d.%02d", t / 3600000, t / 60000 % 60, t / 1000 % 60, t % 1000 / 10)
    }

    /** Subtitle text ke saare timestamps ms se shift karta hai (srt / vtt / ass). */
    private fun shiftSub(text: String, kind: String, ms: Long): String {
        if (ms == 0L) return text
        if (kind == "ttml") return text // Preserve XML time expressions.
        return if (kind == "ass") {
            text.lines().joinToString("\n") { line ->
                assRe.matchEntire(line)?.let { m ->
                    m.groupValues[1] + fmtAss(parseAss(m.groupValues[2]) + ms) + "," +
                        fmtAss(parseAss(m.groupValues[3]) + ms) + m.groupValues[4]
                } ?: line
            }
        } else {
            tsRe.replace(text) { m ->
                fmtTs(parseTs(m.groupValues[1]) + ms, kind == "srt") + m.groupValues[2] +
                    fmtTs(parseTs(m.groupValues[3]) + ms, kind == "srt")
            }
        }
    }

    private fun decodeText(b: ByteArray): String {
        if (b.size >= 2 && ((b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) || (b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())))
            return String(b, Charsets.UTF_16).removePrefix("\uFEFF")
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString().removePrefix("\uFEFF")
        } catch (e: Exception) {
            String(b, java.nio.charset.Charset.forName("windows-1252"))
        }
    }

    /** External subtitle ko current delay ke hisaab se re-time karke cache file + SubtitleConfiguration banata hai. */
    private fun buildExt(k: Int) {
        val e = ext[k] ?: return
        val out = shiftSub(e.text, e.kind, subDelay[k] ?: 0L)
        e.cur?.delete()
        val f = File(cacheDir, "sub_${k}_${System.nanoTime()}.${e.kind}")
        f.writeBytes(out.toByteArray(Charsets.UTF_8))
        e.cur = f
        subs[k] = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f)).setMimeType(e.mime)
            .setId(if (e.kind == "ass") ASS_EXT_ID else "ext").setLabel(e.name).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
    }

    private fun applySub() {
        val sv = subView
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.getInt("ss", 20).toFloat())
        val bg = if (prefs.getBoolean("sb", false)) 0xAA000000.toInt() else Color.TRANSPARENT
        sv.setBottomPaddingFraction(prefs.getInt("spos", 8) / 100f)
        val a = (prefs.getInt("sop", 100).coerceIn(20, 100) * 255) / 100
        val fg = (prefs.getInt("sc", Color.WHITE) and 0x00FFFFFF) or (a shl 24)
        val edge = Color.BLACK and 0x00FFFFFF or (a shl 24)
        sv.setStyle(CaptionStyleCompat(fg, bg, Color.TRANSPARENT,
            CaptionStyleCompat.EDGE_TYPE_OUTLINE, edge, tf))
        updatePreview()
    }

    // ---------- live subtitle preview (Style tab) ----------
    private var subPreview: TextView? = null

    private fun updatePreview() {
        val tv = subPreview ?: return
        val a = (prefs.getInt("sop", 100).coerceIn(20, 100) * 255) / 100
        tv.setTextColor((prefs.getInt("sc", Color.WHITE) and 0x00FFFFFF) or (a shl 24))
        tv.textSize = prefs.getInt("ss", 20).coerceAtMost(34).toFloat()
        tv.setBackgroundColor(if (prefs.getBoolean("sb", false)) 0xAA000000.toInt() else Color.TRANSPARENT)
        tv.typeface = tf ?: Typeface.DEFAULT
    }

    private fun subPreviewBox(): View {
        val tv = TextView(this).apply {
            text = "I want to see more of this world."; gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(dp(8), dp(2), dp(8), dp(2))
        }
        subPreview = tv
        updatePreview()
        return FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF1B2A5A.toInt(), 0xFFD98A7A.toInt(), 0xFF2A2140.toInt())).apply { cornerRadius = dp(18).toFloat() }
            setPadding(dp(12), dp(36), dp(12), dp(18))
            layoutParams = LinearLayout.LayoutParams(-1, dp(120)).apply { bottomMargin = dp(12) }
            addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM))
        }
    }

    // ---------- fonts ----------
    private val sysFonts = listOf("Roboto Medium" to "sans-serif-medium", "Roboto Condensed" to "sans-serif-condensed",
        "Serif" to "serif", "Monospace" to "monospace", "Casual" to "casual", "Cursive" to "cursive")

    private fun fontMode() = prefs.getString("fm", null) ?: if (prefs.getString("sf", null) != null) "custom" else "def"

    private fun assetFontName(path: String) = path.substringAfterLast('/').substringBeforeLast('.')
        .replace('-', ' ').replace('_', ' ').removeSuffix(" Regular")

    private fun fontName(): String {
        val m = fontMode()
        return when {
            m.startsWith("sys:") -> sysFonts.firstOrNull { it.second == m.substring(4) }?.first ?: "System"
            m.startsWith("asset:") -> assetFontName(m.substring(6))
            m == "custom" -> prefs.getString("sfn", null) ?: "Custom Font"
            else -> "Default"
        }
    }

    private fun loadFont() {
        val m = fontMode()
        tf = try {
            when {
                m.startsWith("sys:") -> Typeface.create(m.substring(4), Typeface.NORMAL)
                m.startsWith("asset:") -> Typeface.createFromAsset(assets, m.substring(6))
                m == "custom" -> prefs.getString("sf", null)?.let { Typeface.createFromFile(it) }
                else -> null
            }
        } catch (e: Exception) { null }
    }

    private fun setFontMode(m: String) {
        prefs.edit().putString("fm", m).apply()
        loadFont(); applySub(); reopenSide(); showBadge()
    }

    // ---------- popup helpers (radio list + accent button) ----------
    private fun radioRow(t: String, on: Boolean, f: () -> Unit) = RadioButton(this).apply {
        text = t; isChecked = on; setTextColor(Color.WHITE); textSize = 16f
        setPadding(dp(8), dp(12), dp(8), dp(12)); setSingleLine(false)
        setOnClickListener { f() }
    }

    private fun accentButton(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(0xFF32A8FF.toInt()); textSize = 15f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(14), dp(12), dp(14))
        background = GradientDrawable().apply {
            setColor(0x3332A8FF); setStroke(dp(1), 0xFF32A8FF.toInt()); cornerRadius = dp(14).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        setOnClickListener { f() }
    }

    private fun listDialog(title: String, rows: List<View>, btnText: String, btn2Text: String? = null, onBtn2: (() -> Unit)? = null, rowDp: Int = 50, onBtn: () -> Unit) {
        dlg?.dismiss()
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; rows.forEach { addView(it) } }
        val sc = ScrollView(this).apply { addView(list) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16))
            addView(dialogHeader(title))
            addView(sc, LinearLayout.LayoutParams(-1, minOf(rows.size * dp(rowDp), (resources.displayMetrics.heightPixels * 0.5f).toInt())))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(accentButton(btnText, onBtn).apply {
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { topMargin = dp(12) }
                })
                if (btn2Text != null && onBtn2 != null) addView(accentButton(btn2Text, onBtn2).apply {
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { topMargin = dp(12); marginStart = dp(10) }
                })
            })
        }
        dlg = AlertDialog.Builder(this, DLG).setView(box).create().also {
            it.show()
            it.window?.setLayout(minOf(dp(460), (resources.displayMetrics.widthPixels * 0.92f).toInt()), -2)
        }
    }

    /** Dialog title + close (X) button. */
    private fun dialogHeader(title: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(10))
        addView(TextView(context).apply {
            text = title; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        addView(ImageView(context).apply {
            setImageResource(R.drawable.ic_close); setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundResource(R.drawable.circle_btn); contentDescription = "Close"
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            setOnClickListener { dlg?.dismiss() }
        })
    }

    /** Card row for files / queue items: name, optional badge + size; `best` = accent card. */
    private fun fileRow(name: String, badge: String?, size: String?, best: Boolean, mark: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundResource(if (best) R.drawable.card_sel_bg else R.drawable.row_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        addView(TextView(context).apply {
            text = (if (best) mark else "") + name; setTextColor(Color.WHITE); textSize = 15f; setSingleLine(false)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        if (!badge.isNullOrEmpty()) addView(TextView(context).apply {
            text = badge; setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(3), dp(8), dp(3)); setBackgroundResource(R.drawable.chip_bg)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) }
        })
        if (!size.isNullOrEmpty()) addView(TextView(context).apply {
            text = size; setTextColor(0xFF9A9AAC.toInt()); textSize = 12f
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) }
        })
        setOnClickListener { f() }
    }

    private fun subLabel(g: Tracks.Group, n: Int): String {
        val f = g.getTrackFormat(0)
        if (isExtFormat(f)) return ext[player.currentMediaItemIndex]?.name ?: (f.label ?: "External")
        return listOfNotNull(f.label, f.language).distinct().joinToString(" \u00B7 ").ifEmpty { "Track ${n + 1}" }
    }

    /** Subtitle popup: None + saare tracks (radio) + "Load External Subtitle". */
    private fun chooseSubTrack(gs: List<Tracks.Group>, k: Int) {
        pendingExt = -1
        val tp = player.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, k < 0)
        if (k >= 0) tp.addOverride(TrackSelectionOverride(gs[k].mediaTrackGroup, 0))
        player.trackSelectionParameters = tp.build()
        if (k >= 0 && !isExtFormat(gs[k].getTrackFormat(0))) gs[k].getTrackFormat(0).language?.let { prefs.edit().putString("ptl", it).apply() }
        prefs.edit().putBoolean("son", k >= 0).apply(); syncSubUi()
        subView.postDelayed({ showBadge() }, 150)
    }

    /** Inline track list for the Tracks tab (replaces the separate Track popup). */
    private fun subTrackRows(): List<View> {
        val gs = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        val sel = if (!subOn()) -1 else gs.indexOfFirst { it.isSelected }
        val rows = ArrayList<View>()
        rows.add(TextView(this).apply {
            text = "AVAILABLE TRACKS"; setTextColor(0xFF9A9AAC.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(10), 0, dp(8))
        })
        val after = { sidePanel.postDelayed({ reopenSide() }, 300) }
        rows.add(fileRow("None", null, null, sel < 0, "\u2713  ") { chooseSubTrack(gs, -1); after() })
        gs.forEachIndexed { n, g -> rows.add(fileRow(subLabel(g, n), null, null, n == sel, "\u2713  ") { chooseSubTrack(gs, n); after() }) }
        return rows
    }

    private fun subDialog() {
        val gs = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        val sel = if (!subOn()) -1 else gs.indexOfFirst { it.isSelected }
        val rows = ArrayList<View>()
        val choose = { k: Int -> chooseSubTrack(gs, k); dlg?.dismiss() }
        rows.add(radioRow("None", sel < 0) { choose(-1) })
        gs.forEachIndexed { n, g -> rows.add(radioRow(subLabel(g, n), n == sel) { choose(n) }) }
        listDialog("Subtitles", rows, "Subtitle files") { dlg?.dismiss(); subFolderDialog() }
    }

    /** Font popup: Default, system fonts, assets/fonts ki files, Custom Font + "Load Font File". */
    private class FontItem(val name: String, val source: String, val mode: String, val face: Typeface?)

    private fun fontItems(): List<FontItem> {
        val out = ArrayList<FontItem>()
        out.add(FontItem("Default", "Default", "def", null))
        sysFonts.forEach { (n, fam) ->
            out.add(FontItem(n, "System", "sys:$fam", try { Typeface.create(fam, Typeface.NORMAL) } catch (e: Exception) { null }))
        }
        (try { assets.list("fonts") } catch (e: Exception) { null } ?: emptyArray())
            .filter { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }.sorted().forEach { fn ->
                val path = "fonts/$fn"
                out.add(FontItem(assetFontName(path), "App", "asset:$path", try { Typeface.createFromAsset(assets, path) } catch (e: Exception) { null }))
            }
        val sf = prefs.getString("sf", null)
        if (sf != null && File(sf).exists())
            out.add(FontItem("Custom Font" + (prefs.getString("sfn", null)?.let { " ($it)" } ?: ""), "Custom", "custom",
                try { Typeface.createFromFile(sf) } catch (e: Exception) { null }))
        return out
    }

    /** Font card: search + filter chips + every font shown in its own face. */
    private fun fontDialog() {
        dlg?.dismiss()
        val m = fontMode()
        val items = fontItems()
        var filter = "All"
        var query = ""
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun renderList() {
            listBox.removeAllViews()
            val q = query.trim().lowercase(Locale.ROOT)
            val shown = items.filter { (filter == "All" || it.source == filter) && (q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q)) }
            if (shown.isEmpty()) listBox.addView(TextView(this).apply {
                text = "No fonts found"; setTextColor(0xFFBBBBCC.toInt()); setPadding(dp(8), dp(14), dp(8), dp(14))
            })
            shown.forEach { fi ->
                val on = fi.mode == m
                listBox.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(12))
                    setBackgroundResource(if (on) R.drawable.card_sel_bg else R.drawable.row_bg)
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                    addView(TextView(context).apply {
                        text = fi.name + "  \u00B7  " + fi.source + (if (on) "  \u2713" else "")
                        setTextColor(if (on) 0xFF32A8FF.toInt() else 0xFFBBBBCC.toInt()); textSize = 12f
                    })
                    addView(TextView(context).apply {
                        text = "Aa Bb Cc 123  The quick brown fox \u0905\u0906\u0907"
                        setTextColor(Color.WHITE); textSize = 20f; setSingleLine(false)
                        fi.face?.let { typeface = it }
                    })
                    setOnClickListener { dlg?.dismiss(); setFontMode(fi.mode) }
                })
            }
        }

        fun renderChips() {
            chipRow.removeAllViews()
            (listOf("All") + items.map { it.source }.distinct().filter { it != "Default" }).forEach { n ->
                chipRow.addView(TextView(this).apply {
                    text = n; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    setTextColor(if (n == filter) Color.WHITE else 0xFF9A9AAC.toInt())
                    setBackgroundResource(if (n == filter) R.drawable.tab_sel_bg else R.drawable.chip_bg)
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
                    setOnClickListener { filter = n; renderChips(); renderList() }
                })
            }
        }
        renderChips(); renderList()

        val search = android.widget.EditText(this).apply {
            hint = "Search fonts"; setHintTextColor(0xFF6B6B7A.toInt()); setTextColor(Color.WHITE); textSize = 15f
            setSingleLine(true); setBackgroundResource(R.drawable.row_bg); setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { query = s?.toString() ?: ""; renderList() }
            })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16))
            addView(dialogHeader("Fonts"))
            addView(search)
            addView(android.widget.HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false; addView(chipRow)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            })
            addView(ScrollView(context).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(accentButton(prefs.getString("font_tree", null)?.let { "Font folder  \u00B7  " + folderLabel(it) } ?: "Select font folder") { dlg?.dismiss(); fontFolderDialog() }.apply {
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            })
        }
        dlg = AlertDialog.Builder(this, DLG).setView(box).create().also {
            it.show()
            it.window?.setLayout(minOf(dp(520), (resources.displayMetrics.widthPixels * 0.94f).toInt()), (resources.displayMetrics.heightPixels * 0.92f).toInt())
            it.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
    }

    private val hideBadge = Runnable { findViewById<View>(R.id.subBadge).visibility = View.GONE }

    /** Chhota corner label: kaunsa subtitle + kaunsa font abhi laga hai. */
    private fun showBadge() {
        val b = findViewById<TextView>(R.id.subBadge)
        b.background = GradientDrawable().apply { setColor(0xCC101824.toInt()); setStroke(dp(1), 0x33FFFFFF); cornerRadius = dp(12).toFloat() }
        b.text = "Sub: " + currentSubName() + "\nFont: " + fontName()
        b.visibility = View.VISIBLE
        b.removeCallbacks(hideBadge)
        b.postDelayed(hideBadge, 2800)
    }

    private fun pickFile(r: Int) {
        closeSide()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), r)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data ?: return
        if (res != RESULT_OK) return
        if (r == 3 || r == 4) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
            prefs.edit().putString(if (r == 3) "sub_tree" else "font_tree", u.toString()).apply()
            if (r == 3) subFolderDialog() else fontFolderDialog()
            return
        }
        if (r == 1) loadSubUri(u) else loadFontUri(u)
        player.play()
    }

    // ---------- folder pick (subtitle / font) ----------
    private class FEntry(val name: String, val uri: Uri, val size: Long)

    private fun pickFolder(r: Int) {
        closeSide()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), r)
    }

    /** Chune hue folder ki files (sirf allowed extensions), naam ke hisaab se sorted. */
    private fun listFolder(treeStr: String, exts: Set<String>): List<FEntry>? {
        return try {
            val tree = Uri.parse(treeStr)
            val docId = android.provider.DocumentsContract.getTreeDocumentId(tree)
            val kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val out = ArrayList<FEntry>()
            contentResolver.query(kids, arrayOf(
                android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                android.provider.DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val nm = c.getString(1) ?: continue
                    if (nm.substringAfterLast('.', "").lowercase(Locale.ROOT) !in exts) continue
                    out.add(FEntry(nm, android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)), c.getLong(2)))
                }
            } ?: return null
            out.sortedBy { it.name.lowercase(Locale.ROOT) }
        } catch (e: Exception) { null }
    }

    private fun folderLabel(treeStr: String): String = try {
        android.provider.DocumentsContract.getTreeDocumentId(Uri.parse(treeStr)).substringAfter(':').ifEmpty { "Storage" }
    } catch (e: Exception) { "Folder" }

    private fun plainRow(t: String, sub: String? = null, f: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(10), dp(8), dp(10))
        addView(TextView(context).apply { text = t; setTextColor(Color.WHITE); textSize = 15f; setSingleLine(false) })
        if (sub != null) addView(TextView(context).apply { text = sub; setTextColor(0xFFBBBBCC.toInt()); textSize = 12f })
        setOnClickListener { f() }
    }

    private fun videoBaseName(): String {
        val k = player.currentMediaItemIndex
        val raw = try { Uri.parse(uris[k]).lastPathSegment ?: "" } catch (e: Exception) { "" }
        return raw.substringAfterLast('/').substringAfterLast(':').substringBeforeLast('.').lowercase(Locale.ROOT)
    }

    /** Subtitle folder: saved folder ki saari subtitle files; current video se milta naam upar. */
    private fun subFolderDialog() {
        val tree = prefs.getString("sub_tree", null)
        if (tree == null) { pickFolder(3); return }
        val files = listFolder(tree, setOf("srt", "vtt", "ass", "ssa", "ttml", "dfxp", "xml"))
        if (files == null) { show("Folder not accessible. Select it again."); pickFolder(3); return }
        val base = videoBaseName()
        val sorted = files.sortedByDescending { base.isNotEmpty() && it.name.substringBeforeLast('.').lowercase(Locale.ROOT).let { n -> n == base || n.startsWith(base) || base.startsWith(n) } }
        val rows = ArrayList<View>()
        fun isMatch(n: String) = base.isNotEmpty() && n.substringBeforeLast('.').lowercase(Locale.ROOT).let { x -> x == base || x.startsWith(base) || base.startsWith(x) }
        fun hdr(t: String) = TextView(this).apply { text = t; setTextColor(0xFF9A9AAC.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(6), 0, dp(6)) }
        if (sorted.isEmpty()) rows.add(TextView(this).apply { text = "No subtitle files in this folder"; setTextColor(0xFFBBBBCC.toInt()); setPadding(dp(8), dp(12), dp(8), dp(12)) })
        var shownOther = false
        sorted.forEachIndexed { idx, fe ->
            val match = isMatch(fe.name)
            if (idx == 0 && match) rows.add(hdr("BEST MATCH FOR THIS VIDEO"))
            if (!match && !shownOther) { shownOther = true; rows.add(hdr(if (idx == 0) "SUBTITLE FILES" else "OTHER FILES")) }
            rows.add(fileRow(fe.name, fe.name.substringAfterLast('.', "").uppercase(Locale.ROOT), if (fe.size > 0) "${fe.size / 1024} KB" else null, match, "\u2605 ") {
                dlg?.dismiss(); loadSubUri(fe.uri); player.play()
            })
        }
        listDialog("Subtitles \u00B7 " + folderLabel(tree), rows, "Change Folder", null, null, 66) { dlg?.dismiss(); pickFolder(3) }
    }

    /** Font folder: har font apne hi font me preview ke saath. */
    private fun fontFolderDialog() {
        val tree = prefs.getString("font_tree", null)
        if (tree == null) { pickFolder(4); return }
        val files = listFolder(tree, setOf("ttf", "otf", "ttc"))
        if (files == null) { show("Folder not accessible. Select it again."); pickFolder(4); return }
        val rows = ArrayList<View>()
        if (files.isEmpty()) rows.add(TextView(this).apply { text = "No font files in this folder"; setTextColor(0xFFBBBBCC.toInt()); setPadding(dp(8), dp(12), dp(8), dp(12)) })
        val cache = File(cacheDir, "fontprev").apply { mkdirs() }
        val pool = Executors.newSingleThreadExecutor()
        files.forEach { fe ->
            val sample = TextView(this).apply {
                text = "Aa Bb Cc 123  The quick brown fox \u0905\u0906\u0907"; setTextColor(Color.WHITE); textSize = 20f; setSingleLine(false)
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(10), dp(8), dp(10))
                addView(TextView(context).apply { text = fe.name; setTextColor(0xFFBBBBCC.toInt()); textSize = 12f })
                addView(sample)
                setOnClickListener { dlg?.dismiss(); loadFontUri(fe.uri); player.play() }
            }
            rows.add(row)
            // preview: font ko cache me copy karke background me load, phir sample par lagao
            pool.execute {
                val tfp = try {
                    val f = File(cache, (fe.uri.toString().hashCode().toString() + "_" + fe.size + "." + fe.name.substringAfterLast('.')))
                    if (!f.exists() || f.length() == 0L) contentResolver.openInputStream(fe.uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    Typeface.createFromFile(f)
                } catch (e: Exception) { null }
                if (tfp != null) runOnUiThread { sample.typeface = tfp }
            }
        }
        pool.shutdown()   // queued previews poore hone ke baad band
        listDialog("Fonts \u00B7 " + folderLabel(tree), rows, "Change Folder", null, null, 78) { dlg?.dismiss(); pickFolder(4) }
    }

    private fun loadSubUri(u: Uri) {
        run {
            val dn = (contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: u.lastPathSegment ?: "subtitle")
            val n = dn.lowercase()
            val (kind, mt) = when {
                n.endsWith(".vtt") -> "vtt" to MimeTypes.TEXT_VTT
                n.endsWith(".ass") || n.endsWith(".ssa") -> "ass" to MimeTypes.TEXT_SSA
                n.endsWith(".ttml") || n.endsWith(".dfxp") || n.endsWith(".xml") -> "ttml" to MimeTypes.APPLICATION_TTML
                n.endsWith(".srt") -> "srt" to MimeTypes.APPLICATION_SUBRIP
                else -> {
                    show("Unsupported subtitle format. Use SRT, VTT, ASS, SSA or TTML.")
                    player.play()
                    return
                }
            }
            val bytes = try { contentResolver.openInputStream(u)?.use { it.readBytes() } } catch (e: Exception) { null }
            if (bytes == null || bytes.isEmpty()) { show("Subtitle file could not be read"); player.play(); return }
            val txt = decodeText(bytes)
            val valid = when (kind) {
                "ass" -> txt.contains("[Events]", ignoreCase = true) &&
                    txt.lineSequence().any { it.trimStart().startsWith("Dialogue:", ignoreCase = true) }
                "ttml" -> txt.contains("<tt", ignoreCase = true) && txt.contains("<body", ignoreCase = true)
                "vtt" -> txt.trimStart().removePrefix("\uFEFF").startsWith("WEBVTT", ignoreCase = true) && tsRe.containsMatchIn(txt)
                else -> tsRe.containsMatchIn(txt)
            }
            if (!valid) { show("Subtitle file is invalid or unsupported"); player.play(); return }
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            ext[i]?.cur?.delete()
            ext[i] = ExtSub(txt, kind, mt, dn)
            saveExt(i)
            pendingExt = i
            badgeAfterSelect = true
            buildExt(i)
            prefs.edit().putBoolean("son", true).apply()
            player.replaceMediaItem(i, item(i))
            player.seekTo(i, p)
            // Selection must happen after Media3 prepares the replacement item and exposes its
            // external text TrackGroup. Keep playback state and the existing player workflow.
            applySubOnOff()
            subView.postDelayed(extTrackRetry, 450)
            show("Subtitle added — loading track…")
        }
    }

    private fun loadFontUri(u: Uri) {
        run {
            try {
                val displayName = contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "custom.ttf"
                val extn = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                if (extn !in setOf("ttf", "otf", "ttc")) {
                    show("Unsupported font. Choose a TTF, OTF or TTC font file.")
                    player.play()
                    return
                }
                val f = File(filesDir, "subtitle_font.$extn")
                val copied = contentResolver.openInputStream(u)?.use { ins ->
                    f.outputStream().use { out -> ins.copyTo(out) }
                    f.length() > 0
                } ?: false
                if (!copied) throw IllegalStateException("Empty font file")
                val loaded = Typeface.createFromFile(f)
                prefs.edit().putString("sf", f.path).putString("fm", "custom").putString("sfn", displayName).apply()
                tf = loaded
                applySub()
                showBadge()
            } catch (e: Exception) { show("Font could not be loaded. Try a valid TTF/OTF/TTC file.") }
        }
    }

    private fun pick(type: Int) {
        val gs = player.currentTracks.groups.filter { it.type == type && it.isSupported }
        if (gs.isEmpty()) { show("No tracks"); return }
        val off = type == C.TRACK_TYPE_TEXT
        val names = (if (off) listOf("Off") else listOf<String>()) +
            gs.mapIndexed { n, g -> (if (g.isSelected) "\u2713 " else "") + g.getTrackFormat(0).let { it.label ?: it.language ?: "Track ${n + 1}" } }
        AlertDialog.Builder(this, DLG).setItems(names.toTypedArray()) { _, i ->
            val k = if (off) i - 1 else i
            val tp = player.trackSelectionParameters.buildUpon().clearOverridesOfType(type).setTrackTypeDisabled(type, k < 0)
            if (k >= 0) tp.addOverride(TrackSelectionOverride(gs[k].mediaTrackGroup, 0))
            player.trackSelectionParameters = tp.build()
            if (type == C.TRACK_TYPE_AUDIO && k >= 0) gs[k].getTrackFormat(0).language?.let { prefs.edit().putString("pal", it).apply() }
            if (type == C.TRACK_TYPE_TEXT) { prefs.edit().putBoolean("son", k >= 0).apply(); syncSubUi() }
        }.show()
    }

    // ---------- video enhance (GPU colour matrix, no extra library) ----------
    private fun setEnh(b: Int, c: Int, s: Int, sh: Int = 0) {
        prefs.edit().putInt("eb", b).putInt("ec", c).putInt("es", s).putInt("esh", sh).apply()
        applyEnh(); reopenSide()
    }

    private fun applyEnh() {
        val b = prefs.getInt("eb", 0)
        val c = prefs.getInt("ec", 100) / 100f
        val m = ColorMatrix().apply { setSaturation(prefs.getInt("es", 100) / 100f) }
        val o = 128 * (1 - c) + b * 1.2f
        m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, o, 0f, c, 0f, 0f, o, 0f, 0f, c, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        pv.videoSurfaceView?.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        applySharp()
    }

    /** Sharpness: 3x3 unsharp-mask shader (AGSL, Android 13+). 0 = band. */
    private fun applySharp() {
        if (Build.VERSION.SDK_INT < 33) return
        val v = pv.videoSurfaceView ?: return
        val amt = prefs.getInt("esh", 0) / 125f
        if (amt <= 0f) { v.setRenderEffect(null); return }
        try {
            val sh = RuntimeShader(SHARP_AGSL)
            sh.setFloatUniform("amount", amt)
            v.setRenderEffect(RenderEffect.createRuntimeShaderEffect(sh, "inputShader"))
        } catch (e: Exception) { v.setRenderEffect(null) }
    }

    private fun setLock(on: Boolean) {
        locked = on
        pv.useController = !on
        unlockBtn.removeCallbacks(hideUnlock)
        if (on) flashUnlock() else unlockBtn.visibility = View.GONE
    }

    private fun flashUnlock() {
        unlockBtn.visibility = View.VISIBLE
        unlockBtn.removeCallbacks(hideUnlock)
        unlockBtn.postDelayed(hideUnlock, 2500)
    }

    /** Double-tap play/pause: letters ki jagah symbol (animated). */
    private fun flashPlay(playing: Boolean) {
        playFlash.animate().cancel()
        playFlash.removeCallbacks(hideFlash)
        playFlash.setImageResource(if (playing) R.drawable.ic_play else R.drawable.ic_pause)
        playFlash.visibility = View.VISIBLE
        playFlash.alpha = 0f; playFlash.scaleX = 0.7f; playFlash.scaleY = 0.7f
        playFlash.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140)
            .withEndAction { playFlash.postDelayed(hideFlash, 450) }.start()
    }

    /** MediaStore se width/height (rotation ke saath) -> true = vertical video. Pata na chale to null. */
    private fun peekPortrait(u: String?): Boolean? {
        if (u == null) return null
        return try {
            val cols = if (Build.VERSION.SDK_INT >= 29)
                arrayOf(MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT, MediaStore.Video.Media.ORIENTATION)
            else arrayOf(MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT)
            contentResolver.query(Uri.parse(u), cols, null, null, null)?.use { c ->
                if (!c.moveToFirst()) return@use null
                var w = c.getInt(0); var h = c.getInt(1)
                if (cols.size > 2) { val r = c.getInt(2); if (r == 90 || r == 270) { val t = w; w = h; h = t } }
                if (w <= 0 || h <= 0) null else h > w
            }
        } catch (e: Exception) { null }
    }

    /** Instant +-10s: fast (keyframe) seek, taps accumulate (+10, +20, +30...). */
    private fun skip(dir: Int) {
        val now = SystemClock.uptimeMillis()
        if (dir != skipDir || now - lastSkipAt > 900) { skipAcc = 0L; skipBase = player.currentPosition }
        skipDir = dir; lastSkipAt = now
        skipAcc += 10_000L * dir
        val dur = player.duration
        val t = skipBase + skipAcc
        player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        player.seekTo(if (dur > 0) t.coerceIn(0L, dur) else t.coerceAtLeast(0L))
        pv.removeCallbacks(exactSeek); pv.postDelayed(exactSeek, 1200)
        val v = if (dir < 0) skipL else skipR
        (if (dir < 0) skipR else skipL).visibility = View.GONE
        v.text = (if (skipAcc > 0) "+" else "") + (skipAcc / 1000) + "s"
        v.visibility = View.VISIBLE
        v.animate().cancel()
        v.alpha = 1f; v.scaleX = 0.85f; v.scaleY = 0.85f
        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        v.removeCallbacks(hideSkip); v.postDelayed(hideSkip, 700)
    }

    private fun showLevel(label: String, pct: Int) {
        levelTxt.text = label
        levelBar.progress = pct.coerceIn(0, 100)
        levelBox.visibility = View.VISIBLE
        levelBox.removeCallbacks(hideLevel); levelBox.postDelayed(hideLevel, 900)
    }

    // ---- per-video speed ----
    private fun spdKey(i: Int) = "spd_" + (uris.getOrNull(i) ?: "").hashCode()
    private fun setSpeed(sp: Float) {
        player.setPlaybackSpeed(sp)
        prefs.edit().putFloat(spdKey(player.currentMediaItemIndex), sp).apply()
        show("${sp}x")
    }
    private fun applySpeed() { player.setPlaybackSpeed(prefs.getFloat(spdKey(player.currentMediaItemIndex), 1f)) }

    // ---- A-B repeat ----
    private fun abRow(): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = {
            tv.text = "A-B repeat: " + (if (abA < 0) "off" else VideoInfo.dur(abA)) + (if (abB > 0) "  to  " + VideoInfo.dur(abB) else "")
        }
        upd()
        fun chip(l: String, f: () -> Unit) = btn(l) { f(); upd() }.apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
            setBackgroundResource(R.drawable.chip_bg)
        }
        val row = LinearLayout(this).apply {
            addView(chip("Set A") { abA = player.currentPosition; abB = -1L })
            addView(chip("Set B") { if (abA >= 0 && player.currentPosition > abA) abB = player.currentPosition })
            addView(chip("Clear") { abA = -1L; abB = -1L })
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row) }
    }

    // ---- queue / playlist ----
    private fun queue() {
        val cur = player.currentMediaItemIndex
        val rows = uris.indices.map { i ->
            fileRow(names?.getOrNull(i) ?: Uri.parse(uris[i]).lastPathSegment ?: "Video", null, "#" + (i + 1), i == cur, "\u25B6  ") {
                dlg?.dismiss(); player.seekTo(i, 0L)
            }
        }
        listDialog("Queue (" + uris.size + ")", rows, "Close", null, null, 66) { dlg?.dismiss() }
    }

    private fun friendly(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "Video file nahi mili (shayad delete ya move ho gayi)."
        PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> "Is video ko kholne ki permission nahi hai."
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "Internet / network problem. Connection check karke Retry karo."
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED -> "Ye file kharab ya unsupported format ki hai."
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> "Phone ye video format decode nahi kar pa raha. HW/SW decoder chip badal ke dekho."
        else -> "Playback me problem aayi."
    }

    // ---- seekbar thumbnail preview ----
    private fun scrubTo(pos: Long) {
        val dur = player.duration
        scrubTime.text = VideoInfo.dur(pos)
        if (dur > 0) {
            val frac = (pos.toFloat() / dur).coerceIn(0f, 1f)
            val room = (pv.width - dp(136)).coerceAtLeast(0)
            scrubBox.translationX = frac * room
        }
        scrubWant = pos
        if (!scrubBusy) loadScrubFrame()
    }

    private fun loadScrubFrame() {
        val uri = player.currentMediaItem?.localConfiguration?.uri ?: return
        if (uri.scheme != "content" && uri.scheme != "file") return
        val want = scrubWant
        scrubBusy = true
        scrubPool.execute {
            var bm: Bitmap? = null
            try {
                val key = uri.toString()
                if (mmr == null || mmrUri != key) {
                    try { mmr?.release() } catch (e: Exception) { }
                    mmr = MediaMetadataRetriever().also { it.setDataSource(this, uri) }
                    mmrUri = key
                }
                bm = if (Build.VERSION.SDK_INT >= 27)
                    mmr?.getScaledFrameAtTime(want * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 272, 156)
                else mmr?.getFrameAtTime(want * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } catch (e: Exception) { }
            runOnUiThread {
                scrubBusy = false
                if (bm != null) scrubImg.setImageBitmap(bm)
                if (scrubBox.visibility == View.VISIBLE && scrubWant != want) loadScrubFrame()
            }
        }
    }

    private fun show(t: String) {
        info.removeCallbacks(hideInfo)
        info.text = t
        info.visibility = View.VISIBLE
        info.postDelayed(hideInfo, 800)
    }

    private fun mark(item: MediaItem, pos: Long, dur: Long) {
        val u = item.localConfiguration?.uri?.toString() ?: return
        History.save(this, u, pos, dur, folder, item.mediaMetadata.title?.toString() ?: "Video")
    }

    private fun save() {
        val item = player.currentMediaItem ?: return
        val d = player.duration
        if (d > 0) mark(item, player.currentPosition, d)
    }

    private fun pip() {
        enterPictureInPictureMode(PictureInPictureParams.Builder().build())
    }

    override fun onUserLeaveHint() {
        if (!locked && player.isPlaying) pip()
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        pv.useController = !inPip && !locked
    }

    // ---------- headset / bluetooth media buttons ----------
    private var msess: MediaSession? = null

    private fun setupSession() {
        msess?.let { it.isActive = false; it.release() }
        val s = MediaSession(this, "AniTube")
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { player.play() }
            override fun onPause() { player.pause() }
            override fun onStop() { player.pause() }
            override fun onSkipToNext() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
            override fun onSkipToPrevious() {
                if (player.currentPosition > 3000 || !player.hasPreviousMediaItem()) player.seekTo(0) else player.seekToPreviousMediaItem()
            }
            override fun onFastForward() { player.seekTo(player.currentPosition + 10_000) }
            override fun onRewind() { player.seekTo(maxOf(0L, player.currentPosition - 10_000)) }
            override fun onSeekTo(pos: Long) { player.seekTo(pos) }
        })
        s.isActive = true
        msess = s
        syncSession()
    }

    private fun syncSession() {
        val s = msess ?: return
        val playing = player.isPlaying || (player.playWhenReady && player.playbackState == Player.STATE_BUFFERING)
        val acts = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_STOP or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
            PlaybackState.ACTION_FAST_FORWARD or PlaybackState.ACTION_REWIND or PlaybackState.ACTION_SEEK_TO
        s.setPlaybackState(PlaybackState.Builder().setActions(acts)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                player.currentPosition, if (playing) player.playbackParameters.speed else 0f).build())
    }

    override fun onStop() { super.onStop(); save(); player.pause() }
    override fun onDestroy() {
        super.onDestroy()
        subView.removeCallbacks(tick); subView.removeCallbacks(reloadSub); subView.removeCallbacks(sleepRun); info.removeCallbacks(flushAudio)
        pv.removeCallbacks(exactSeek)
        scrubPool.execute { try { mmr?.release() } catch (e: Exception) { } }
        scrubPool.shutdown()
        ext.values.forEach { it.cur?.delete() }
        msess?.let { it.isActive = false; it.release() }
        fx.release()
        player.release()
    }
}
