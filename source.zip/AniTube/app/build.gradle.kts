import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Apni release key: AniTube/keystore.properties (git me nahi jati). Nahi mili to debug key se build (sirf testing).
val verCode = (project.findProperty("verCode") as String?)?.toIntOrNull() ?: 2
val verName = (project.findProperty("verName") as String?) ?: "1.1"
val ksFile = rootProject.file("keystore.properties")
val ks = Properties().apply { if (ksFile.exists()) ksFile.inputStream().use { load(it) } }

android {
    namespace = "com.anitube.player"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.anitube.player"
        minSdk = 26
        targetSdk = 34
        versionCode = verCode
        versionName = verName
        resourceConfigurations += "en"
        // ffmpeg ki native libs sirf phones ke ABI ki (x86 emulator wale hata diye) -> APK chhota
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    signingConfigs {
        create("release") {
            if (ksFile.exists()) {
                storeFile = rootProject.file(ks.getProperty("storeFile"))
                storePassword = ks.getProperty("storePassword")
                keyAlias = ks.getProperty("keyAlias")
                keyPassword = ks.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName(if (ksFile.exists()) "release" else "debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Kotlin 2.x: kotlinOptions ki jagah compilerOptions
kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.8.0")
    implementation("androidx.media3:media3-ui:1.8.0")
    implementation("io.github.peerless2012:ass-media:0.5.1")   // libass (ASS/SSA) - media3 1.8.0 par bani hai, versions saath rakhna
    implementation("io.github.anilbeesetti:nextlib-media3ext:1.8.0-0.9.0")   // FFmpeg decoders (AC3/EAC3/DTS/TrueHD...). GPL-3.0! media3 version se match rakhna
    implementation("androidx.media3:media3-exoplayer-hls:1.8.0")   // .m3u8 streams
    implementation("androidx.core:core:1.13.1")   // FileProvider (update install)
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")   // pull to refresh
}
