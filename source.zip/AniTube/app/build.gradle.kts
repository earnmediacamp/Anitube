import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Apni release key: AniTube/keystore.properties (git me nahi jati). Nahi mili to debug key se build (sirf testing).
val verCode = (project.findProperty("verCode") as String?)?.toIntOrNull() ?: 2
val verName = (project.findProperty("verName") as String?) ?: "1.1"
val ksFile = rootProject.file("keystore.properties")
val ks = Properties().apply { if (ksFile.exists()) ksFile.inputStream().use { load(it) } }

android {
    namespace = "com.anitube.player"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.anitube.player"
        minSdk = 26
        targetSdk = 34
        versionCode = verCode
        versionName = verName
        resourceConfigurations += "en"
    }
    signingConfigs {
        create("release") {
            if (ksFile.exists()) {
                storeFile = rootProject.file(ks.getProperty("storeFile"))
                storePassword = ks.getProperty("storePassword")
                keyAlias = ks.getProperty("keyAlias")
                keyPassword = ks.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName(if (ksFile.exists()) "release" else "debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.core:core:1.13.1")   // FileProvider (update install)
}
